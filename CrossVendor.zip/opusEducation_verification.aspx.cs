﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;
using System.Text;
using System.Web.SessionState;
public partial class opusEducation_verification : System.Web.UI.Page
{
    public Button btn;
    string employeeID = "";
    string fullempID = "";
    string clientID = "";
    string vendorID = "";
    string jobID = "";
    string Email = "";
    string password = "";
    string sOut = "";
    private bool startConversion = false;
    private bool identity = false;
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            sOut = "";
        }
        
        if (IsPostBack == true)
        {
            Email = email_ID.Text;
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                string strSql = " select ed.employee_id, concat('W', clt.client_alias, '00', right('0000' + convert(varchar(4), ed.employee_id), 4)) as employeesfull_id, "+
                                "ea.client_id,ea.vendor_id,ea.job_id, dbo.CamelCase(ed.first_name + ' ' + ed.last_name) full_name " +
                                " from ovms_employee_details as ed " +
                                "  join ovms_employees as ea on ea.employee_id = ed.employee_id " +
                                "left join ovms_clients as clt on clt.client_id = ea.client_id" +
                                " where ed.email ='" + Email + "'";
                SqlCommand cmd = new SqlCommand(strSql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        employeeID = reader["employee_id"].ToString();
                        fullempID = reader["employeesfull_id"].ToString();
                        clientID = reader["client_id"].ToString();
                        vendorID = reader["vendor_id"].ToString();
                        jobID = reader["job_id"].ToString();
                        Session["emp_emailID"] = employeeID;
                    }
                    identity = true;
                    lblMailAlert.Visible = false;
                }
                else
                {
                    identity = false;
                    lblMailAlert.Visible = true;
                    lblMailAlert.Text = "invalid email";
                }
                conn.Close();
                reader.Close();
                cmd.Dispose();
            }
        }
    }

    protected void btnBGcheck_Click(object sender, EventArgs e)
    {
        if (identity == true)
        {
            startConversion = true;
            string Fullname = txtFullname.Text;
            send_info("Fullname", Fullname);
            string dob = Textdate.Value;
            send_info("Date of birth", dob);
            string aliasname = alias.Text;
            send_info("alias name", aliasname);
            string email = email_ID.Text;
            send_info("email", email);
            string signature1 = signature.Text;
            send_info("signature1", signature1);
            string datejoin = date.Value;
            send_info("date", datejoin);
            string telephone = tele.Value;
            send_info("telephone", telephone);
            string hiring_manager = hiring_manager_name.Text;
            send_info("hiring manager", hiring_manager);
            string position1 = position.Text;
            send_info("Position", position1);
            string school = school_ph1.Text;
            send_info("School attended", school);
            string program = program_name_ph1.Text;
            send_info("program attended", program);
            string school_address = addr_ph1.Text;
            send_info("School address", school_address);
            string school_phone = tele_ph1.Value;
            send_info("school phone", school_phone);
            string stu_no = stuno_ph1.Text;
            send_info("student number", stu_no);
            if (Request.Form["group1"] != null)
            {
                send_info("Program Completed", Request.Form["group1"].ToString());
            }
            string school_start_date = straDate_ph1.Value;
            send_info("School start date", school_start_date);
            string school_end_date = enddate_ph1.Value;
            send_info("school end date", school_end_date);
            string school2 = school_ph2.Text;
            send_info("second school", school2);
            string program2 = program_name_ph2.Text;
            send_info("other program", program2);
            string school_address2 = addr_ph2.Text;
            send_info("second school address", school_address2);
            string school_phone2 = tele_ph2.Value;
            send_info("second school phone", school_phone2);
            string stu_no2 = stuno_ph2.Text;
            send_info("student number", stu_no2);
            if (Request.Form["group2"] != null)
            {
                send_info("Program Completed", Request.Form["group2"].ToString());
            }
            string school_start_date2 = straDate_ph2.Value;
            send_info("second school start date", school_start_date2);
            string school_end_date2 = enddate_ph2.Value;
            send_info("second school end date", school_end_date2);

            string organization_name = org_name.Text;
            send_info("organization name", organization_name);
            string program3 = prog.Text;
            send_info("program in organization", program3);
            string address = addr_ph3.Text;
            send_info("organization address", address);
            string org_phone = tele_ph3.Value;
            send_info("organization phone", org_phone);
            string stu_no3 = stuno_ph3.Text;
            send_info("organization student number", stu_no3);
            if (Request.Form["group3"] != null)
            {
                send_info("Program Completed", Request.Form["group3"].ToString());
            }
            string org_start_date = straDate_ph3.Value;
            send_info("organization start date", org_start_date);
            string org_end_date = enddate_ph3.Value;
            send_info("organization end date", org_end_date);
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        }
    }
    protected override void Render(HtmlTextWriter writer)
    {
        if(startConversion == true && identity == true)
        { 
            TextWriter myWriter = new StringWriter();
            HtmlTextWriter htwOut = new HtmlTextWriter(myWriter);
        base.Render(htwOut);
            //sOut = sbOut.ToString();
            //Session["sOut"] = sOut;
            // Send sOut as an Email
            BackgroundApi.apiservice files = new BackgroundApi.apiservice(); //testlab.Text =

            if (Directory.Exists(Server.MapPath("~/BackGround/" + fullempID + "/")) == false)
            {
                DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/BackGround/" + fullempID + "/"));
            }

            string strpath = Server.MapPath("BackGround/" + fullempID + "/Educationalverification.pdf");
            files.pdf_convertor(myWriter.ToString(), strpath);
            //writer.Write(myWriter.ToString());
        }
        else
        {
            // render web page in browser
            base.Render(writer);
        }
    }

    public void send_info(string title, string value)
    {
        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
            string strSql = "select * from ovms_users where email_id='" + Email + "'";
            SqlCommand cmd = new SqlCommand(strSql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    password = reader["user_password"].ToString();
                }
            }
            conn.Close();
            reader.Close();
            cmd.Dispose();
        }
        string field_name = title;
        string field_value = value;

       // localhost.Service web = new localhost.Service();

        XmlDocument dom11 = new XmlDocument();
        dom11.LoadXml( send_bgINFO_from_candidate(Email, password, field_name, field_value, employeeID, clientID, vendorID, "1", "edu_background", jobID).InnerXml);

        XmlNodeList Response34 = dom11.SelectNodes("XML/RESPONSE");
    }
    public XmlDocument send_bgINFO_from_candidate(string userEmailId, string userPassword, string field_name, string field_value, string employee_id, string client_id, string vendor_id, string form_id, string doc_title, string job_id)
    {
        SqlConnection conn;
        string xml_string = "";
        // logAPI.Service logService = new logAPI.Service();
        string errString = "";
        //errString = VerifyUser(userEmailId, userPassword);

        xml_string = "<XML>" +
                    "<REQUEST>" +


                         "<FIELD_NAME>" + field_name + "</FIELD_NAME>" +
                         "<FIELD_VALUE>" + field_value + "</FIELD_VALUE>" +
                        "<EMPLOYEE_ID>" + employee_id + "</EMPLOYEE_ID>" +
                        "<CLIENT_ID>" + client_id + "</CLIENT_ID>" +
                        "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +
                         "<FORM_ID>" + form_id + "</FORM_ID>" +
                         "<DOC_TITLE>" + doc_title + "</DOC_TITLE>" +



                    "</REQUEST>";
        xml_string += "<RESPONSE>";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        if (errString != "")
        {
            xml_string += "<ERROR>" + errString + "</ERROR>";
        }
        else
        {
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string strSql = " insert into ovms_background_check ( client_id, document_title, field_name,field_value,vendor_id, employee_id, form_id, job_id) " +
                                   "  values('" + client_id + "', '" + doc_title + "', '" + field_name + "', '" + field_value + "', '" + vendor_id + "', '" + employee_id + "','" + form_id + "','" + job_id + "')";

                    SqlCommand cmd = new SqlCommand(strSql, conn);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        xml_string += "<INSERT_STRING>Info inserted</INSERT_STRING>";
                    }
                    else
                    {
                        xml_string += "<INSERT_STRING><ERROR>Info not inserted</ERROR> </INSERT_STRING>";

                    }
                    cmd.Dispose();
                    conn.Close();

                }
            }

            catch (Exception ex)
            {
                xml_string += "<XML>" + "<STATUS>error:100.systemerror</STATUS>";


            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
        xml_string += "</RESPONSE>" +
                             "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }
}

