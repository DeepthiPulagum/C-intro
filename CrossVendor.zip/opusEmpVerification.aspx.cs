﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class opusEmpVerification : System.Web.UI.Page
{
    string employeeID = "";
    string fullempID = "";
    string clientID = "";
    string vendorID = "";
    string jobID = "";
    string Email = "";
    string password = "";
    private bool startConversion = false;
    private bool identity = false;
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == true)
        {
            Email = empVere_mail.Text;
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                string strSql = " select ed.employee_id, concat('W', clt.client_alias, '00', right('0000' + convert(varchar(4), ed.employee_id), 4)) as employeesfull_id, " + 
                                " ea.client_id,ea.vendor_id,ea.job_id, dbo.CamelCase(ed.first_name + ' ' + ed.last_name) full_name " +
                                " from ovms_employee_details as ed " +
                                "  join ovms_employees as ea on ea.employee_id = ed.employee_id " +
                                " left join ovms_clients as clt on clt.client_id = ea.client_id" +
                                   " where ed.email ='" + Email + "'";
                SqlCommand cmd = new SqlCommand(strSql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        employeeID = reader["employee_id"].ToString();
                        fullempID = reader["employeesfull_id"].ToString();
                        clientID = reader["client_id"].ToString();
                        vendorID = reader["vendor_id"].ToString();
                        jobID = reader["job_id"].ToString();
                    }
                    identity = true;
                    lblMailAlert.Visible = false;
                }
                else
                {
                    lblMailAlert.Visible = true;
                    lblMailAlert.Text = "invalid email";

                }
                conn.Close();
                reader.Close();
                cmd.Dispose();
            }
        }  
}

    protected void btnemp_verfication_Click(object sender, EventArgs e)
    {
        if(identity == true)
        {
            startConversion = true;
        string fullname = empVerfull_Name.Value;
        send_info("candidate_name", fullname);
        string date_of_birth = empVerdob.Value;
        send_info("Date of birth", date_of_birth);
        string alias_name = empVermaid_Name.Value;
        send_info("alias name", alias_name);
        string email = empVere_mail.Text;
        send_info("email", email);
        string signature = empVerSig.Value;
        send_info("signature", signature);
        string date = empVerdate.Value;
        send_info("date", date);
        string phone = empVertele.Value;
        send_info("phone", phone);
        string hiring_manager = empVerhirimanager.Value;
        send_info("hiring manager", hiring_manager);
        string position_applied = empVerposition.Value;
        send_info("position applied", position_applied);
        string company_name1 = empVercomp_namefr41.Value;
        send_info("First company name", company_name1);
        string manager1 = empVermang_namefr41.Value;
        send_info("first manager", manager1);
        string position1 = empVerpositionfr41.Value;
        send_info("position in company1", position1);
        string salary1 = empVersalaryfr41.Value;
        send_info("salary in first compant", salary1);
        string manager_email1 = empVeremailfr41.Value;
        send_info("first company manager email", manager_email1);
        string company1_phone = empVerph_fr41.Value;

        send_info("first company phone", company1_phone);
        string manager_phone1 = empVerManPh_fr41.Value;
        send_info("first company manager phone", manager_phone1);
        string date_of_employement1 = empVerDOB_fr41.Value;
        send_info("first company employement date", date_of_employement1);
        string company_name2 = empVercomp_namefr42.Value;
        send_info("Second company name", company_name2);
        string manager2 = empVermang_namefr42.Value;
        send_info("Second manager", manager2);
        string position2 = empVerpositionfr42.Value;
        send_info("Position in company2", position2);
        string salary2 = empVersalaryfr42.Value;
        send_info("salary in second company", salary2);
        string manager_email2 = empVeremailfr42.Value;
        send_info("second company manager email", manager_email2);
        string company2_phone = empVerph_fr42.Value;
        send_info("second company phone", fullname);
        string manager_phone2 = empVerManPh_fr42.Value;
        send_info("second company manager phone ", manager_phone2);
        string date_of_employement2 = empVerDOB_fr42.Value;
        send_info("Second company employement date", date_of_employement2);
        string company_name3 = empVercomp_namefr43.Value;
        send_info("third company name", company_name3);
        string manager3 = empVermang_namefr43.Value;
        send_info("third manager", manager3);
        string position3 = empVerpositionfr43.Value;
        send_info("position in company3", position3);
        string salary3 = empVersalaryfr43.Value;
        send_info("salary in third company", salary3);
        string manager_email3 = empVeremailfr43.Value;
        send_info("third company manager email", manager_email3);
        string company3_phone = empVerph_fr43.Value;
        send_info("third company phone", company3_phone);
        string manager_phone3 = empVerManPh_fr43.Value;
        send_info("third company manager phone", manager_phone3);
        string date_of_employement3 = empVerDOB_fr43.Value;
        send_info("third company employement date", date_of_employement3);
        string company_name4 = empVercomp_namefr44.Value;
        send_info("fourth company name", company_name4);
        string manager4 = empVermang_namefr44.Value;
        send_info("fourth manager", manager4);
        string position4 = empVerpositionfr44.Value;
        send_info("position in company4", position4);
        string salary4 = empVersalaryfr44.Value;
        send_info("salary in fourth company", salary4);
        string manager_email4 = empVeremailfr44.Value;
        send_info("fourth company manager email", manager_email4);
        string company4_phone = empVerph_fr44.Value;
        send_info("fourth company phone", company4_phone);
        string manager_phone4 = empVerManPh_fr44.Value;
        send_info("fourth company manager phone", manager_phone4);
        string date_of_employement4 = empVerDOB_fr44.Value;
        send_info("fourth company employement date", date_of_employement4);
        string company_name5 = empVercomp_namefr45.Value;
        send_info("fifth company name", company_name5);
        string manager5 = empVermang_namefr45.Value;
        send_info("fifth manager", manager5);
        string position5 = empVerpositionfr45.Value;
        send_info("position in fifth company", position5);
        string salary5 = empVersalaryfr45.Value;
        send_info("salary in fifth company", salary5);
        string manager_email5 = empVeremailfr45.Value;
        send_info("fifth company manager email", manager_email5);
        string company5_phone = empVerph_fr45.Value;
        send_info("fifth company phone", company5_phone);
        string manager_phone5 = empVerManPh_fr45.Value;
        send_info("fifth company manager phone", manager_phone5);
        string date_of_employement5 = empVerDOB_fr45.Value;
        send_info("fifth company employement date", date_of_employement5);
        }
    }
    protected override void Render(HtmlTextWriter writer)
    {
        if (startConversion == true && identity == true)
        {
            TextWriter myWriter = new StringWriter();
            HtmlTextWriter htwOut = new HtmlTextWriter(myWriter);
            base.Render(htwOut);
            //sOut = sbOut.ToString();
            //Session["sOut"] = sOut;
            // Send sOut as an Email
            BackgroundApi.apiservice files = new BackgroundApi.apiservice(); //testlab.Text =

            if (Directory.Exists(Server.MapPath("~/BackGround/" + fullempID + "/")) == false)
            {
                DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/BackGround/" + fullempID + "/"));
            }

            string strpath = Server.MapPath("BackGround/" + fullempID + "/EmployeeVerification.pdf");
            files.pdf_convertor(myWriter.ToString(), strpath);
            //writer.Write(myWriter.ToString());
        }
        else
        {
            // render web page in browser
            base.Render(writer);
        }
    }
    public void send_info(string title, string value)
    {
        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
            string strSql = "select * from ovms_users where email_id='" + Email + "'";
            SqlCommand cmd = new SqlCommand(strSql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    password = reader["user_password"].ToString();
                }
            }
        }
        string field_name = title;
        string field_value = value;

        //localhost.Service web = new localhost.Service();
        XmlDocument dom11 = new XmlDocument();
        dom11.LoadXml(send_bgINFO_from_candidate(Email, password, field_name, field_value, employeeID, clientID, vendorID, "2", "emp_background", jobID).InnerXml);

        XmlNodeList Response34 = dom11.SelectNodes("XML/RESPONSE");
    }
    public XmlDocument send_bgINFO_from_candidate(string userEmailId, string userPassword, string field_name, string field_value, string employee_id, string client_id, string vendor_id, string form_id, string doc_title, string job_id)
    {
        SqlConnection conn;
        string xml_string = "";
        // logAPI.Service logService = new logAPI.Service();
        string errString = "";
        //errString = VerifyUser(userEmailId, userPassword);

        xml_string = "<XML>" +
                    "<REQUEST>" +


                         "<FIELD_NAME>" + field_name + "</FIELD_NAME>" +
                         "<FIELD_VALUE>" + field_value + "</FIELD_VALUE>" +
                        "<EMPLOYEE_ID>" + employee_id + "</EMPLOYEE_ID>" +
                        "<CLIENT_ID>" + client_id + "</CLIENT_ID>" +
                        "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +
                         "<FORM_ID>" + form_id + "</FORM_ID>" +
                         "<DOC_TITLE>" + doc_title + "</DOC_TITLE>" +



                    "</REQUEST>";
        xml_string += "<RESPONSE>";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        if (errString != "")
        {
            xml_string += "<ERROR>" + errString + "</ERROR>";
        }
        else
        {
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string strSql = " insert into ovms_background_check ( client_id, document_title, field_name,field_value,vendor_id, employee_id, form_id, job_id) " +
                                   "  values('" + client_id + "', '" + doc_title + "', '" + field_name + "', '" + field_value + "', '" + vendor_id + "', '" + employee_id + "','" + form_id + "','" + job_id + "')";

                    SqlCommand cmd = new SqlCommand(strSql, conn);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        xml_string += "<INSERT_STRING>Info inserted</INSERT_STRING>";
                    }
                    else
                    {
                        xml_string += "<INSERT_STRING><ERROR>Info not inserted</ERROR> </INSERT_STRING>";

                    }
                    cmd.Dispose();
                    conn.Close();

                }
            }

            catch (Exception ex)
            {
                xml_string += "<XML>" + "<STATUS>error:100.systemerror</STATUS>";


            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
        xml_string += "</RESPONSE>" +
                             "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }
}