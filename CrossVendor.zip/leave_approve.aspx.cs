﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class leave_approve : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string employee_id = Request.QueryString["empid"];
        string date= Request.QueryString["date"];
        // API.Service approve = new API.Service();
        API.Service confirm = new API.Service();
        XmlDocument _xmlDoc1 = new XmlDocument();
        _xmlDoc1.LoadXml("<XML>" + confirm.leave_conform(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id.ToString(),date.ToString(),"1").InnerXml + "</XML>");
        XmlNodeList ea = _xmlDoc1.SelectNodes("XML/RESPONSE");
        Response.Redirect("V_DayActivity.aspx");
        Response.End();
    }
}