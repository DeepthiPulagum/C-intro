﻿using System;
using System.Globalization;


public partial class Message_pmo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strMonthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(System.DateTime.Today.Month);
        lblDate.Text = System.DateTime.Today.Day.ToString() + " " + strMonthName;
    }

    protected void btnCancelEmail_Click(object sender, EventArgs e)
    {
        Response.Redirect("vendor.aspx");
    }
}