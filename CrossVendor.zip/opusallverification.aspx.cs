﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class opusallverification : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["empID"] != null)
        {
            //string empsID = Request["empID"].Substring(4, Request["empID"].Length - 4);
            string empsID = Request["empID"].ToString();
            try
            {

                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string strSql = "select * from ovms_background_verify_details where employee_id = '" + empsID + "' and emp_submitted_details = 1";
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if(reader.HasRows == true)
                    {
                        opusdisable.Visible = true;
                        opusenable.Visible = false;
                    }
                    reader.Close();
                    cmd.Dispose();
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
        }

    }
}