﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class opusReferenceVerify : System.Web.UI.Page
{
    string employeeID = "";
    string fullempID = "";
    string clientID = "";
    string vendorID = "";
    string jobID = "";
    string Email = "";
    string password = "";
    private bool startConversion = false;
    private bool identity = false;
    SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == true)
        {
            Email = candidemail.Text;

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                string strSql = " select ed.employee_id, concat('W', clt.client_alias, '00', right('0000' + convert(varchar(4), ed.employee_id), 4)) as employeesfull_id, " + 
                                " ea.client_id,ea.vendor_id,ea.job_id, dbo.CamelCase(ed.first_name + ' ' + ed.last_name) full_name " +
                                " from ovms_employee_details as ed " +
                                  "  join ovms_employees as ea on ea.employee_id = ed.employee_id " +
                                  "left join ovms_clients as clt on clt.client_id = ea.client_id" +
                                   " where ed.email ='" + Email + "'";
                SqlCommand cmd = new SqlCommand(strSql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        employeeID = reader["employee_id"].ToString();
                        fullempID = reader["employeesfull_id"].ToString();
                        clientID = reader["client_id"].ToString();
                        vendorID = reader["vendor_id"].ToString();
                        jobID = reader["job_id"].ToString();
                    }
                    identity = true;
                    lblMailAlerts.Visible = false;
                }
                else
                {
                    identity = false;
                    lblMailAlerts.Visible = true;
                    lblMailAlerts.Text = "invalid email";
                }
                conn.Close();
                reader.Close();
                cmd.Dispose();
            }
        }
    }

    protected void btnSendRefInfo_Click(object sender, EventArgs e)
    {
        if (identity == true)
        {
            startConversion = true;
            string candidate_name = candidName.Value;
            send_info("candidate_name", candidate_name);
            string candidate_phone = candidtele.Value;
            send_info("candidate_phone", candidate_phone);
            string email = candidemail.Text;
            send_info("email", email);
            string signature = cansign.Value;
            send_info("signature", signature);
            string date = candidDate.Value;
            send_info("date", date);
            string hiring_manager = candidManager.Value;
            send_info("hiring manager", hiring_manager);
            string position_applied_for = candidpos.Value;
            send_info("position applied for", position_applied_for);
            string reference1_name = refName1.Value;
            send_info("reference1 name", reference1_name);
            string company1_name = comName1.Value;
            send_info("company1 name", company1_name);
            string refernce1_title = reftit1.Value;
            send_info("refernce1 title", refernce1_title);
            string refernce1_phone = teleph1.Value;
            send_info("refernce phone", refernce1_phone);
            string refernce1_email = e_mail1.Value;
            send_info("refernce1 email", refernce1_email);
            string refernce1_date_of_emp = doe1.Value;
            send_info("refernce1 date of employement", refernce1_date_of_emp);
            string refernce1_phone2 = teleph12.Value;
            send_info("refernce1 phone2", refernce1_phone2);
            string reference2_name = refName2.Value;
            send_info("reference2 name", reference2_name);
            string company2_name = comName2.Value;
            send_info("company2 name", company2_name);
            string refernce2_title = reftit2.Value;
            send_info("refernce2 title", refernce2_title);
            string refernce2_phone = teleph2.Value;
            send_info("refernce2 phone", refernce2_phone);
            string refernce2_email = e_mail2.Value;
            send_info("refernce2 email", refernce2_email);
            string refernce2_date_of_emp = doe2.Value;
            send_info("refernce2 date of employement", refernce2_date_of_emp);
            string refernce2_phone2 = teleph22.Value;
            send_info("refernce2 phone2", refernce2_phone2);
            string reference3_name = refName3.Value;
            send_info("reference3 name", reference3_name);
            string company3_name = comName3.Value;
            send_info("company3 name", company3_name);

            string refernce3_title = reftit3.Value;
            send_info("refernce3 title", refernce3_title);
            string refernce3_phone = teleph3.Value;
            send_info("refernce3 phone", refernce3_phone);
            string refernce3_email = e_mail3.Value;
            send_info("Fullname", refernce3_phone);
            string refernce3_date_of_emp = doe3.Value;
            send_info("refernce3 date of employement", refernce3_date_of_emp);
            string refernce3_phone2 = teleph32.Value;
            send_info("refernce3 phone2", refernce3_phone2);
            string reference4_name = refName4.Value;
            send_info("reference4 name", reference4_name);
            string company4_name = comName4.Value;
            send_info("company4 name", company4_name);
            string refernce4_title = reftit4.Value;
            send_info("refernce4 title", refernce4_title);
            string refernce4_phone = teleph4.Value;
            send_info("refernce4 phone", refernce4_phone);
            string refernce4_email = e_mail4.Value;
            send_info("refernce4 email", refernce4_email);
            string refernce4_date_of_emp = doe4.Value;
            send_info("refernce4 date of employement", refernce4_date_of_emp);
            string refernce4_phone2 = teleph42.Value;
            send_info("refernce4 phone2", refernce4_phone2);
            string reference5_name = refName5.Value;
            send_info("reference5 name", reference5_name);
            string company5_name = comName5.Value;
            send_info("company5 name", company5_name);
            string refernce5_title = reftit5.Value;
            send_info("refernce5 title", refernce5_title);
            string refernce5_phone = teleph5.Value;
            send_info("refernce5 phone", refernce5_phone);
            string refernce5_email = e_mail5.Value;
            send_info("refernce5 email", refernce5_email);
            string refernce5_date_of_emp = doe5.Value;
            send_info("refernce5 date of employement", refernce5_date_of_emp);
            string refernce5_phone2 = teleph52.Value;
            send_info("refernce5 phone2", refernce5_phone2);

            try
            {

                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string strSql = "update ovms_background_verify_details set emp_submitted_details = 1, emp_submitted_date = '" + DateTime.Now + "' where employee_id='" + employeeID + "'";

                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Close();
                    cmd.Dispose();
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
        }
    }
    protected override void Render(HtmlTextWriter writer)
    {
        if (startConversion == true && identity == true)
        {
            TextWriter myWriter = new StringWriter();
            HtmlTextWriter htwOut = new HtmlTextWriter(myWriter);
            base.Render(htwOut);
            //sOut = sbOut.ToString();
            //Session["sOut"] = sOut;
            // Send sOut as an Email
            BackgroundApi.apiservice files = new BackgroundApi.apiservice(); //testlab.Text =

            if (Directory.Exists(Server.MapPath("~/BackGround/" + fullempID + "/")) == false)
            {
                DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/BackGround/" + fullempID + "/"));
            }

            string strpath = Server.MapPath("BackGround/" + fullempID + "/ReferenceVerification.pdf");
            files.pdf_convertor(myWriter.ToString(), strpath);
           // writer.Write(myWriter.ToString());
        }
        else
        {
            // render web page in browser
            base.Render(writer);
        }
    }
    public void send_info(string title, string value)
    {
        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();
            string strSql = "select * from ovms_users where email_id='" + Email + "'";
            SqlCommand cmd = new SqlCommand(strSql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    password = reader["user_password"].ToString();
                }
            }
            conn.Close();
            reader.Close();
            cmd.Dispose();
        }
        string field_name = title;
        string field_value = value;
        if (field_name != "" && field_value != "")
        {
            XmlDocument dom11 = new XmlDocument();
            dom11.LoadXml(send_bgINFO_from_candidate(Email, password, field_name, field_value, employeeID, clientID, vendorID, "3", "Ref_background", jobID).InnerXml);

            XmlNodeList Response34 = dom11.SelectNodes("XML/RESPONSE");
        }
    }
    public XmlDocument send_bgINFO_from_candidate(string userEmailId, string userPassword, string field_name, string field_value, string employee_id, string client_id, string vendor_id, string form_id, string doc_title, string job_id)
    {
        SqlConnection conn;
        string xml_string = "";
        // logAPI.Service logService = new logAPI.Service();
        string errString = "";
        //errString = VerifyUser(userEmailId, userPassword);

        xml_string = "<XML>" +
                    "<REQUEST>" +


                         "<FIELD_NAME>" + field_name + "</FIELD_NAME>" +
                         "<FIELD_VALUE>" + field_value + "</FIELD_VALUE>" +
                        "<EMPLOYEE_ID>" + employee_id + "</EMPLOYEE_ID>" +
                        "<CLIENT_ID>" + client_id + "</CLIENT_ID>" +
                        "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +
                         "<FORM_ID>" + form_id + "</FORM_ID>" +
                         "<DOC_TITLE>" + doc_title + "</DOC_TITLE>" +



                    "</REQUEST>";
        xml_string += "<RESPONSE>";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        if (errString != "")
        {
            xml_string += "<ERROR>" + errString + "</ERROR>";
        }
        else
        {
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string strSql = " insert into ovms_background_check ( client_id, document_title, field_name,field_value,vendor_id, employee_id, form_id, job_id) " +
                                   "  values('" + client_id + "', '" + doc_title + "', '" + field_name + "', '" + field_value + "', '" + vendor_id + "', '" + employee_id + "','" + form_id + "','" + job_id + "')";

                    SqlCommand cmd = new SqlCommand(strSql, conn);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        xml_string += "<INSERT_STRING>Info inserted</INSERT_STRING>";
                    }
                    else
                    {
                        xml_string += "<INSERT_STRING><ERROR>Info not inserted</ERROR> </INSERT_STRING>";

                    }
                    cmd.Dispose();
                    conn.Close();

                }
            }

            catch (Exception ex)
            {
                xml_string += "<XML>" + "<STATUS>error:100.systemerror</STATUS>";


            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
        xml_string += "</RESPONSE>" +
                             "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }
}