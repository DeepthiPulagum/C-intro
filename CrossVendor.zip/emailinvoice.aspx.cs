﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class emailinvoice : System.Web.UI.Page
{
    private int iResponse;
    StringFunctions func = new StringFunctions();
    emailFunctions semail = new emailFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {
        string job_id_get = "";
        string date_from_get = "";
        string name_get = "";
        string date_to_get = "";
        string full_job_id = "";
        string hours_get = "";
        DateTime from_date = DateTime.Parse(Request.QueryString["fromdate"].ToString());
        DateTime to_date = DateTime.Parse(Request.QueryString["todate"].ToString());
        API.Service jobInfo = new API.Service();
        XmlDocument xmldoc = new XmlDocument();
      
        xmldoc.LoadXml("<XML>" + jobInfo.get_from_and_to_date(Session["Email"].ToString(), Session["P@ss"].ToString(),"1",Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/STATUS");
      
            hours_get = Response[iResponse].SelectSingleNode("HOURS").InnerText;
            job_id_get = Response[iResponse].SelectSingleNode("JOB_ID").InnerText;
             date_from_get = DateTime.Parse(Response[iResponse].SelectSingleNode("FROM_DATE").InnerText).ToString("dd MMM, yyyy");
            date_to_get = DateTime.Parse(Response[iResponse].SelectSingleNode("TO_DATE").InnerText).ToString("dd MMM, yyyy");
            name_get = func.FixString(Response[iResponse].SelectSingleNode("FIRST_NAME").InnerText) + " " + func.FixString(Response[iResponse].SelectSingleNode("LAST_NAME").InnerText);
      
        xmldoc.LoadXml("<XML>" + jobInfo.get_job_alias(Session["Email"].ToString(), Session["P@ss"].ToString(), job_id_get).InnerXml + "</XML>");

        XmlNodeList Response1 = xmldoc.SelectNodes("XML/RESPONSE");
       full_job_id = Response1.Item(0).SelectSingleNode("JOB_ALIAS").InnerText;
        

        if (Between(DateTime.Today.Date, from_date, to_date) != true)
        {
            semail.sendEmail("janalpatel37@gmail.com", "INVOICE SUBMITTED[Worker Name: "+ name_get + "Job ID: "+ full_job_id + ",NVOICE DATE FROM: "+ date_from_get+",INVOICE DATE TO: "+ date_to_get,
                            "<br>Invoice has been submitted to the Buyer."+
                            "<br>Details:"+

                            "<br><br>Invoice Submit Date" +
                            "<br>"+ (DateTime.Today.Date).ToString("dd MMM, yyyy") +

                            "<br><br>Invoice for:" +
                            "<br>"+ date_from_get + " -"+ date_to_get +

                            "<br><br>Requisition ID" +
                            "<br>"+ full_job_id +


                            "<br><br>Worker Name" +
                            "<br>" + name_get +

                            "<br><br>Number of Hours:" +
                            "<br>"+ hours_get+
                            "<br>" +
                            "<br>This notification was sent by FlentisPRO.If you have any questions regarding this notice," +
                            "<br>please contact the SAP Fieldglass Helpdesk at:" +
                            "<br>mailto:helpdesk@oveems.com" +
                            "<br>By Phone:" +
                            "<br>US(toll free) 1 800 123 1234" +
                            "<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");
           
        }

    }
    public static bool Between(DateTime input, DateTime date1, DateTime date2)
    {
        return (input >= date1 && input <= date2);
    }
}