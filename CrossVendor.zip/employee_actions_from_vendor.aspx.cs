﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class employee_actions_from_vendor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string employee_id = (Request.QueryString["empid"].Substring(Request.QueryString["empid"].Length - 6));
        // API.Service approve = new API.Service();
        API.Service int_confirm = new API.Service();
        XmlDocument _xmlDoc1 = new XmlDocument();
        //_xmlDoc1.LoadXml("<XML>" + int_confirm.interview_status(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id.ToString(), "1").InnerXml + "</XML>");
        XmlNodeList ea = _xmlDoc1.SelectNodes("XML/RESPONSE");
        Response.Redirect("Vendor.aspx");
    }
}