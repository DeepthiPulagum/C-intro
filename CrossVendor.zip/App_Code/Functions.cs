﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Functions
/// </summary>
public class Functions
{
    HttpContext httpContext = HttpContext.Current;
    public Functions()
    {
        //
        // TODO: Add constructor logic here
        //
        //Check if Session is there or not.
        CheckSession();


    }
    public void CheckSession()
    {
        if (httpContext.ApplicationInstance.Session["UserID"] == null)
        {
            httpContext.ApplicationInstance.Session.Abandon();
            httpContext.Response.Redirect("Login.aspx?m=You+have+logged+out");
            httpContext.Response.End();
        }
    }
   
}