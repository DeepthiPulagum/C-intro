﻿using System;
using System.Xml;
using System.IO;
using System.Web;

public partial class Job_Details : System.Web.UI.Page
{
    public string canPhoto { get; set; }
    public string canResume { get; set; }
    string fileExtension = "";
    string UniqueDateTime = "";

    StringFunctions func = new StringFunctions();
    private int iResponse;
    private int intCount1;
    DateTime comp_end_date;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string a = "";
        }
        //following code is for retreiving comment in the ribbon from client to vendor
        string cJOB_ID = (Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 5));
        API.Service addcmnt = new API.Service();
        XmlDocument commments = new XmlDocument();
        commments.LoadXml("<XML>" + addcmnt.get_client_job_comment(Session["Email"].ToString(), Session["P@ss"].ToString(), cJOB_ID).InnerXml + "</XML>");
        XmlNodeList Response12 = commments.SelectNodes("XML/RESPONSE/COMMENT_ID");
        string previous_commnt = "";

        for (int iResponse1 = 0; iResponse1 < Response12.Count; iResponse1++)
        {
            previous_commnt = Server.HtmlDecode(previous_commnt + "\n" + "(" + Response12[iResponse1].SelectSingleNode("CLIENT_COMMENT_TIME").InnerText + "):  " + (Response12[iResponse1].SelectSingleNode("CLIENT_JOB_COMMENT").InnerText));

        }

        Txtarea_client_comment.Value = previous_commnt;
        //upper code is for retreiving comment in the ribbon from client to vendor

        int jobID = 0;
        if (Request.QueryString["jobID"] != "")
        {
            if (Request.QueryString["jobID"].ToString().Length > 2)
                jobID = Int32.Parse(Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 5));
        }
        API.Service jobDetails = new API.Service();
        XmlDocument _xjobDetails = new XmlDocument();
        _xjobDetails.LoadXml("<XML>" + jobDetails.get_Jobs(Convert.ToString(jobID), Session["Email"].ToString(), Session["P@ss"].ToString(), Session["VendorID"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        // _xjobDetails.LoadXml("<XML>" + jobDetails.get_Jobs("2", "srinivas.gadde@pamten.ca", "ferivan").InnerXml + "</XML>");
        string _Error = "";
        try
        {
            _Error = _xjobDetails.SelectSingleNode("XML/RESPONSE/ERROR").InnerText;
            //_xUserInfo.SelectNodes("XML/RESPONSE/JOB_NO")
        }
        catch (Exception ex)
        {
            _Error = "";
        }
        XmlNodeList Response2 = _xjobDetails.SelectNodes("XML/RESPONSE/JOBS");
        //social media
        lblfacebook.Text = "<a href='https://www.facebook.com/sharer/sharer.php?u=http%3A//www.flentispro.com/(S(xpo23hjr3nn2xirznt5wwz55))/social_media_job_view.aspx?jobID=" + Request.QueryString["jobID"] + "' class='fa fa-fw fa-facebook' target='_blank'></a>";
        lbllinkedin.Text = "<a href='https://www.linkedin.com/shareArticle?mini=true&url=http%3A//www.flentispro.com/(S(xpo23hjr3nn2xirznt5wwz55))/social_media_job_view.aspx?jobID=&title=&summary=&source=" + Request.QueryString["jobID"] + " 'class='fa fa-fw fa-linkedin'   target='_blank'></a>";
        lbltwitter.Text = "<a href='https://twitter.com/home?status=http%3A//www.flentispro.com/(S(xpo23hjr3nn2xirznt5wwz55))/social_media_job_view.aspx?jobID=" + Request.QueryString["jobID"] + "' class='fa fa-fw fa-twitter'  target='_blank'></a>";
        //int CountRows = 1;
        string _Job_Description = "";
        string _Job_Title = "";
        string _No_Of_Opennings = "";
        string _DepartmentName = "";
        string _ClientName = "";
        string _Job_Position_Type = "";
        string _Job_Posting_Start_Date = "";
        string _Job_Posting_End_Date = "";
        string _Job_Location = "";
        string _Hours_Per_Day = "";
        string _Hiring_Manager = "";
        string _Job_Currency = "";
        string _Job_TimeZone = "";
        string _Contract_Start_Date = "";
        string _Contract_End_Date = "";
        string _Max_submittion = "";
        string _ReasonForOpen = "";
        string _Urgent = "";
        string _PayRate = "";
        string _comments = "";
       DateTime thisday = (DateTime.Now);
      

        for (int intCount = 0; intCount < Response2.Count; intCount++)
        {
            _Job_Description = Response2[intCount].SelectSingleNode("JOB_DESC").InnerText;
            _Job_Title = func.FixString(Server.HtmlDecode(Response2[intCount].SelectSingleNode("JOB_TITLE").InnerText));
            _No_Of_Opennings = Response2[intCount].SelectSingleNode("NO_OF_OPENINGS").InnerText;
            _DepartmentName = Response2[intCount].SelectSingleNode("DEPARTMENT_NAME").InnerText;
            _ClientName = Response2[intCount].SelectSingleNode("CLIENT_NAME").InnerText;
            _Job_Position_Type = Response2[intCount].SelectSingleNode("JOB_POSITION_TYPE").InnerText;
            _Job_Posting_Start_Date = DateTime.Parse(Response2[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("MMMM dd, yyyy");
            _Job_Posting_End_Date = DateTime.Parse(Response2[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("MMMM dd, yyyy");
            _Job_Location = Response2[intCount].SelectSingleNode("JOB_LOCATION").InnerText;
            _Hours_Per_Day = Response2[intCount].SelectSingleNode("HOURS_PER_DAY").InnerText;
            _Hiring_Manager = Response2[intCount].SelectSingleNode("HIRING_MANAGER_NAME").InnerText;
            _Job_Currency = Response2[intCount].SelectSingleNode("JOB_CURRENCY").InnerText;
            _Contract_Start_Date = Response2[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText;
            _Contract_End_Date = Response2[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText;
            _Job_TimeZone = Response2[intCount].SelectSingleNode("JOB_TIMEZONE").InnerText;
            _Max_submittion = Response2[intCount].SelectSingleNode("MAX_SUBMISSION_PER_SUPPLIER").InnerText;
            _ReasonForOpen = Response2[intCount].SelectSingleNode("REASON_FOR_OPEN").InnerText;
            _Urgent = Response2[intCount].SelectSingleNode("URGENT").InnerText;
            _PayRate = Response2[intCount].SelectSingleNode("STD_PAY_RATE").InnerText;
            _comments = Response2[intCount].SelectSingleNode("COMMENTS").InnerText;
             comp_end_date = DateTime.Parse(Response2[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);

        }
        if (_Urgent == "1")
        {
            lblUrgent.Text = "<blink>(Urgent Request)</blink>";
        }
        DateTime dt = Convert.ToDateTime(_Job_Posting_Start_Date);
        DateTime dtt = Convert.ToDateTime(_Job_Posting_End_Date);
        //lblPostingDate.Text = dt.ToString("dddd, dd MMMM yyyy HH:mm:ss").Replace("00:00:00", "");
        lbljobtitle.Text = _Job_Title;
        lblJobDescription.Text = Server.HtmlDecode(_Job_Description);
        lblpositiontype.Text = _Job_Position_Type;

        if (_comments == "")
        {
            lblcomments.Text = "N/A";
        }
        else
        {
            lblcomments.Text = _comments;
        }


        // API.Service web3 = new API.Service();
        API.Service web3 = new API.Service();
        XmlDocument dom3 = new XmlDocument();
        dom3.LoadXml("<XML>" + web3.get_Jobs(jobID.ToString(), Session["Email"].ToString(), Session["P@ss"].ToString(), Session["VendorID"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response8 = dom3.SelectNodes("XML/RESPONSE/JOBS ");

        lblnoofopning.Text = Response8[iResponse].SelectSingleNode("NO_OF_OPENINGS").InnerText;
        lblstartdate.Text = DateTime.Parse(Response8[iResponse].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy");
        if (comp_end_date <= thisday) { lblenddate.Text = "Permanent Position"; }
        else
        {
            lblenddate.Text = DateTime.Parse(Response8[iResponse].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy");
        }
            lblUrgent.Text = Response8[iResponse].SelectSingleNode("URGENT").InnerText;
        lbljobtitle.Text = func.FixString(Response8[iResponse].SelectSingleNode("JOB_TITLE").InnerText);
        lbljobtitle.Text = func.FixString(Server.HtmlDecode(Response8[iResponse].SelectSingleNode("JOB_TITLE").InnerText));
        lbllocation2.Text = Response8[iResponse].SelectSingleNode("JOB_LOCATION").InnerText;
        lblbill.Text = Response8[iResponse].SelectSingleNode("STD_BILL_RATE").InnerText;
        lbladdress2.Text = Response8[iResponse].SelectSingleNode("ADDRESS1").InnerText;
        lblpay2.Text = Response8[iResponse].SelectSingleNode("STD_PAY_RATE").InnerText;
        lbllocation.Text = Response8[iResponse].SelectSingleNode("JOB_LOCATION").InnerText;
        lbladdres.Text = Response8[iResponse].SelectSingleNode("ADDRESS1").InnerText;
        lblsalary.Text = Response8[iResponse].SelectSingleNode("BASE_SALARY").InnerText;
        lbllocation3.Text = Response8[iResponse].SelectSingleNode("JOB_LOCATION").InnerText;
        lbladdress3.Text = Response8[iResponse].SelectSingleNode("ADDRESS1").InnerText;

        if (lblpay2.Text == "" || lblpay2.Text == "0" && (lblbill.Text == "" || lblbill.Text == "0") && (lblsalary.Text != "" || lblsalary.Text != "0"))
        //  if (z == "0" && p != "0" && q == "0")
        {
            y.Visible = false;
            x.Visible = false;
            w.Visible = true;

        }
        else if (lblbill.Text == null || lblbill.Text == "0" && (lblpay2.Text != null || lblpay2.Text != "0") && (lblsalary.Text == "" || lblsalary.Text == "0"))
        // else if (z != "0" && p == "0" && q == "0")
        {
            y.Visible = false;
            x.Visible = true;
            w.Visible = false;
        }
        else
        {
            x.Visible = false;
            y.Visible = true;
            w.Visible = false;
        }
        if (lblUrgent.Text == "1")
        {
            lblUrgent.Text = "<blink>(Urgent Request)</blink>";
        }
        else
        {
            lblUrgent.Text = "";
        }


        //stars 
        API.Service web1 = new API.Service();
        // API.Service web1 = new API.Service();
        XmlDocument dom2 = new XmlDocument();
        //  int jobID = 0;

        //string strID = Request.QueryString["ID"];
        dom2.LoadXml("<XML>" + web1.get_jobrating(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString()).InnerXml + "</XML>");
        XmlNodeList Response3 = dom2.SelectNodes("XML/RESPONSE/QUESTIONS_NO ");

        //API.Service web1 = new API.Service();
        //XmlDocument dom2 = new XmlDocument();
        ////string strID = Request.QueryString["ID"];
        //dom2.LoadXml("<XML>" + web1.get_rating_with_jobid(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString()).InnerXml + "</XML>");
        //XmlNodeList Response3 = dom2.SelectNodes("XML/RESPONSE/QUESTIONS_NO");

        string que1 = "";
        string que2 = "";
        string que3 = "";
        string que4 = "";
        string que5 = "";
        string rating1 = "";
        string rating2 = "";
        string rating3 = "";
        string rating4 = "";
        string rating5 = "";
        try
        {
            que1 = Server.HtmlDecode(Response3[intCount1].SelectSingleNode("QUESTION1").InnerText);
            que2 = Response3[intCount1].SelectSingleNode("QUESTION2").InnerText;
            que3 = Response3[intCount1].SelectSingleNode("QUESTION3").InnerText;
            que4 = Response3[intCount1].SelectSingleNode("QUESTION4").InnerText;
            que5 = Response3[intCount1].SelectSingleNode("QUESTION5").InnerText;
            rating1 = Response3[intCount1].SelectSingleNode("RATING1").InnerText;
            rating2 = Response3[intCount1].SelectSingleNode("RATING2").InnerText;
            rating3 = Response3[intCount1].SelectSingleNode("RATING3").InnerText;
            rating4 = Response3[intCount1].SelectSingleNode("RATING4").InnerText;
            rating5 = Response3[intCount1].SelectSingleNode("RATING5").InnerText;
        }
        catch (Exception ex)
        {

        }
        if (que1 == "")
        {
            divstar.Visible = false;
        }
        else
        {
            divstar.Visible = true;
        }
        lblque1.Text = que1;
        labque2.Text = que2;
        lblque3.Text = que3;
        lblque4.Text = que4;
        lblque5.Text = que5;
        txtRating1.Text = rating1;
        txtRating2.Text = rating2;
        txtRating3.Text = rating3;
        txtRating4.Text = rating4;
        txtRating5.Text = rating5;

        string sTable = "<tbody>";
        API.Service web = new API.Service();
        XmlDocument dom1 = new XmlDocument();
        //string strID = Request.QueryString["ID"];
        dom1.LoadXml("<XML>" + web.get_candiate_for_that_particuler_job(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString(), Session["VendorID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response1 = dom1.SelectNodes("XML/RESPONSE/EMPLOYEE_NO");
        sTable = "";
        for (int iResponse2 = 0; iResponse2 < Response1.Count; iResponse2++)
        {
            sTable = sTable + "<tr>";
            sTable = sTable + "<td><a class='btn btn-danger btn-xs' data-toggle='tooltip' data-placement='top' name='abc' title='Edit Candidate ' href='Edit_Worker.aspx?empid=" + Response1[iResponse2].SelectSingleNode("EMPLOYEE_ID").InnerText + "&jobId=" + Request.QueryString["jobID"] + "'>Edit</a> </td> ";
            sTable = sTable + "<td>" + DateTime.Parse(Response1[iResponse2].SelectSingleNode("SUBMIT_DATE").InnerText).ToString("MMMM dd, yyyy") + " </TD>";
            sTable = sTable + "<td>" + Response1[iResponse2].SelectSingleNode("FIRST_NAME").InnerText + " " + Response1[iResponse2].SelectSingleNode("LAST_NAME").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse2].SelectSingleNode("EMAIL").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse2].SelectSingleNode("LOCATION").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse2].SelectSingleNode("STATUS").InnerText + " </td> ";
            sTable = sTable + "<td>$" + Response1[iResponse2].SelectSingleNode("PAY_RATE").InnerText + " Per Hour </td> ";
            string resume = Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText;
            string resuepath = "";
            if (Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText != "")
            {
                resume = Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText;
                resuepath = Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText.Substring(Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText.IndexOf("Resume\\"), Convert.ToInt32(Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText.Length) - Convert.ToInt32(Response1[iResponse2].SelectSingleNode("RESUME_PATH").InnerText.IndexOf("Resume\\"))).Replace("\\", "//").ToString();

            }
            if (resuepath == "")
                sTable = sTable + "<td>Resume </td> ";
            else
                sTable = sTable + "<td><a href='http://" + HttpContext.Current.Request.Url.Host + "/" + resuepath.Replace("//", "/") + "'>Resume</a></td>";
                //sTable = sTable + "<td><a href='http://www.flentispro.com/" + resuepath.Replace("//", "/") + "'>Resume</a> </td> ";
            sTable = sTable + "</tr>";
            string a = "";
        }
        sTable = sTable + "</tbody>";
        web.Dispose();
        lblTableData.Text = sTable;
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("Add_Worker.aspx?wopen=Y&p=AW&jobID=" + Request.QueryString["jobID"]);
    }
}