﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Edit_Worker : System.Web.UI.Page
{
    public string DOBValue = String.Empty;
    public string availableDate = String.Empty;
    public string canPhoto { get; set; }
    public string canResume { get; set; }
    string fileExtension = "";
    string UniqueDateTime = "";
    private int iResponse;
    private int intCount1;
    private SqlConnection conn;
    string sCountry = "";
    StringFunctions func = new StringFunctions();
    emailFunctions semail = new emailFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        btnupdate.Enabled = true;
        if ((Request.Form["ctl00$MainContent$txtemail"] != null) && (Request.Form["ctl00$MainContent$txtemail"] != ""))
        {
            if (CheckCandidateDup(Request.Form["ctl00$MainContent$txtemail"]) == "YES")
            {
                lblDuplicate.Text = "This candidate already exists, please submit someone else";
                btnupdate.Enabled = false;
            }
            else
            {
                lblDuplicate.Text = "";

            }
        }

        if (!Page.IsPostBack)
        {
            //Loadcountry();
            Loadstate();


            XmlDocument xmldoc = new XmlDocument();
            API.Service MessageList = new API.Service();
            //  API1.Service MessageList1 = new API1.Service();
            /* try code */
            if (Request.QueryString["preview"] != "view")
                xmldoc.LoadXml("<XML>" + MessageList.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), Request.QueryString["empid"], Session["VendorID"].ToString(), "", "", "", "1", "").InnerXml + "</XML>");
            else
            {
                btnGoBack.Style.Add("display", "none");
                xmldoc.LoadXml("<XML>" + MessageList.get_employees_for_preview(Session["Email"].ToString(), Session["P@ss"].ToString(), Request.QueryString["empid"], Session["VendorID"].ToString(), "", "", "", "1", "").InnerXml + "</XML>");
            }
            /* try code */
            XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
            string firstname = Response[iResponse].SelectSingleNode("FIRSTNAME").InnerText;
            string middlename = Response[iResponse].SelectSingleNode("MIDDLE_NAME").InnerText;
            string lastname = Response[iResponse].SelectSingleNode("LASTNAME").InnerText;
            string email = Response[iResponse].SelectSingleNode("EMAIL").InnerText;
            string phone = Response[iResponse].SelectSingleNode("PHONE").InnerText;
            string dob = Response[iResponse].SelectSingleNode("DATE_OF_BIRTH").InnerText;
            string suitno = Response[iResponse].SelectSingleNode("SUITE_NO").InnerText;
            string address1 = Response[iResponse].SelectSingleNode("ADDRESS1").InnerText;
            string city = Response[iResponse].SelectSingleNode("CITY").InnerText;
            string country = Response[iResponse].SelectSingleNode("COUNTRY").InnerText;
            string postal = Response[iResponse].SelectSingleNode("POSTAL").InnerText;
            string province = Response[iResponse].SelectSingleNode("PROVINCE").InnerText;
            string comment = Response[iResponse].SelectSingleNode("COMMENTS").InnerText;
            string available = Response[iResponse].SelectSingleNode("AVAILABILITY_FOR_INTERVIEW").InnerText;
            string skype = Response[iResponse].SelectSingleNode("SKYPE").InnerText;
            string licence = Response[iResponse].SelectSingleNode("LICENCE_NO").InnerText;
            string lsatsin = Response[iResponse].SelectSingleNode("LAST_4_DIGITS_OF_SSN_SIN").InnerText;
            string pay = Response[iResponse].SelectSingleNode("PAY_RATE").InnerText;
            //  string job = Response[iResponse].SelectSingleNode("JOB_TITLE").InnerText +"-"+ Response[iResponse].SelectSingleNode("JOB_ID").InnerText;
            txtfistname.Value = firstname;
            txtmiddle.Value = middlename;
            txtlastname.Value = lastname;
            txtemail.Text = email;
            txtphone.Value = phone;
            DOBValue = dob;
            txtsuite.Value = suitno;
            txtaddress1.Value = address1;
            txtstdpayf.Value = pay;
            txtcity.Value = city;
          //  dd.Text = country;
            txtpostal.Value = postal;
            ddlprivince.Text = province;
            txtcomment.Value = comment;
            availableDate = available;
            txtskype.Value = skype;
            txtlicence.Value = licence;
            txtsinnumber.Value = lsatsin;
            // ddljobs.Text = job;
            API.Service web1 = new API.Service();
            XmlDocument dom2 = new XmlDocument();
            int jobID = 0;
            if (Request.QueryString["jobID"] != "")
            {
                jobID = Int32.Parse(Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 5));
            }
            dom2.LoadXml("<XML>" + web1.get_jobrating(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString()).InnerXml + "</XML>");
            XmlNodeList Response3 = dom2.SelectNodes("XML/RESPONSE/QUESTIONS_NO ");
            string que1 = "";
            string que2 = "";
            string que3 = "";
            string que4 = "";
            string que5 = "";
            string rating1 = "";
            string rating2 = "";
            string rating3 = "";
            string rating4 = "";
            string rating5 = "";
            string emprating1 = "";
            string emprating2 = "";
            string emprating3 = "";
            string emprating4 = "";
            string emprating5 = "";
            try
            {
                //que1 = Server.HtmlDecode(Response3[intCount1].SelectSingleNode("QUESTION1").InnerText);
                que1 = Server.HtmlDecode(Response3[intCount1].SelectSingleNode("QUESTION1").InnerText);
                que2 = Response3[intCount1].SelectSingleNode("QUESTION2").InnerText;
                que3 = Response3[intCount1].SelectSingleNode("QUESTION3").InnerText;
                que4 = Response3[intCount1].SelectSingleNode("QUESTION4").InnerText;
                que5 = Response3[intCount1].SelectSingleNode("QUESTION5").InnerText;
                rating1 = Response3[intCount1].SelectSingleNode("RATING1").InnerText;
                rating2 = Response3[intCount1].SelectSingleNode("RATING2").InnerText;
                rating3 = Response3[intCount1].SelectSingleNode("RATING3").InnerText;
                rating4 = Response3[intCount1].SelectSingleNode("RATING4").InnerText;
                rating5 = Response3[intCount1].SelectSingleNode("RATING5").InnerText;

                dom2.LoadXml("<XML>" + web1.get_emprating(Session["Email"].ToString(), Session["P@ss"].ToString(), Request.QueryString["empid"].ToString()).InnerXml + "</XML>");
                XmlNodeList Response33 = dom2.SelectNodes("XML/RESPONSE/QUESTIONS_NO ");


                try
                {
                    //que1 = Server.HtmlDecode(Response3[intCount1].SelectSingleNode("QUESTION1").InnerText);
                    emprating1 = Response33[iResponse].SelectSingleNode("RATING1").InnerText;
                    emprating2 = Response33[iResponse].SelectSingleNode("RATING2").InnerText;
                    emprating3 = Response33[iResponse].SelectSingleNode("RATING3").InnerText;
                    emprating4 = Response33[iResponse].SelectSingleNode("RATING4").InnerText;
                    emprating5 = Response33[iResponse].SelectSingleNode("RATING5").InnerText;


                }
                catch (Exception ex)
                {
                    //nothing
                    //que1 = "";
                }


            }
            catch (Exception ex)
            {
                //nothing
                //que1 = "";
            }
            if (que1 == "")
            {
                divstar.Visible = false;
            }
            else
            {
                divstar.Visible = true;
            }


            lblque1.Text = que1;
            labque2.Text = que2;
            lblque3.Text = que3;
            lblque4.Text = que4;
            lblque5.Text = que5;
            txtRating1.Text = rating1;
            txtRating2.Text = rating2;
            txtRating3.Text = rating3;
            txtRating4.Text = rating4;
            txtRating5.Text = rating5;
            txtemprating1.Text = emprating1;
            txtemprating2.Text = emprating2;
            txtemprating3.Text = emprating3;
            txtemprating4.Text = emprating4;
            txtemprating5.Text = emprating5;

        }
    }
    public string CheckCandidateDup(string email)
    {

        //select employee_ID from ovms_employees where job_id = 5 and user_id = 20
        string _SCandDup = "NO";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                // Session["JobID"] = jobID.ToString();

                //start, end and weeks
                string sqlGetDup = " select count(*) as DUP from ovms_users where email_id = '" + email + "' and Vendor_id = '" + Session["VendorID"].ToString() + "' ";
                SqlCommand cmdGetDup = new SqlCommand(sqlGetDup, conn);
                SqlDataReader rsGetDup = cmdGetDup.ExecuteReader();
                //string _svendorList = "";
                while (rsGetDup.Read())
                {
                    if (rsGetDup["DUP"].ToString() != "0")
                    {
                        _SCandDup = "YES";
                    }
                    //Session["EmployeeIDForJob"] = rsGetEmployeeID["employee_ID"].ToString();
                    //_sArrayString = rsStartEndWeeks["contract_Start_date"].ToString() + "," + rsStartEndWeeks["contract_end_date"].ToString() + "," + rsStartEndWeeks["Num_weeks"].ToString();

                }
                rsGetDup.Close();
                cmdGetDup.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _SCandDup;
    }
    private void Loadstate()
    {
        DataTable dt = new DataTable();
        API.Service web = new API.Service();
        XmlDocument xDoc = new XmlDocument();
        xDoc.LoadXml("<XML>" + web.get_state(Session["Email"].ToString(), Session["P@ss"].ToString(), "").InnerXml + "</XML>");
        XmlNodeList xResponse = xDoc.SelectNodes("XML/RESPONSE/STATE_NO ");
        dt.Columns.Add("STATE_CODE", typeof(string));
        dt.Columns.Add("STATE_ID", typeof(string));

        string sVar = "";
        string sUS = "";
        foreach (XmlNode node in xResponse)
        {
            DataRow dr = dt.NewRow();


            if (node["COUNTRY_ID"].InnerText == "2")
                sVar = "United States";

            if (node["COUNTRY_ID"].InnerText == "1")
                sVar = "Canada";


            dr["STATE_CODE"] = node["STATE_NAME"].InnerText + " / " + sVar;
            dr["STATE_ID"] = node["STATE_ID"].InnerText;
            dt.Rows.Add(dr);
        }
        ddlprivince.DataSource = dt;
        ddlprivince.DataTextField = "STATE_CODE";
        ddlprivince.DataValueField = "STATE_CODE";
        ddlprivince.DataBind();
        ddlprivince.Items.Insert(0, new ListItem("--Select one--", "0"));
    }
    

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        int jobID = 0;

        if (Request.QueryString["jobID"] != "" )
        {
            jobID = Int32.Parse(Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 5));
        }

        string UserID = "";
        if (FileUpload1.HasFile)
        {
            if (FileUpload1.PostedFile.ContentType == "image/jpeg" || FileUpload1.PostedFile.ContentType == "image/jpg")
            {
                fileExtension = Path.GetExtension(FileUpload1.FileName);
                if (FileUpload1.PostedFile.ContentLength < 100000000)
                {
                    string p = Path.GetFileName(FileUpload1.FileName);
                    //check if vendor exist in folder
                    if (Directory.Exists(Server.MapPath("~/images/profile_picture/" + UserID + "/ ")) == false)
                    {
                        DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/images/profile_picture/" + UserID + "/ "));
                    }

                    UniqueDateTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                    if (fileExtension.ToLower() == ".jpg")
                    {
                        FileUpload1.SaveAs(Server.MapPath("~/images/profile_picture/" + UserID + "/") + (FileUpload1.FileName.Replace(".jpg", "_" + UniqueDateTime + ".jpg")));
                        canPhoto = Server.MapPath("~/images/profile_picture/" + UserID + "/") + (FileUpload1.FileName.Replace(".jpg", "_" + UniqueDateTime + ".jpg"));
                    }

                    //FileUpload1.SaveAs(Server.MapPath("~/images/profile_picture" + FileUpload1.FileName));
                    lblimagestatus.Text = "File Uploaded...";
                    //canPhoto = "~/images/profile_picture" + FileUpload1.FileName;
                }
                else
                {
                    lblimagestatus.Text = "Only JPEG files with max size 1000 KB are accepted..";
                }
            }
        }
        else
        {
            lblimagestatus.Text = "Please select a file to upload...";
        }
        if (fileupresume.HasFile)
        {
            fileExtension = Path.GetExtension(fileupresume.FileName);
            if (fileExtension.ToLower() != ".doc" && fileExtension.ToLower() != ".docx" && fileExtension.ToLower() != ".pdf" && fileExtension.ToLower() != ".rtf")
            {
                lblresumestatus.Text = "Only Files with .doc or .docx extension are allowed...";
                lblresumestatus.ForeColor = System.Drawing.Color.White;
            }
            else
            {
                int filesize = fileupresume.PostedFile.ContentLength;

                if (filesize > 52428800)
                {
                    lblresumestatus.Text = "Maximum file size(50 MB) exceeded";
                    lblresumestatus.ForeColor = System.Drawing.Color.White;
                }
                else
                {
                    //check if vendor exist in folder
                    if (Directory.Exists(Server.MapPath("~/Resume/" + Session["VendorID"] + "/")) == false)
                    {
                        DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/Resume/" + Session["VendorID"] + "/"));
                    }
                    //check if jobid exists for that vendor for that resume
                    if (Directory.Exists(Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"])) == false)
                    {
                        DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"]));
                    }
                    UniqueDateTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                    if (fileExtension.ToLower() == ".doc")
                    {
                        fileupresume.SaveAs(Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".doc", "_" + UniqueDateTime + ".doc")));
                        canResume = Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".doc", "_" + UniqueDateTime + ".doc"));
                    }
                    if (fileExtension.ToLower() == ".docx")
                    {
                        fileupresume.SaveAs(Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".docx", "_" + UniqueDateTime + ".docx")));
                        canResume = Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".docx", "_" + UniqueDateTime + ".docx"));
                    }
                    if (fileExtension.ToLower() == ".rtf")
                    {
                        fileupresume.SaveAs(Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".rtf", "_" + UniqueDateTime + ".rtf")));
                        canResume = Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".rtf", "_" + UniqueDateTime + ".rtf"));
                    }
                    if (fileExtension.ToLower() == ".pdf")
                    {
                        fileupresume.SaveAs(Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".pdf", "_" + UniqueDateTime + ".pdf")));
                        canResume = Server.MapPath("~/Resume/" + Session["VendorID"] + "/" + Request.QueryString["jobID"] + "/") + (fileupresume.FileName.Replace(".pdf", "_" + UniqueDateTime + ".pdf"));
                    }
                    //fileupresume.SaveAs(Server.MapPath("~/Resume/4/JALS000019/") + fileupresume.FileName);
                    lblresumestatus.Text = "File uploaded...";
                    lblresumestatus.ForeColor = System.Drawing.Color.White;
                }
            }
        }
        else
        {
            lblresumestatus.Text = "Please select a file to upload...";
            lblresumestatus.ForeColor = System.Drawing.Color.White;
        }
        API.Service web = new API.Service();
        XmlDocument dom1 = new XmlDocument();
        UserID = Session["UserID"].ToString();
        dom1.LoadXml("<XML>" + web.get_dates(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString()).InnerXml + "</XML>");

        XmlNodeList Response3 = dom1.SelectNodes("XML/RESPONSE");
        string strat = Response3.Item(0).SelectSingleNode("CONTRACT_START_DATE").InnerText;
        string end = Response3.Item(0).SelectSingleNode("CONTRACT_END_DATE").InnerText;

        dom1.LoadXml("<XML>" + web.update_employee(Session["Email"].ToString(), Session["P@ss"].ToString(), Request.QueryString["empid"],
            jobID.ToString(), Session["VendorID"].ToString(), Session["ClientID"].ToString(), txtfistname.Value, txtmiddle.Value, txtlastname.Value,
            txtemail.Text, txtphone.Value, Request["txtdateofbirth"].ToString(), txtsuite.Value, txtaddress1.Value, "",
            txtcity.Value, ddlprivince.SelectedItem.Text, txtpostal.Value, sCountry, Server.HtmlEncode(txtcomment.Value.Replace("'", "''")), canPhoto, Request["txtavailable"].ToString(),
            txtskype.Value, strat, end, txtlicence.Value, txtsinnumber.Value, txtstdpayf.Value).InnerXml + "</XML>");
        XmlNodeList Response1 = dom1.SelectNodes("XML/RESPONSE");
        string employeeID = Response1.Item(0).SelectSingleNode("RESPONSE_MESSAGE").InnerText;

        dom1.LoadXml("<XML>" + web.update_resume(Session["Email"].ToString(), Session["P@ss"].ToString(), canResume, jobID.ToString(), Request.QueryString["empid"], UserID, Session["VendorID"].ToString()).InnerXml + "</XML>");

    

        XmlNodeList Response2 = dom1.SelectNodes("XML/RESPONSE");
        API.Service web1 = new API.Service();
     //   localhost.Service web1 = new localhost.Service();
        XmlDocument dom2 = new XmlDocument();
        if (txtemprating1 != null)
        {
            dom2.LoadXml("<XML>" + web1.update_emprating(Session["Email"].ToString(), Session["P@ss"].ToString(), Request.QueryString["empid"], Session["VendorID"].ToString(),
             Session["ClientID"].ToString(), txtemprating1.Text, txtemprating2.Text, txtemprating3.Text, txtemprating4.Text, txtemprating5.Text, Session["UserID"].ToString(), jobID.ToString()).InnerXml + "</XML>");
        }
        if (Request.QueryString["preview"] == "view")
        {
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
            string eID = Request.QueryString["empid"];
            string clientmails = "";
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                DateTime thisDay = DateTime.Now;

                conn.Open();

                string strSql = "update ovms_employees set submit_candidate_check=1 where employee_id=" + eID;

                SqlCommand cmd12 = new SqlCommand(strSql, conn);
                SqlDataReader reader23 = cmd12.ExecuteReader();
                reader23.Close();
                cmd12.Dispose();
                string clientmail = "select email_id from ovms_users where utype_id = 2 and client_id = '" + Session["ClientID"].ToString() + "' and vendor_id = '" + Session["VendorID"].ToString() + "'";
                SqlCommand cld = new SqlCommand(clientmail, conn);
                SqlDataReader cltread = cld.ExecuteReader();
                if (cltread.HasRows)
                {
                    while (cltread.Read())
                    {
                        clientmails = cltread["email_id"].ToString();
                    }
                }
                cld.Dispose();
                cltread.Close();
                conn.Close();

            }
            API.Service getWorkers = new API.Service();
            XmlDocument doms1 = new XmlDocument();
            doms1.LoadXml("<XML>" + getWorkers.get_employees("", "", Request.QueryString["empid"], Session["VendorID"].ToString(), Session["ClientID"].ToString(), "", "", "1", "").InnerXml + "</XML>");
            XmlNodeList empdate = doms1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID ");

            using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/EmailTemplate.html")))
            {
                string body = string.Empty;
                body = reader.ReadToEnd();

                body = body.Replace("{emails}", empdate[iResponse].SelectSingleNode("EMAIL").InnerText);
                body = body.Replace("{phone}", empdate[iResponse].SelectSingleNode("PHONE").InnerText);
                body = body.Replace("{JobID}", func.FixString(empdate[iResponse].SelectSingleNode("JOB_TITLE").InnerText));
                body = body.Replace("{EmployeeID}", empdate[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText);
                body = body.Replace("{EmployeeName}", empdate[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + empdate[iResponse].SelectSingleNode("LASTNAME").InnerText);
                body = body.Replace("{Vendor}", empdate[iResponse].SelectSingleNode("VENDOR_NAME").InnerText);


                semail.sendEmail(clientmails, "Candidate added to job - " + func.FixString(empdate[iResponse].SelectSingleNode("JOB_TITLE").InnerText),

                   body, "", "");
            }
        }
        XmlNodeList Response6 = dom2.SelectNodes("XML/RESPONSE");
        if (Response6.Item(0).SelectSingleNode("STATUS").InnerText == "1")
        {
            lblTableData.Text = "update worker succcessfully";
            // Response.Redirect("REFRESH", "5;URL=Job_Details.aspx?jobID=" + Request.QueryString["JobID"].ToString());
            Response.Redirect("Job_Details.aspx?jobID=" + Request.QueryString["jobId"] + "&update_worker=y");
        }
                else
        {
            lblTableData.Text = "can not insert data";
        }
        
    }
    protected void btnGoBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Job_Details.aspx?jobID=" + Request.QueryString["JobID"].ToString());
        //   Response.Redirect("Job_Details.aspx?jobID=" + Request.QueryString["JobID"].ToString());
    }
}