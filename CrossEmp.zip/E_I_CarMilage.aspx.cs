﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class E_I_CarMilage : System.Web.UI.Page
{
    SqlConnection conn;
    string errString = "";
    StringFunctions func = new StringFunctions();

    string _strinsertTimeSheet = "";
    string _strinsertTimeSheetDetail = "";
    emailFunctions semail = new emailFunctions();
    string emailjobid = "";
    string emailemployeeid = "";
    string employee_name_email = "";
    string email_job_id = "";
    string email_worker_name = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=Your+session+has+timed+out");
            Response.End();
        }

        GetEmployeename(Session["EmployeeIDForJob"].ToString());

        string _sInsertTimeSheet = "";
        _sInsertTimeSheet = InsertTimeSheet(emailemployeeid, Request.QueryString["Day"].ToString(), Request.QueryString["Month"].ToString(), Request.QueryString["Year"].ToString());

        lblResponse.Text = _sInsertTimeSheet;
    }

    public void GetEmployeename(string emailemployeeid)
    {

        string _sArrayString = "";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                string sqlGetEmployeeIDForJob = " select first_name,last_name, " +
                    "(select job_id from ovms_employees as ed where employee_id=e.employee_id) jobid," +
                    "(select job_title from ovms_jobs where job_id = (select job_id from ovms_employees as ed where employee_id = e.employee_id) )job_title" +
                    " from ovms_employee_details as e  where employee_id =  " + emailemployeeid;

                SqlCommand cmdEmployeeID = new SqlCommand(sqlGetEmployeeIDForJob, conn);
                SqlDataReader rsGetEmployeeID = cmdEmployeeID.ExecuteReader();
                //string _svendorList = "";
                while (rsGetEmployeeID.Read())
                {
                    Session["employee_name_email"] = rsGetEmployeeID["first_name"].ToString() + " " + rsGetEmployeeID["last_name"].ToString();
                    Session["emailjobid"] = rsGetEmployeeID["jobid"].ToString();
                }
                rsGetEmployeeID.Close();
                cmdEmployeeID.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        //return _sArrayString;
    }

    public string InsertTimeSheet(string Employee_ID, string day, string month, string year)
    {
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

        int newtsid = 0;
        double _dmiles = 0;
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                for (int iDate = 0; iDate <= 6; iDate++)
                {
                    DateTime _dt = Convert.ToDateTime(month + "/" + day + "/" + year).AddDays(iDate);


                    if (iDate == 0)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["M"].ToString());
                    }
                    if (iDate == 1)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["T"].ToString());
                    }
                    if (iDate == 2)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["W"].ToString());
                    }
                    if (iDate == 3)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["TH"].ToString());
                    }
                    if (iDate == 4)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["F"].ToString());
                    }
                    if (iDate == 5)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["S"].ToString());
                    }
                    if (iDate == 6)
                    {
                        _dmiles = ConvertToDouble(Request.QueryString["SU"].ToString());
                    }
                    //delete first allowing for update
                    //string strDeleteOldTime = " Delete from ovms_timesheet where day = '" + _dt.Day + "' and month = '" + _dt.Month + "' and year = '" + _dt.Year + "' where employee_id='"+ Session["EmployeeIDForJob"].ToString() +"' ";
                    string strDeleteOldTime = " Delete from ovms_cars where day = '" + _dt.Day + "' and month = '" + _dt.Month + "' and year = '" + _dt.Year + "' and employee_id='" + Session["EmployeeIDForJob"].ToString() + "'";
                    SqlCommand cmdDeleteOldTime = new SqlCommand(strDeleteOldTime, conn);
                    cmdDeleteOldTime.ExecuteScalar();


                    string strSql = "INSERT INTO ovms_cars (employee_id, day, month, year, miles,active,create_date)" +
                       " VALUES(" + Session["EmployeeIDForJob"].ToString() + "," + _dt.Day + "," + _dt.Month + "," + _dt.Year + "," + _dmiles + ",1, CURRENT_TIMESTAMP)" +
                       " SELECT CAST(scope_identity() AS int)";

                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    newtsid = (int)cmd.ExecuteScalar();

                    if (newtsid > 0)
                    {
                        _strinsertTimeSheet = "DONE";
                    }
                    else
                    {
                        _strinsertTimeSheet = "NOT";
                    }

                    strSql = "insert into ovms_car_milage_details(car_id, car_milesstatus, car_comment_id, create_date, active)" +
                               "values(" + newtsid + ", '3', '', CURRENT_TIMESTAMP, 1); ";

                    cmd = new SqlCommand(strSql, conn);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        _strinsertTimeSheet = "DONE";

                    }
                    else
                    {
                        _strinsertTimeSheet += "NOT";
                        //logService.set_log(125, HttpContext.Current.Request.Url.AbsoluteUri, "Unable to create new timesheet");
                    }
                    //dispose
                    cmd.Dispose();
                }


            }
        }
        catch (Exception ex)
        {
            _strinsertTimeSheet += "NOT";
            //logService.set_log(125, HttpContext.Current.Request.Url.AbsoluteUri, ex.Message);
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }

        if (_strinsertTimeSheet == "DONE")
        {

            DateTime _dt_From = Convert.ToDateTime(month + "/" + day + "/" + year);
            DateTime _dt_To = _dt_From.AddDays(7);

            string total = Request.QueryString["total"];
            emailemployeeid = Session["EmployeeIDForJob"].ToString();
            
        }
        
        //Session["EmployeeIDForJob"] = null;
        //Session["emailjobid"] = null;
        //Session["employee_name_email"] = null;

        return _strinsertTimeSheet;
    }
    public static double ConvertToDouble(string Value)
    {
        if (Value == null)
        {
            return 0;
        }
        else
        {
            double OutVal;
            double.TryParse(Value, out OutVal);

            if (double.IsNaN(OutVal) || double.IsInfinity(OutVal))
            {
                return 0;
            }
            return OutVal;
        }
    }
 }