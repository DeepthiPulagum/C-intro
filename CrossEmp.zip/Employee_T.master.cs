﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Employee_T : System.Web.UI.MasterPage
{
    //public string UserName { get { return (Session["FirstName"].ToString() + ' ' + Session["LastName"].ToString()); } }
    public string jobDetails { get { return (jbView.Value); } }
    //public string empid { get { return empView.Value; } }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["jobID"] != null)
        {
            jbView.Value = Request["jobID"].ToString();
        }
        if (!Page.IsPostBack)
        {
            XmlDocument xmldoc = new XmlDocument();
            API.Service prof = new API.Service();

            xmldoc.LoadXml("<XML>" + prof.get_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
            // xmldoc.LoadXml("<XML>" + prof.get_Profile("greg@opusing.com ", "1234", "9").InnerXml + "</XML>");
            XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/USER_NO");

            txtfirst.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/FIRST_NAME").InnerText;
            txtsecond.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/LAST_NAME").InnerText;
            txtemail.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/EMAIL").InnerText;

            // Password1.Value = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/PASSWORD").InnerText;
        }
    }

    protected void updatePassword_Click(object sender, EventArgs e)
    {
        string abc = txtnewpassword.Text;
        string xyz = txtconfirmpassword.Text;
        //if (txtnewpassword.Text == "" || txtconfirmpassword.Text == "")
        //{

        //    Label1.Text = "*Fields can not be empty";
        //    Label1.ForeColor = System.Drawing.Color.Red;
        //    Label1.Focus();
        //}
        //else
        //{
        //    if (txtnewpassword.Text != txtconfirmpassword.Text)
        //    {

        //        Label1.Text = "*Passwords do not match";
        //        Label1.ForeColor = System.Drawing.Color.Red;
        //        Label1.Focus();

        //    }
        //    else
        //    {
        XmlDocument xmldoc = new XmlDocument();
        API.Service updateP = new API.Service();
        xmldoc.LoadXml("<XML>" + updateP.update_Personal_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString(), txtnewpassword.Text).InnerXml + "</XML>");
        Session["P@ss"] = "";
        // Session["P@ss"] = txtnewpass.Value;
        //Response.Redirect("Emp_Profile.aspx");
        //}
        //}

    }


    //protected void updatebasicinfo_Click(object sender, EventArgs e)
    //{
    //    if (txtfirst.Text == "" || txtsecond.Text == "" || txtemail.Text == "")
    //    {
    //        //Label5.Text= "*Fields can not be empty";

    //        //Label5.ForeColor = System.Drawing.Color.Red;
    //        //Label5.Focus();
    //    }


    //    else
    //    {

    //        XmlDocument xmldoc = new XmlDocument();
    //        API.Service updateP = new API.Service();
    //        // API.Service updateP = new API.Service();
    //        xmldoc.LoadXml("<XML>" + updateP.update_Basic_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), txtfirst.Text, txtsecond.Text, txtemail.Text, Session["UserID"].ToString()).InnerXml + "</XML>");
    //        Session["Email"] = "";
    //        Session["Email"] = txtemail.Text;
    //        Response.Redirect("E_Dashboard.aspx");
    //        Response.End();
    //    }
    //}
}
