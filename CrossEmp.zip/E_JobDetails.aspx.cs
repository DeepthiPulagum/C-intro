﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class E_JobDetails : System.Web.UI.Page
{
    public string canPhoto { get; set; }
    public string canResume { get; set; }
    string fileExtension = "";
    string UniqueDateTime = "";
    StringFunctions func = new StringFunctions();
    private int intCount1;

    protected void Page_Load(object sender, EventArgs e)
    {

        //check session
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=Your+session+has+timed+out");
            Response.End();
        }

        //social media
        lblfacebook.Text = "<a href='https://www.facebook.com/sharer/sharer.php?u=http%3A//flentispro.com/social_media_job_view.aspx?jobID=" + Request.QueryString["jobID"] + "' class='fa fa-fw fa-facebook' target='_blank'></a>";
        lbllinkedin.Text = "<a href='https://www.linkedin.com/shareArticle?mini=true&url=http%3A//flentispro.com/social_media_job_view.aspx?jobID=&title=We%20are%20currently%20hiring,%20check%20this%20new%20job.!!&summary=&source=" + Request.QueryString["jobID"] + " 'class='fa fa-fw fa-linkedin'   target='_blank'></a>";
        lbltwitter.Text = "<a href='https://twitter.com/home?status=http%3A//flentispro.com/social_media_job_view.aspx?jobID=" + Request.QueryString["jobID"] + "' class='fa fa-fw fa-twitter'  target='_blank'></a>";


        if (!Page.IsPostBack)
        {
            string a = "";
        }
        int jobID = 0;
        if (Request.QueryString["jobID"] != "")
        {
            jobID = Int32.Parse(Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 5));
        }
        API.Service jobDetails = new API.Service();
        XmlDocument _xjobDetails = new XmlDocument();
        _xjobDetails.LoadXml("<XML>" + jobDetails.get_Jobs(Convert.ToString(jobID), Session["Email"].ToString(), Session["P@ss"].ToString(), Session["VendorID"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        // _xjobDetails.LoadXml("<XML>" + jobDetails.get_Jobs("2", "srinivas.gadde@pamten.ca", "ferivan").InnerXml + "</XML>");
        string _Error = "";
        try
        {
            _Error = _xjobDetails.SelectSingleNode("XML/RESPONSE/ERROR").InnerText;
            //_xUserInfo.SelectNodes("XML/RESPONSE/JOB_NO")
        }
        catch (Exception ex)
        {
            _Error = "";
        }
        XmlNodeList Response2 = _xjobDetails.SelectNodes("XML/RESPONSE/JOBS");

        //int CountRows = 1;
        string _Job_Description = "";
        string _Job_Title = "";
        string _No_Of_Opennings = "";
        string _DepartmentName = "";
        string _ClientName = "";
        string _Job_Position_Type = "";
        string _Job_Posting_Start_Date = "";
        string _Job_Posting_End_Date = "";
        string _Job_Location = "";
        string _Hours_Per_Day = "";
        string _Hiring_Manager = "";
        string _Job_Currency = "";
        string _Job_TimeZone = "";
        string _Contract_Start_Date = "";
        string _Contract_End_Date = "";
        string _Max_submittion = "";
        string _ReasonForOpen = "";
        string _Urgent = "";
        string _PayRate = "";
        string _comments = "";

        for (int intCount = 0; intCount < Response2.Count; intCount++)
        {
            _Job_Description = Server.HtmlDecode(Response2[intCount].SelectSingleNode("JOB_DESC").InnerText);
            _Job_Title = Response2[intCount].SelectSingleNode("JOB_TITLE").InnerText;
            _No_Of_Opennings = Response2[intCount].SelectSingleNode("NO_OF_OPENINGS").InnerText;
            _DepartmentName = Response2[intCount].SelectSingleNode("DEPARTMENT_NAME").InnerText;
            _ClientName = Response2[intCount].SelectSingleNode("CLIENT_NAME").InnerText;
            _Job_Position_Type = Response2[intCount].SelectSingleNode("JOB_POSITION_TYPE").InnerText;
            _Job_Posting_Start_Date = DateTime.Parse(Response2[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("MMMM dd, yyyy");
            _Job_Posting_End_Date = DateTime.Parse(Response2[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("MMMM dd, yyyy");
            _Job_Location = Response2[intCount].SelectSingleNode("JOB_LOCATION").InnerText;
            _Hours_Per_Day = Response2[intCount].SelectSingleNode("HOURS_PER_DAY").InnerText;
            _Hiring_Manager = Response2[intCount].SelectSingleNode("HIRING_MANAGER_NAME").InnerText;
            _Job_Currency = Response2[intCount].SelectSingleNode("JOB_CURRENCY").InnerText;
            _Contract_Start_Date = Response2[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText;
            _Contract_End_Date = Response2[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText;
            _Job_TimeZone = Response2[intCount].SelectSingleNode("JOB_TIMEZONE").InnerText;
            _Max_submittion = Response2[intCount].SelectSingleNode("MAX_SUBMISSION_PER_SUPPLIER").InnerText;
            _ReasonForOpen = Response2[intCount].SelectSingleNode("REASON_FOR_OPEN").InnerText;
            _Urgent = Response2[intCount].SelectSingleNode("URGENT").InnerText;
            _PayRate = Response2[intCount].SelectSingleNode("STD_PAY_RATE").InnerText;
            _comments = Response2[intCount].SelectSingleNode("COMMENTS").InnerText;

        }
        if (_Urgent == "1")
        {
            lblUrgent.Text = "(Urgent Request)";
        }
        DateTime dt = Convert.ToDateTime(_Job_Posting_Start_Date);
        DateTime dtt = Convert.ToDateTime(_Job_Posting_End_Date);
        // lblPostingDate.Text = dt.ToString("dddd, dd MMMM yyyy HH:mm:ss").Replace("00:00:00", "");
        lblJobTitle.Text = func.FixString(_Job_Title);
        lblJobDescription.Text = _Job_Description;
        //lblNumberofPOsitions.Text = _No_Of_Opennings + " position(s) available, please respond by " + dtt.ToString("dddd, dd MMMM yyyy HH:mm:ss").Replace("00:00:00", ""); ;
        // lblLocation.Text = _Job_Location;
        lblnoofopning.Text = _No_Of_Opennings;
        lblstartdate.Text = _Job_Posting_Start_Date;
        lblenddate.Text = _Job_Posting_End_Date;
        lbllocation.Text = _Job_Location;
        lblpayrate.Text = _PayRate;
        lblcomments.Text = _comments;

        //stars 

        API.Service web1 = new API.Service();
        XmlDocument dom2 = new XmlDocument();
        //string strID = Request.QueryString["ID"];
        dom2.LoadXml("<XML>" + web1.get_rating_with_jobid2(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString()).InnerXml + "</XML>");
        XmlNodeList Response3 = dom2.SelectNodes("XML/RESPONSE/QUESTIONS_NO ");

        //Deepthi's code
        string que1 = "";
        string que2 = "";
        string que3 = "";
        string que4 = "";
        string que5 = "";
        string rating1 = "";
        string rating2 = "";
        string rating3 = "";
        string rating4 = "";
        string rating5 = "";
        try
        {
            que1 = Server.HtmlDecode(Response3[intCount1].SelectSingleNode("QUESTION1").InnerText);
            que2 = Response3[intCount1].SelectSingleNode("QUESTION2").InnerText;
            que3 = Response3[intCount1].SelectSingleNode("QUESTION3").InnerText;
            que4 = Response3[intCount1].SelectSingleNode("QUESTION4").InnerText;
            que5 = Response3[intCount1].SelectSingleNode("QUESTION5").InnerText;
            rating1 = Response3[intCount1].SelectSingleNode("RATING1").InnerText;
            rating2 = Response3[intCount1].SelectSingleNode("RATING2").InnerText;
            rating3 = Response3[intCount1].SelectSingleNode("RATING3").InnerText;
            rating4 = Response3[intCount1].SelectSingleNode("RATING4").InnerText;
            rating5 = Response3[intCount1].SelectSingleNode("RATING5").InnerText;
        }
        catch (Exception ex)
        {

        }
        if (que1 == "")
        {
            divstar.Visible = false;
        }
        else
        {
            divstar.Visible = true;
        }
        lblque1.Text = que1;
        labque2.Text = que2;
        lblque3.Text = que3;
        lblque4.Text = que4;
        lblque5.Text = que5;
        txtRating1.Text = rating1;
        txtRating2.Text = rating2;
        txtRating3.Text = rating3;
        txtRating4.Text = rating4;
        txtRating5.Text = rating5;
        //Deepthi's code end

        //old code
        //string que1 = "";
        //string que2 = "";
        //string que3 = "";
        //string que4 = "";
        //string que5 = "";
        //string rating1 = "";
        //string rating2 = "";
        //string rating3 = "";
        //string rating4 = "";
        //string rating5 = "";
        //que1 = Response3[intCount1].SelectSingleNode("QUESTION1").InnerText;
        //if (que1 == "")
        //{
        //    divstar.Visible = false;
        //}
        //else
        //{
        //    divstar.Visible = true;
        //}

        //for (intCount1 = 0; intCount1 < Response2.Count; intCount1++)
        //{
        //    que1 = Response3[intCount1].SelectSingleNode("QUESTION1").InnerText;
        //    que2 = Response3[intCount1].SelectSingleNode("QUESTION2").InnerText;
        //    que3 = Response3[intCount1].SelectSingleNode("QUESTION3").InnerText;
        //    que4 = Response3[intCount1].SelectSingleNode("QUESTION4").InnerText;
        //    que5 = Response3[intCount1].SelectSingleNode("QUESTION5").InnerText;
        //    rating1 = Response3[intCount1].SelectSingleNode("RATING1").InnerText;
        //    rating2 = Response3[intCount1].SelectSingleNode("RATING2").InnerText;
        //    rating3 = Response3[intCount1].SelectSingleNode("RATING3").InnerText;
        //    rating4 = Response3[intCount1].SelectSingleNode("RATING4").InnerText;
        //    rating5 = Response3[intCount1].SelectSingleNode("RATING5").InnerText;
        //}
        //lblque1.Text = func.FixString(que1);
        //labque2.Text = func.FixString(que2);
        //lblque3.Text = func.FixString(que3);
        //lblque4.Text = func.FixString(que4);
        //lblque5.Text = func.FixString(que5);
        //txtRating1.Text = rating1;
        //txtRating2.Text = rating2;
        //txtRating3.Text = rating3;
        //txtRating4.Text = rating4;
        //txtRating5.Text = rating5;
        //old code end

        string sTable = "<tbody>";
        API.Service web = new API.Service();
        XmlDocument dom1 = new XmlDocument();
        //string strID = Request.QueryString["ID"];
        dom1.LoadXml("<XML>" + web.get_candiate_for_that_particuler_job(Session["Email"].ToString(), Session["P@ss"].ToString(), jobID.ToString(), Session["VendorID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response1 = dom1.SelectNodes("XML/RESPONSE/EMPLOYEE_NO");
        sTable = "";
        //  string _messageVariable = "";

        //   _messageVariable = _messageVariable +

        for (int iResponse = 0; iResponse < Response1.Count; iResponse++)
        {
            sTable = sTable + "<tr>";
            //    sTable = sTable + "<td>" + @" <div class=""checkbox checkbox-single margin-none"">  <input id=""checkAll"" type=""checkbox"" ></input> <label for=""checkbox2"" > Label </label> </div>" + " </TD>";
            // sTable = sTable + "<td>" + _messageVariable + " </TD>";
            sTable = sTable + "<td><a class='btn btn-danger btn-xs' data-toggle='tooltip' data-placement='top' name='abc' title='Edit Candidate ' href='Edit_Worker.aspx?empid=" + Response1[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText + "&jobId=" + Request.QueryString["jobID"] + "'>Edit</a> </td> ";
            sTable = sTable + "<td>" + DateTime.Parse(Response1[iResponse].SelectSingleNode("SUBMIT_DATE").InnerText).ToString("MMMM dd, yyyy") + " </TD>";
            sTable = sTable + "<td>" + Response1[iResponse].SelectSingleNode("FIRST_NAME").InnerText + " " + Response1[iResponse].SelectSingleNode("LAST_NAME").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse].SelectSingleNode("EMAIL").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse].SelectSingleNode("LOCATION").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse].SelectSingleNode("STATUS").InnerText + " </td> ";
            sTable = sTable + "<td>" + Response1[iResponse].SelectSingleNode("PAY_RATE").InnerText + " </td> ";
            sTable = sTable + "<td><a href='" + Response1[iResponse].SelectSingleNode("RESUME_PATH").InnerText + "'>Resume</a> </td> ";
            sTable = sTable + "</tr>";
            string a = "";

            //  EMPLOYEE_ID
        }

        sTable = sTable + "</tbody>";
        web.Dispose();
        //lblTableData.Text = sTable;
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("Add_worker.aspx?wopen=Y&p=AW&jobID=" + Request.QueryString["jobID"]);
    }

    protected void btnrefer_Click(object sender, EventArgs e)
    {

        string jobId = lblJobId.Text;
        string name = TxtName.Text;
        string job = Txtjob.Text;
        string phone = Txtphone.Text;
        string email = Txtemail.Text;
        // string resume = FileUpload1.Load;

        string resumepath = Path.GetFileName(FileUpload1.FileName);
        string resume = Server.MapPath("~/") + resumepath;//FileUpload1;

        string comment = TextArea1.Value;
        //Response.Redirect("refer_frnd_page2.aspx?wopen=Y&jobid=" + Request.QueryString["jobID"] + "&p=AW&Name=" + name + "&Job=" + job + "&Phone=" + phone + "&Email=" + email + "&comment=" + comment);
        // Txtemail.Text = "";

        string empID = Session["EmployeeID"].ToString();
        //string cand_name = Request.QueryString["name"];
        //string jobname = Request.QueryString["job"];
        //string phone = Request.QueryString["phone"];
        string job_id = (Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 7));
        //string email = Request.QueryString["Email"];
        //string resume = Request.QueryString["fileresume"];
        //string comments = Request.QueryString["comment"];
        API.Service refer = new API.Service();
        XmlDocument _xmlDoc1 = new XmlDocument();
        _xmlDoc1.LoadXml("<XML>" + refer.refer_a_frnd(Session["Email"].ToString(), Session["P@ss"].ToString(), empID, job, name, resume, comment, phone, email) + "</XML>");

        // _xmlDoc1.LoadXml("<XML>" + refer.refer_a_frnd(Session["Email"].ToString(), Session["P@ss"].ToString(), emp_id, "", job_id, resume, comment, phone, email).InnerXml + "</XML>");
        XmlNodeList ea = _xmlDoc1.SelectNodes("XML/RESPONSE");

        Response.Redirect("E_JobDetails.aspx?wopen=Y&p=VW&jobid=" + Request.QueryString["jobID"]);
        Response.End();

    }
}