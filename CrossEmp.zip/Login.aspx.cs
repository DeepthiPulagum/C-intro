﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Login : System.Web.UI.Page
{
    SqlConnection conn;
    string uName = "";
    string uPassword = "";
    //emailFunctions semail = new emailFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request["H"] == null)
        {
            Response.Redirect("Login.aspx?H=V&m=" + Request["m"]);
        }

        if ((Session["UserTypeID"] != null) && (Session["UserTypeID"].ToString() != ""))
        {
            if (Session["UserTypeID"].ToString() == "2") //client
            {
                Response.Redirect("V_Dashboard.aspx");
                Response.End();
            }

            if (Session["UserTypeID"].ToString() == "3") //client
            {
                Response.Redirect("C_Dashboard.aspx");
                Response.End();
            }
       
            if (Session["UserTypeID"].ToString() == "4") //employee
            {
                Response.Redirect("E_Dashboard.aspx");
                Response.End();
            }
        }
        alertbox.Visible = false;
        // forgotpasswordpanel.Visible = false;

        if (Request["m"] != null)
        {
            if (Request["m"] != "")
                alertbox.Visible = true;
            alertbox.InnerText = Request.QueryString["m"];
        }
        if (Request["forgotpass"] != null)
        {
            // forgotpasswordpanel.Visible = true;
        }
    }

    protected void loginbtn_Click(object sender, EventArgs e)
    {
        //if (remember.Checked)
        //{
        //    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(30);
        //    Response.Cookies["password"].Expires = DateTime.Now.AddDays(30);
        //}
        //else

        //{
        //    Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
        //    Response.Cookies["password"].Expires = DateTime.Now.AddDays(-1);
        //}

        Response.Cookies["UserName"].Value = txtEmailAddress.Text.Trim();
        Response.Cookies["password"].Value = txtPassword.Text.Trim();

        API.Service web = new API.Service();
        XmlDocument dom1 = new XmlDocument();


        string ipAddresscheck = string.Empty;
        ipAddresscheck = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (ipAddresscheck == "" || ipAddresscheck == null)
        {
            ipAddresscheck = HttpContext.Current.Request.ServerVariables["LOCAL_ADDR"];

        }
        else
        {
            ipAddresscheck = "";
        }

        dom1.LoadXml("<XML>" + web.blacklist_check(ipAddresscheck).InnerXml + "</XML>");
        XmlNodeList Response3 = dom1.SelectNodes("XML/RESPONSE");
        if (Response3.Item(0).SelectSingleNode("TIMES").InnerText == "0")
        {
            //alertbox.InnerText = "Login failed - Please ensure you check the box below and also enter proper credentials";
            alertbox.InnerText = "Login failed - Please enter proper credentials";

        }
        else
        {
            string count = Response3.Item(0).SelectSingleNode("TIMES").InnerText;
            string min = Response3.Item(0).SelectSingleNode("MINUTES_DIFFERENCE").InnerText.Replace("-", "");
            string hour = Response3.Item(0).SelectSingleNode("HOURS").InnerText;

            if (Convert.ToInt32(count) >= 5)
            {
                alertbox.Visible = true;

                alertbox.InnerText = " Unfortunately because of too many attemts your IP has been blocked." +
                   "You can login after " + hour + " Hours and " + min + " Minutes.";

            }
        }
        //string uType = "";
        //uType = "3";
        //if (Request["H"] != null)
        //{
        //    if (Request["H"].ToString() == "V")
        //    {
        //        uType = "2";
        //    }
        //    if (Request["H"].ToString() == "C")
        //    {
        //        uType = "3";
        //    }
        //    if (Request["H"].ToString() == "E")
        //    {
        //        uType = "4";
        //    }
        //}
        string sContinue = "NO";
        if (getLogin_VCE(txtEmailAddress.Text, txtPassword.Text) == "YES")
        {
            sContinue = "YES";
        }

        var result = ": true";
        if ((result.ToString().Contains(": true")) && (sContinue == "YES"))
        {
            //query users table

            //user info web service
            API.Service userinf = new API.Service();
            XmlDocument _xUserInfo = new XmlDocument();
            _xUserInfo.LoadXml("<XML>" + userinf.get_Login(txtEmailAddress.Text, txtPassword.Text).InnerXml + "</XML>");

            string _Error = "";
            try
            {
                _Error = _xUserInfo.SelectSingleNode("XML/RESPONSE/ERROR").InnerText;
                //_xUserInfo.SelectNodes("XML/RESPONSE/JOB_NO")
            }
            catch (Exception ex)
            {
                _Error = "";
            }
            string UserID = "";
            string UserTypeID = "";
            string FirstName = "";
            string LastName = "";
            string Email = "";
            string ClientID = "";
            string VendorID = "";
            string PMOID = "";
            string vendor_email = "";

            if (_Error != "")
            {
                alertbox.Visible = true;

                alertbox.InnerText = _Error;
            }
            else
            {
                //user loged in information from table
                UserID = _xUserInfo.SelectSingleNode("XML/RESPONSE/USERID").InnerText;
                PMOID = _xUserInfo.SelectSingleNode("XML/RESPONSE/PMOID").InnerText;
                UserTypeID = _xUserInfo.SelectSingleNode("XML/RESPONSE/USERTYPE").InnerText;
                FirstName = _xUserInfo.SelectSingleNode("XML/RESPONSE/FIRSTNAME").InnerText;
                LastName = _xUserInfo.SelectSingleNode("XML/RESPONSE/LASTNAME").InnerText;
                Email = _xUserInfo.SelectSingleNode("XML/RESPONSE/EMAIL").InnerText;
                VendorID = _xUserInfo.SelectSingleNode("XML/RESPONSE/VENDORID").InnerText;
                ClientID = _xUserInfo.SelectSingleNode("XML/RESPONSE/CLIENTID").InnerText;
                vendor_email = _xUserInfo.SelectSingleNode("XML/RESPONSE/VENDORID_EMAIL").InnerText;

                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();

                        //start, end and weeks
                        string sqlGetClientName = "select employee_id from ovms_employees as emp join ovms_users  as us on emp.user_id = us.user_id where us.email_id = '" + Email + "'";

                        SqlCommand cmdEmpID = new SqlCommand(sqlGetClientName, conn);
                        SqlDataReader rsGetEmpID = cmdEmpID.ExecuteReader();

                        while (rsGetEmpID.Read())
                        {
                            Session["EmployeeID"] = rsGetEmpID["employee_id"].ToString();
                        }
                        //Close()
                        rsGetEmpID.Close();
                        cmdEmpID.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    //
                }
                finally
                {
                    if (conn.State == System.Data.ConnectionState.Open)
                        conn.Close();
                }

                Session["Vendor_Email"] = vendor_email;
                Session["UserID"] = UserID;
                Session["UserTypeID"] = UserTypeID;
                Session["FirstName"] = FirstName;
                Session["LastName"] = LastName;
                Session["Email"] = Email;
                Session["ClientID"] = ClientID;
                Session["VendorID"] = VendorID;
                Session["P@ss"] = txtPassword.Text;
                Session["PMOID"] = PMOID;

                if (UserTypeID == "2") //if it is vendor
                {

                    //get Vendor Name
                    Session["VendorLoggedIn"] = "true";
                    get_VendorName(Session["VendorID"].ToString());
                    Response.Redirect("V_Dashboard.aspx");
                    Response.End();
                }
                if (UserTypeID == "3") //if it is client
                {
                    //get Client Name
                    Session["ClientLoggedIn"] = "true";
                    get_ClientName(Session["ClientID"].ToString());
                    Response.Redirect("C_Dashboard.aspx");
                    Response.End();
                }
                if (UserTypeID == "4") //if it is employee
                {
                    Session["EmployeeLoggedIn"] = "true";
                    Response.Redirect("E_Dashboard.aspx?H=1");
                    Response.End();
                }
            }
        }
        else
        {
            alertbox.Visible = true;

            //**24 hour limit **/
            string ipAddress = string.Empty;
            ipAddress = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipAddress == "" || ipAddress == null)
            {
                ipAddress = HttpContext.Current.Request.ServerVariables["LOCAL_ADDR"];

            }
            else
            {
                ipAddress = "";
            }

            dom1.LoadXml("<XML>" + web.blacklist_check(ipAddress).InnerXml + "</XML>");
            XmlNodeList Response37 = dom1.SelectNodes("XML/RESPONSE");

            string count = Response3.Item(0).SelectSingleNode("TIMES").InnerText;
            string min = Response3.Item(0).SelectSingleNode("MINUTES_DIFFERENCE").InnerText.Replace("-", "");
            string hour = Response3.Item(0).SelectSingleNode("HOURS").InnerText;

            if (Convert.ToInt32(count) == 5)
            {
                alertbox.Visible = true;

                alertbox.InnerText = "Please enter your credentials and ensure to click on 'I'm not a Robot'.";


            }
            //else
            //{
            //    dom1.LoadXml("<XML>" + web.insert_fail_login(txtEmailAddress.Text, txtPassword.Text, ipAddress).InnerXml + "</XML>");

            //    XmlNodeList Response2 = dom1.SelectNodes("XML/RESPONSE");
            //    if (Response2.Item(0).SelectSingleNode("STRING").InnerText == "1")
            //    {
            //        dom1.LoadXml("<XML>" + web.get_ip_address_count(ipAddress).InnerXml + "</XML>");
            //        XmlNodeList Response33 = dom1.SelectNodes("XML/RESPONSE");
            //        string count1 = Response33.Item(0).SelectSingleNode("TIMES").InnerText;
            //        if (Convert.ToInt32(count1) >= 5)
            //        {
            //            alertbox.InnerText = " Unfortunately because of too many attemts your IP has been blocked ";
            //            txtEmailAddress.Text = string.Empty;
            //            txtPassword.Text = string.Empty;
            //        }
            //        else
            //        {
            //            alertbox.InnerText = "Login failed - Please ensure you check the box below and also enter proper credentials";
            //        }
            //    }
            //    else
            //    {
            //        alertbox.InnerText = "Login failed - Please ensure you check the box below and also enter proper credentials";
            //    }
            //}

        }
    }
    public string getLogin_VCE(string username, string password)
    {
        string _sFound = "NO";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                //start, end and weeks
                string sqlGetType = " select user_id from ovms_users where email_id = '" + username + "' and user_password = '" + password + "' and active = 1 and 1 = 1";

                SqlCommand cmdGetType = new SqlCommand(sqlGetType, conn);
                SqlDataReader rsGetType = cmdGetType.ExecuteReader();

                while (rsGetType.Read())
                {
                    _sFound = "YES";
                }
                //Close()
                rsGetType.Close();
                cmdGetType.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sFound;
    }
    public void get_ClientName(string cli_id)
    {
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                //start, end and weeks
                string sqlGetClientName = "select client_name from ovms_clients where client_ID = " + cli_id + " ";

                SqlCommand cmdGetClientName = new SqlCommand(sqlGetClientName, conn);
                SqlDataReader rsGetClientName = cmdGetClientName.ExecuteReader();

                while (rsGetClientName.Read())
                {
                    Session["ClientName"] = rsGetClientName["client_name"].ToString();
                }
                //Close()
                rsGetClientName.Close();
                cmdGetClientName.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }
    public void get_VendorName(string ven_id)
    {
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                // Session["JobID"] = jobID.ToString();

                //start, end and weeks
                string sqlGetvendorName = "select vendor_name from ovms_vendors where vendor_id = " + ven_id + " ";

                SqlCommand cmdGetVendorName = new SqlCommand(sqlGetvendorName, conn);
                SqlDataReader rsGetvendorName = cmdGetVendorName.ExecuteReader();



                while (rsGetvendorName.Read())
                {
                    Session["VendorName"] = rsGetvendorName["vendor_name"].ToString();
                }


                //Close()
                rsGetvendorName.Close();
                cmdGetVendorName.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }

}