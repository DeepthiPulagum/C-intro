﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class E_ViewJobs : System.Web.UI.Page
{
    StringFunctions func = new StringFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }

        ViewJobsInTable();
    }
    private void ViewJobsInTable()
    {
        string sTable = "<tbody>";
        API.Service jobInfo = new API.Service();
        XmlDocument xmldoc = new XmlDocument();

        //xmldoc.LoadXml("<XML>" + jobInfo.get_JobView("srinivas.gadde@pamten.ca", "ferivan", "2", "", "", "", "", "", "", "").InnerXml + "</XML>");
        xmldoc.LoadXml("<XML>" + jobInfo.get_Jobs("", Session["Email"].ToString(), Session["P@ss"].ToString(), Session["VendorID"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/JOBS ");
        sTable = "";
        int CountRows = 1;

        string _sBackground = "";

        for (int intCount = 0; intCount < Response.Count; intCount++)
        {
            //wrap text for title
            string original_jobtitle = Response[intCount].SelectSingleNode("JOB_TITLE").InnerText;

            string job_title = "";
            if (original_jobtitle.Length > 25)
            {
                job_title = original_jobtitle.Substring(0, 25);
            }
            else
            {
                job_title = original_jobtitle;
            }

            string urgent_job = Response[intCount].SelectSingleNode("URGENT").InnerText;

            //if (intCount % 2 >= 1)
            //{
            //    //enableordisable = "";
            //    _sBackground = "bgcolor='#ECF0F1'";
            //}
            //else
            //{
            //    // enableordisable = "disabled";
            //    _sBackground = "";
            //}

            sTable = sTable + "<tr>";
            //sTable = sTable + "<td>" + CountRows + "</td>";
            //if (Response[intCount].SelectSingleNode("URGENT").InnerText == "1")
            //{
            //    sTable = sTable + "<td bgcolor=\"#ff0000\"><font color=\"#ffffff\">";
            //}
            //else
            //{
            //    sTable = sTable + "<td>";
            //}
            //sTable = sTable + Response[intCount].SelectSingleNode("JOB_STATUS").InnerText;

            if (Response[intCount].SelectSingleNode("URGENT").InnerText == "1")
            {
                sTable = sTable + "<td style=color:red><BLINK> " + "Urgent" + "</BLINK></td> ";
                //sTable = sTable + "<td style=color:red><a style=color:red  href='E_JobDetails.aspx?jopen=Y&p=JV&jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                sTable = sTable + "<td style=color:red;white-space:nowrap;><a style=color:red  href='E_JobDetails.aspx?jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                sTable = sTable + "<td style=color:red> " + func.FixString(job_title) + "</td> ";
                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + Response[intCount].SelectSingleNode("JOB_LOCATION").InnerText.Replace(",Canada", "") + " </td> ";
                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                // sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                DateTime comp_end_date = DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                DateTime thisday = DateTime.Now;
                if (comp_end_date <= thisday)
                {
                    sTable = sTable + "<td style=color:red>N/A</td> ";
                }
                else
                {
                    sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                }
                sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("NO_OF_OPENINGS").InnerText + " </td> ";
                //sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("HIRED").InnerText + " </td> ";
                //sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("AVAILABLE_JOBS").InnerText + " </td> ";
                //sTable = sTable + "<td style=color:red;white-space:nowrap;>" + Response[intCount].SelectSingleNode("RECENT").InnerText + " day(s)</td> ";
                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + Response[intCount].SelectSingleNode("USERNAME").InnerText + " </td> ";
                sTable = sTable + "</tr>";
            }
            else
            {
                sTable = sTable + "<td> " + Response[intCount].SelectSingleNode("JOB_STATUS").InnerText + "</td> ";
                //sTable = sTable + "<td><a href='E_JobDetails.aspx?jopen=Y&p=JV&jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                sTable = sTable + "<td style=white-space:nowrap;><a href='E_JobDetails.aspx?jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                sTable = sTable + "<td style=white-space:nowrap;>" + func.FixString(job_title) + "</td> ";
                sTable = sTable + "<td style=white-space:nowrap;>" + Response[intCount].SelectSingleNode("JOB_LOCATION").InnerText.Replace(",Canada", "") + " </td> ";
                sTable = sTable + "<td style=white-space:nowrap;>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                // sTable = sTable + "<td>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                DateTime comp_end_date = DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                DateTime thisday = DateTime.Now;
                if (comp_end_date <= thisday)
                {
                    sTable = sTable + "<td >N/A</td> ";
                }
                else
                {
                    sTable = sTable + "<td style=color:red;white-space:nowrap;>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                }
                sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("NO_OF_OPENINGS").InnerText + " </td> ";
                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("HIRED").InnerText + " </td> ";
                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("AVAILABLE_JOBS").InnerText + " </td> ";
                //sTable = sTable + "<td style=white-space:nowrap;>" + Response[intCount].SelectSingleNode("RECENT").InnerText + " day(s)</td> ";
                sTable = sTable + "<td style=white-space:nowrap;>" + Response[intCount].SelectSingleNode("USERNAME").InnerText + " </td> ";
                sTable = sTable + "</tr>";
            }

            CountRows++;
        }
        sTable = sTable + "</tbody>";
        jobInfo.Dispose();
        lblTableData.Text = sTable;
    }
}