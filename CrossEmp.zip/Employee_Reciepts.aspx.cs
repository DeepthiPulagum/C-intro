﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
public partial class Employee_Reciepts : System.Web.UI.Page
{
    SqlConnection conn;
    string errString = "";
    StringFunctions func = new StringFunctions();
    string NumberOfWeeks = "";
    string FirstMonday = "";
    string FirstSunday = "";
    string LastContractDate = "";
    string ContractWeeks = "";
    string sTimeValues;
    string _sBackground = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string _sTimeSheetLines = "";
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=Your+session+has+timed+out");
            Response.End();
        }
        NumberOfWeeks = GetNumberOfWeeks();
        if (NumberOfWeeks != "")
        {
            FirstMonday = GetMonday(NumberOfWeeks.Split(',')[0].ToString());
            FirstSunday = GetSunday(NumberOfWeeks.Split(',')[0].ToString());
            ContractWeeks = NumberOfWeeks.Split(',')[2].ToString(); //week num
            LastContractDate = NumberOfWeeks.Split(',')[1].ToString(); //last contract date
            GetEmployeeID();
            //draw table but first read from file
            int counter = 0;
            string line;
            string TimeSheet_Line = "";
            string TimeSheetFileRead = "";
            int iloop = 0;
            DateTime MonDate;
            DateTime SunDate;
            string _sMonday;
            string _sMondayDay = "";
            string _sMondayMonth = "";
            string _sMondayYear = "";
            string _sTuesday;
            string _sWednesday;
            string _sThursday;
            string _sFriday;
            string _sSaturday;
            string _sSunday;
            string _rMonday;
            string _rMondayDay = "";
            string _rMondayMonth = "";
            string _rMondayYear = "";
            string _rTuesday;
            string _rWednesday;
            string _rThursday;
            string _rFriday;
            string _rSaturday;
            string _rSunday;
            string enableordisable = "";

            double _dTot;
            double _rTot;

            //get all time values for this timesheet
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string sqlGetTime = "select concat(a.month,-a.day, -a.year) as tDate, a.hours, b.timesheet_status_id,  " +
                                            " (select timesheet_status from ovms_timesheet_status where timesheet_status_id = b.timesheet_status_id and active = 1) as TimeSheet_Status_Name " +
                                            " from ovms_timesheet a, ovms_timesheet_details b " +
                                            " where a.employee_id =  " + Session["EmployeeIDForJob"].ToString() + " " +
                                            " and a.timesheet_id = b.timesheet_id " +
                                            " and a.active = 1 " +
                                            " and b.active = 1 ";
                    SqlCommand cmdGetTime = new SqlCommand(sqlGetTime, conn);
                    SqlDataReader rsGetTime = cmdGetTime.ExecuteReader();
                    //string _svendorList = "";
                    while (rsGetTime.Read())
                    {
                       sTimeValues = sTimeValues + rsGetTime["tDate"].ToString() + "," + rsGetTime["hours"].ToString() + "," + rsGetTime["TimeSheet_Status_Name"].ToString() + "@";
                    }
                    rsGetTime.Close();
                    cmdGetTime.Dispose();

                    string strsql = "";

                }
            }
            catch (Exception ex)
            {
                //
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

            if (Session["VendorID"].ToString() == "3" && Session["ClientID"].ToString() == "3")
            {
                for (iloop = 0; iloop <= Convert.ToInt32(ContractWeeks); iloop++)
                {
                    if (iloop == 0)
                    {
                        MonDate = Convert.ToDateTime(FirstMonday);
                        SunDate = Convert.ToDateTime(FirstSunday);
                    }
                    else
                    {
                        MonDate = AddWorkingDays(Convert.ToDateTime(FirstMonday), iloop * 5);
                        SunDate = AddWorkingDays(Convert.ToDateTime(FirstSunday), iloop * 5);
                        //MonDate = Convert.ToDateTime(FirstMonday),AddDays(iloop * 7 + 1);
                    }

                    //Monday
                    if (Convert.ToDateTime(MonDate).Day.ToString().Length == 1)
                    {
                        _sMonday = "0" + Convert.ToDateTime(MonDate).Day.ToString();
                        _rMonday = "0" + Convert.ToDateTime(MonDate).Day.ToString();
                        _sMondayDay = Convert.ToDateTime(MonDate).Day.ToString();
                        _sMondayMonth = Convert.ToDateTime(MonDate).Month.ToString();
                        _sMondayYear = Convert.ToDateTime(MonDate).Year.ToString();
                    }
                    else
                    {
                        _sMonday = Convert.ToDateTime(MonDate).Day.ToString();
                        _rMonday = Convert.ToDateTime(MonDate).Day.ToString();
                    }
                    //Tuesday
                    if (Convert.ToDateTime(MonDate).AddDays(1).Day.ToString().Length == 1)
                    {
                        _sTuesday = "0" + Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                        _rTuesday = "0" + Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                    }
                    else
                    {
                        _sTuesday = Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                        _rTuesday = Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                    }
                    //Wednesday
                    if (Convert.ToDateTime(MonDate).AddDays(2).Day.ToString().Length == 1)
                    {
                        _sWednesday = "0" + Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                        _rWednesday = "0" + Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                    }
                    else
                    {
                        _sWednesday = Convert.ToDateTime(MonDate).AddDays(2).Day.ToString();
                        _rWednesday = Convert.ToDateTime(MonDate).AddDays(2).Day.ToString();
                    }
                    //Thursday
                    if (Convert.ToDateTime(MonDate).AddDays(3).Day.ToString().Length == 1)
                    {
                        _sThursday = "0" + Convert.ToDateTime(MonDate).AddDays(3).Day.ToString();
                        _rThursday = "0" + Convert.ToDateTime(MonDate).AddDays(3).Day.ToString();
                    }
                    else
                    {
                        _sThursday = Convert.ToDateTime(MonDate).AddDays(3).Day.ToString();
                        _rThursday = Convert.ToDateTime(MonDate).AddDays(3).Day.ToString();
                    }
                    //Friday
                    if (Convert.ToDateTime(MonDate).AddDays(4).Day.ToString().Length == 1)
                    {
                        _sFriday = "0" + Convert.ToDateTime(MonDate).AddDays(4).Day.ToString();
                        _rFriday = "0" + Convert.ToDateTime(MonDate).AddDays(4).Day.ToString();
                    }
                    else
                    {
                        _sFriday = Convert.ToDateTime(MonDate).AddDays(4).Day.ToString();
                        _rFriday = Convert.ToDateTime(MonDate).AddDays(4).Day.ToString();
                    }
                    //Saturday
                    if (Convert.ToDateTime(MonDate).AddDays(5).Day.ToString().Length == 1)
                    {
                        _sSaturday = "0" + Convert.ToDateTime(MonDate).AddDays(5).Day.ToString();
                        _rSaturday = "0" + Convert.ToDateTime(MonDate).AddDays(5).Day.ToString();
                    }
                    else
                    {
                        _sSaturday = Convert.ToDateTime(MonDate).AddDays(5).Day.ToString();
                        _rSaturday = Convert.ToDateTime(MonDate).AddDays(5).Day.ToString();
                    }
                    //Sunday
                    if (Convert.ToDateTime(MonDate).AddDays(6).Day.ToString().Length == 1)
                    {
                        _sSunday = "0" + Convert.ToDateTime(MonDate).AddDays(6).Day.ToString();
                        _rSunday = "0" + Convert.ToDateTime(MonDate).AddDays(6).Day.ToString();
                    }
                    else
                    {
                        _sSunday = Convert.ToDateTime(MonDate).AddDays(6).Day.ToString();
                        _rSunday = Convert.ToDateTime(MonDate).AddDays(6).Day.ToString();
                    }

                    if (Between(DateTime.Today.Date, MonDate, SunDate) == true)
                    {
                        enableordisable = "";
                        _sBackground = "style='background:#FAFFBD;'";
                    }
                    else
                    {
                        enableordisable = "disabled";
                        //enableordisable = "";
                        _sBackground = "";
                        //_sBackground = "bgcolor='#FAFFBD'";
                    }
                    //load all values from database for this employeeID
                    _sTimeSheetLines = _sTimeSheetLines + 
                                    "<tr " + _sBackground + ">" +
                                    "    <td>" + iloop + "</td>" +
                                    "    <td>" + DateTime.Parse(MonDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" + DateTime.Parse(SunDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sMonday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn'>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sMonday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px'  data-toggle='tooltip' data-placement='top' name='abc' title=" + _sTuesday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtTue_" + iloop + "' id='txtTue_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sTuesday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sWednesday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtWed_" + iloop + "' id='txtWed_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn text-body-2'>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sWednesday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sThursday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtThu_" + iloop + "' id='txtThu_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sThursday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "           <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sFriday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtFri_" + iloop + "' id='txtFri_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sFriday + " </small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sSaturday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtSat_" + iloop + "' id='txtSat_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sSaturday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sSunday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtSun_" + iloop + "' id='txtSun_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>";
                    _dTot = Convert.ToDouble(CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString());

                    _sTimeSheetLines = _sTimeSheetLines + "   <td><input type='text' style='height: 15px;' class='txt form-control' id='txtTot_" + iloop + "' name='txtTot_" + iloop + "'  disabled value=" + _dTot.ToString() + "></td>";

                    if ((isLessThanToday(DateTime.Today.Date, MonDate)) && (_sBackground == ""))
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }
                    if (_sBackground != "")
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' class='btn btn-default' id='btnSubmit_" + iloop + "' onClick='doSubmit(" + iloop + "," + _sMonday + ", " + Convert.ToDateTime(MonDate).Month.ToString() + ", " + Convert.ToDateTime(MonDate).Year.ToString() + ");'>Submit</button></td>";
                    }
                    if (isMoreThanToday(DateTime.Today.Date, MonDate))
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default' onClick='do_NotSent();'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }

                    _sTimeSheetLines = _sTimeSheetLines + "</tr>";

                    _sTimeSheetLines += "<tr " + _sBackground + ">" +
                                    "    <td>" + iloop + "</td>" +
                                    "    <td>" + DateTime.Parse(MonDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" + DateTime.Parse(SunDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rMonday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rTuesday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rWednesday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rThursday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rFriday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rSaturday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rSunday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>";
                                    _rTot = Convert.ToDouble(CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString());
                    _sTimeSheetLines = _sTimeSheetLines + "   <td><input type='text' style='height: 15px;' class='txt form-control' id='txtTot_" + iloop + "' name='txtTot_" + iloop + "'  disabled value=" + _rTot.ToString() + "></td>";
                    if ((isLessThanToday(DateTime.Today.Date, MonDate)) && (_sBackground == ""))
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }
                    if (_sBackground != "")
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' class='btn btn-default' id='btnSubmit_" + iloop + "' onClick='doSubmit(" + iloop + "," + _sMonday + ", " + Convert.ToDateTime(MonDate).Month.ToString() + ", " + Convert.ToDateTime(MonDate).Year.ToString() + ");'>Submit</button></td>";
                    }
                    if (isMoreThanToday(DateTime.Today.Date, MonDate))
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default' onClick='do_NotSent();'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }

                    _sTimeSheetLines = _sTimeSheetLines + "</tr>";
                    _sTimeSheetLines += "<tr " + _sBackground + ">" +
                                    "    <td>" + iloop + "</td>" +
                                    "    <td>" + DateTime.Parse(MonDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" + DateTime.Parse(SunDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rMonday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rTuesday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rWednesday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rThursday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rFriday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rSaturday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _rSunday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    "        </div>" +
                                    "    </td>";
                    _rTot = Convert.ToDouble(CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString());
                    _sTimeSheetLines = _sTimeSheetLines + "   <td><input type='text' style='height: 15px;' class='txt form-control' id='txtTot_" + iloop + "' name='txtTot_" + iloop + "'  disabled value=" + _rTot.ToString() + "></td>";
                    if ((isLessThanToday(DateTime.Today.Date, MonDate)) && (_sBackground == ""))
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }
                    if (_sBackground != "")
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' class='btn btn-default' id='btnSubmit_" + iloop + "' onClick='doSubmit(" + iloop + "," + _sMonday + ", " + Convert.ToDateTime(MonDate).Month.ToString() + ", " + Convert.ToDateTime(MonDate).Year.ToString() + ");'>Submit</button></td>";
                    }
                    if (isMoreThanToday(DateTime.Today.Date, MonDate))
                    {
                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default' onClick='do_NotSent();'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }

                    _sTimeSheetLines = _sTimeSheetLines + "</tr>";
                    //increment loop
                    //iloop = iloop + 1;
                }
            }
        }
        else
        {

            _sTimeSheetLines = "<tr><td>" +
                                                                                       " <a class='btn btn-default' href='#'><i class='icon-user-1'></i> You are not assigned to a job yet, please contact your agency.</a>" +
                                                                                       " </td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " <td></td>" +
                                                                                       //" <td></td>" +
                                                                                       " <td></td>" +
                                                                                       " </tr>";
            divTable.Visible = false;
            lblNotAssigned.Text = _sTimeSheetLines;
        }
        lblTimeSheet.Text = _sTimeSheetLines;
    }

    public string CheckValTime(string sDay, string sMonth, string sYear)
    {
        string aHours = "";
        string aDatePassed = sMonth + "-" + sDay + "-" + sYear;
        if (sTimeValues != "")
        {
            string[] stringArray;
            try
            {
                stringArray = sTimeValues.Split('@');

                for (int ix = 0; ix < stringArray.Length; ix++)
                {
                    if (stringArray[ix].Split(',')[0].ToString().Trim() == aDatePassed.ToString().Trim())
                    {
                        //aHours = stringArray[ix].Split(',')[1].ToString();
                        aHours = stringArray[ix].Split(',')[1].ToString() + "," + stringArray[ix].Split(',')[2].ToString();

                        break;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        if (aHours == "")
        {
            aHours = "0,Not Sent";
        }
        //return
        return aHours;
    }
    public static bool Between(DateTime input, DateTime date1, DateTime date2)
    {
        return (input >= date1 && input <= date2);
    }

    public static bool isLessThanToday(DateTime input, DateTime date1)
    {
        return (input >= date1);
    }
    public static bool isMoreThanToday(DateTime input, DateTime date1)
    {
        return (input < date1);
    }

    public DateTime AddWorkingDays(DateTime dtFrom, int nDays)
    {
        // determine if we are increasing or decreasing the days
        int nDirection = 1;
        if (nDays < 0)
        {
            nDirection = -1;
        }

        // move ahead the day of week
        int nWeekday = nDays % 5;
        while (nWeekday != 0)
        {
            dtFrom = dtFrom.AddDays(nDirection);

            if (dtFrom.DayOfWeek != DayOfWeek.Saturday
                && dtFrom.DayOfWeek != DayOfWeek.Sunday)
            {
                nWeekday -= nDirection;
            }
        }

        // move ahead the number of weeks
        int nDayweek = (nDays / 5) * 7;
        dtFrom = dtFrom.AddDays(nDayweek);

        return dtFrom;
    }

    public void GetEmployeeID()
    {

        //select employee_ID from ovms_employees where job_id = 5 and user_id = 20
        string _sArrayString = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                // Session["JobID"] = jobID.ToString();

                //start, end and weeks
                string sqlGetEmployeeIDForJob = " select employee_ID " +
                                             " from ovms_employees " +
                                             " where job_id =  " + Session["JobID"].ToString().Trim() + "  " +
                                             " and user_id = " + Session["UserID"].ToString();
                SqlCommand cmdEmployeeID = new SqlCommand(sqlGetEmployeeIDForJob, conn);
                SqlDataReader rsGetEmployeeID = cmdEmployeeID.ExecuteReader();
                //string _svendorList = "";
                while (rsGetEmployeeID.Read())
                {
                    Session["EmployeeIDForJob"] = rsGetEmployeeID["employee_ID"].ToString();
                    //_sArrayString = rsStartEndWeeks["contract_Start_date"].ToString() + "," + rsStartEndWeeks["contract_end_date"].ToString() + "," + rsStartEndWeeks["Num_weeks"].ToString();

                }
                rsGetEmployeeID.Close();
                cmdEmployeeID.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        //return _sArrayString;
    }
    public string GetNumberOfWeeks()
    {
        string _sArrayString = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                //open connection
                conn.Open();

                API.Service timesheet = new API.Service();
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.LoadXml("<XML>" + timesheet.Add_TimeSheet(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
                string FileName = Server.MapPath("temp") + "\\response_get_timesheet_" + DateTime.Now.Millisecond.ToString() + ".xml";
                XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/TIMESHEET");
                // string weeks;
                // string timesheetVariable = "";
                string jobID = "";
                jobID = Response[0].SelectSingleNode("JOB_ID").InnerText;
                Session["JobID"] = jobID.ToString();

                //start, end and weeks
                string sqlGetStartEndWeeks = " select contract_Start_date, contract_end_date, " +
                                        " DATEDIFF(wk, contract_Start_date, contract_end_date + 7) as Num_weeks " +
                                        " from ovms_jobs where job_id =  " + Session["JobID"].ToString().Trim();
                SqlCommand cmdStartEndWeeks = new SqlCommand(sqlGetStartEndWeeks, conn);
                SqlDataReader rsStartEndWeeks = cmdStartEndWeeks.ExecuteReader();
                //string _svendorList = "";
                while (rsStartEndWeeks.Read())
                {
                    _sArrayString = rsStartEndWeeks["contract_Start_date"].ToString() + "," + rsStartEndWeeks["contract_end_date"].ToString() + "," + rsStartEndWeeks["Num_weeks"].ToString();
                }
                rsStartEndWeeks.Close();
                cmdStartEndWeeks.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sArrayString;
    }
    public string GetMonday(string StartDate)
    {
        string _sStartDate = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                //getJobs
                string sqlGetStartDate = " select DATEADD(DD, 1 - DATEPART(DW, '" + StartDate + "'), '" + StartDate + "') + 1 as startd ";
                SqlCommand cmdGetStartDate = new SqlCommand(sqlGetStartDate, conn);
                SqlDataReader rsGetStartDate = cmdGetStartDate.ExecuteReader();
                //string _svendorList = "";
                while (rsGetStartDate.Read())
                {
                    _sStartDate = rsGetStartDate["startd"].ToString();
                }
                rsGetStartDate.Close();
                cmdGetStartDate.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sStartDate;
    }

    public string GetSunday(string StartDate)
    {
        string _sEndDate = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                //getJobs
                string sqlGetEndDate = " select DATEADD(DAY , 7-DATEPART(WEEKDAY,'" + StartDate + "'),'" + StartDate + "') + 1  as endd ";
                SqlCommand cmdGetEndDate = new SqlCommand(sqlGetEndDate, conn);
                SqlDataReader rsGetEndDate = cmdGetEndDate.ExecuteReader();
                //string _svendorList = "";
                while (rsGetEndDate.Read())
                {
                    _sEndDate = rsGetEndDate["endd"].ToString();
                }
                rsGetEndDate.Close();
                cmdGetEndDate.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sEndDate;
    }

}