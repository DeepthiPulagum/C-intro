﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using API;
using System.Globalization;
using System.IO;

public partial class E_Dashboard : System.Web.UI.Page
{
    string FirstName = "";
    string LastName = "";
    string JobDescription = "";
    SqlConnection conn;
    string errString = "";
    StringFunctions func = new StringFunctions();
    emailFunctions semail = new emailFunctions();
    private int iResponseq;
    string for_Rfer_EMP_id = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (IsPostBack == true)
        {

            btnSendRequest.CausesValidation = false;
        }
        //semail.sendEmail("greg@opusing.com", "I love my mama", "She is so cute", "", "");
        if ((Session["Email"] == null) && (Session["contract_end"] == null))
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=Your+session+has+timed+out");
            Response.End();
        }
        if (Request["action"] != null)
        {
            lblAbsenceSent.Text = "<a href ='#' class='btn btn-success'>Thank you - Request has been sent<i class='fa fa-check-circle fa-fw'></i></a>";
        }
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

        //get other jobs
        API.Service web = new API.Service();

        // XmlDocument _xmlWorkers = new XmlDocument();

        //Create XML Stuff
        XmlDocument _xmlDoc = new XmlDocument();
        XmlNodeList nodeList;
        string _Error = "";
        int intCount = 1;
        //Load XML Element into document
        _xmlDoc.LoadXml("<XML>" + web.get_Recent_jobs(Session["Email"].ToString(), Session["P@ss"].ToString(), "4", Session["UserID"].ToString(), Session["VendorID"].ToString()).InnerXml + "</XML>");
        //loop through
        nodeList = _xmlDoc.SelectNodes("XML/RESPONSE/JOB_ID");
        string strGOTO = "";
        //declare variables

        string strjob = "";
        intCount = nodeList.Count;
        try
        {
            //_Error = nodeList[0].SelectSingleNode("JOB_ALIAS").InnerText;
            //_Error = nodeList[0].ChildNodes[0].SelectSingleNode("JOB_ALIAS").InnerText;
            _Error = nodeList[0].SelectSingleNode("JOB_ALIAS").InnerText;
        }
        catch (Exception ex)
        {
            _Error = "error";
        }
        if (_Error == "error")
        {
            strjob = strjob + @"<li class=""list-group-item"">" +
                                   @"<div id=""lbl1"" runat=""server"">" +
                                   @"No jobs have been added " +
                                   @"</div>" +
                                   @"</li>";
        }
        else
        {
            int i = 0;
            //loop through nodes
            foreach (XmlNode book in nodeList)
            {

                //job id show jobs
                strjob = strjob + @"<li class=""list-group-item"">" +
                                    @"<div id=""lbl1"" runat=""server"">" +
                                    @"		<span class='label label-default'>" + nodeList[i].SelectSingleNode("JOB_ALIAS").InnerText + "</span>&nbsp;<a href='E_JobDetails.aspx?jobID=" + nodeList[i].SelectSingleNode("JOB_ALIAS").InnerText + "'><b>" + func.FixString(nodeList[i].SelectSingleNode("JOB_TITLE").InnerText) + "</b><br>" +
                                    @"		" + nodeList[i].SelectSingleNode("NO_OF_OPENINGS").InnerText + " position(s) | " + func.FixString(nodeList[i].SelectSingleNode("LOCATION").InnerText) + " - " + nodeList[i].SelectSingleNode("DATE_CREATED").InnerText + "</a>" +
                                    @"</div>" +
                                    @"</li>";

                if (i == 0)
                {

                    strGOTO = @"<li class=""list-group-item text-right"" style=""text-align: right;"">" +
                                   @"<a class=""btn btn-primary"" href=""E_ViewJobs.aspx"">See All Jobs</a>" +
                                   @"</li>";
                }
                //<i class=""fa fa-fw fa-arrow-right""></i>
                //increment
                i = i + 1;
            }

        }
        lblshowrecentlyadded.Text = strjob + strGOTO;


        // GetPersonalInfo
        GetEmployeePersonalInfo();
        //OtherInfo
        GetEmployeeProfileAndOther();

    }
    public void GetEmployeePersonalInfo()
    {
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                //getJobs
                string strGetFullName = " select first_name, last_name, email_id from ovms_users where user_id = " + Session["UserID"].ToString();
                SqlCommand cmdGetFullName = new SqlCommand(strGetFullName, conn);
                SqlDataReader readerGetFullName = cmdGetFullName.ExecuteReader();
                //string _svendorList = "";
                while (readerGetFullName.Read())
                {
                    //  lblNameEmployee.Text = func.FixString(readerGetFullName["first_name"].ToString() + " " + readerGetFullName["last_name"].ToString());


                    //lblvendor.Text = readerVendorActivity["vendor_name"].ToString();
                    //lblVendors.Text  = reader["num_of_jobs"].ToString();
                }
                readerGetFullName.Close();
                cmdGetFullName.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }

    public void GetEmployeeProfileAndOther()
    {
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                //getJobs
                string strGetOtherInfo = @" select a.user_id, a.job_id,  a.employee_id UserIDEmployee, b.profile_picture_path, b.pay_rate, b.email, " +
                                        " (select job_title from ovms_jobs where job_id = a.job_id and active = 1) as job_title, " +
                                        " (select roles_and_responsibilities from ovms_job_details where job_id = a.job_id and active = 1) as job_desc, " +
                                        " (select Contract_start_date from ovms_jobs where job_id = a.job_id and active = 1) as contract_Start, " +
                                        " (select Contract_End_date from ovms_jobs where job_id = a.job_id and active = 1) as contract_End, " +
                                        " getdate() as todaydate, datediff(d, getdate(), (select Contract_End_date from ovms_jobs where job_id = a.job_id and active = 1)) as days_left, " +
                                        " datediff(d, (select Contract_start_date from ovms_jobs where job_id = a.job_id and active = 1), (select Contract_End_date from ovms_jobs where job_id = a.job_id and active = 1)) as total_days " +
                                        " from ovms_employees a, ovms_employee_details b " +
                                        " where a.employee_id = b.employee_id " +
                                        " and a.user_id = " + Session["UserID"].ToString();


                SqlCommand cmdGetOtherInfo = new SqlCommand(strGetOtherInfo.Replace("'", " "), conn);
                SqlDataReader readerGetOtherInfo = cmdGetOtherInfo.ExecuteReader();
                //string _svendorList = "";
                int DaysLeft = 0;

                if (readerGetOtherInfo.HasRows == true)
                {
                    lblEmployeeStatus.Text = "<a href ='#' class='btn btn-success'>Working<i class='fa fa-check-circle fa-fw'></i></a>";
                    Session["NotWorking"] = "false";
                }
                else
                {
                    lblEmployeeStatus.Text = "<a href ='#' class='btn btn-danger'>Not Working<i class='fa fa-times-circle fa-fw'></i></a>";
                    // lblRatePerHour.Text = "$0/hr";
                    Session["NotWorking"] = "true";
                }

                while (readerGetOtherInfo.Read())
                {
                    // lblRatePerHour.Text = "$" + readerGetOtherInfo["pay_rate"].ToString() + "/hr";
                    lblJobTitle.Text = readerGetOtherInfo["job_title"].ToString();
                    //  lblJobDescription.Text = Server.HtmlDecode( readerGetOtherInfo["job_desc"].ToString());
                    //lblNameEmployee.Text = readerGetOtherInfo["first_name"].ToString() + " " + readerGetFullName["last_name"].ToString();
                    ContractStart.Text = DateTime.Parse(readerGetOtherInfo["contract_Start"].ToString()).ToString("dd MMM, yyyy");
                    ContractEnd.Text = DateTime.Parse(readerGetOtherInfo["contract_End"].ToString()).ToString("dd MMM, yyyy");
                    DaysLeft = (Convert.ToInt32(readerGetOtherInfo["total_days"].ToString()) - Convert.ToInt32(readerGetOtherInfo["days_left"].ToString()));
                    lblPercent.Text = "<div data-percent='" + DaysLeft + "' data-size='100' class='easy-pie inline-block primary' data-scale-color='false' data-track-color='#efefef' data-line-width= '6'>";
                    //lblvendor.Text = readerVendorActivity["vendor_name"].ToString();
                    //lblVendors.Text  = reader["num_of_jobs"].ToString();
                    String jobid = readerGetOtherInfo["job_id"].ToString();
                    {
                        API.Service getWorkers = new API.Service();
                        XmlDocument dom1 = new XmlDocument();
                        dom1.LoadXml("<XML>" + getWorkers.get_Jobs(jobid, Session["Email"].ToString(), Session["P@ss"].ToString(), "", Session["UserID"].ToString(), "").InnerXml + "</XML>");
                        XmlNodeList Response = dom1.SelectNodes("XML/RESPONSE/JOBS");

                        lblJobDescription.Text = Server.HtmlDecode(Response[iResponseq].SelectSingleNode("JOB_DESC").InnerText);
                    }
                    GetRevenueforEmployee(readerGetOtherInfo["UserIDEmployee"].ToString(), readerGetOtherInfo["pay_rate"].ToString(), readerGetOtherInfo["total_days"].ToString(), "1");
                    GetRevenueforEmployee(readerGetOtherInfo["UserIDEmployee"].ToString(), readerGetOtherInfo["pay_rate"].ToString(), readerGetOtherInfo["total_days"].ToString(), "3");
                    GetTBARevenue(readerGetOtherInfo["UserIDEmployee"].ToString(), readerGetOtherInfo["pay_rate"].ToString(), readerGetOtherInfo["total_days"].ToString());

                    if (readerGetOtherInfo.HasRows == true)
                    {
                        double work_status = Convert.ToDouble(readerGetOtherInfo["days_left"].ToString());
                        //lblEmployeeStatus.Text = "<a href ='#' class='btn btn-success'>Working<i class='fa fa-check-circle fa-fw'></i></a>";
                        //Session["NotWorking"] = "false";
                        if (work_status > 0)
                        {
                            //lblEmployeeStatus.Text = "Working";
                            //Session["NotWorking"] = "false";
                            lblEmployeeStatus.Text = "<a href ='#' class='btn btn-success'>Working<i class='fa fa-check-circle fa-fw'></i></a>";
                            Session["NotWorking"] = "false";
                        }
                        else
                        {
                            lblEmployeeStatus.Text = "<a href ='#' class='btn btn-danger'>Contract Ended<i class='fa fa-times-circle fa-fw'></i></a>";
                            // lblRatePerHour.Text = "$0/hr";
                            Session["NotWorking"] = "true";
                        }
                    }
                    else
                    {
                        lblEmployeeStatus.Text = "<a href ='#' class='btn btn-danger'>Not Working<i class='fa fa-times-circle fa-fw'></i></a>";
                        //  lblRatePerHour.Text = "$0/hr";
                        Session["NotWorking"] = "true";
                    }


                }

                Session["contract_end"] = ContractEnd.Text;
                readerGetOtherInfo.Close();
                cmdGetOtherInfo.Dispose();
                //if (Request["H"] == "1")
                //{

                //    Response.Redirect("E_timesheet.aspx?topen=Y&p=EAT&nj=1", true);
                //    Response.End();
                //}
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }

    public void GetTBARevenue(string EmployeeID, string PayRate, string ContractLength)
    {
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                //getJobs
                string strTABRevenue = @" select sum(a.hours) as Ahours " +
                                            " from ovms_timesheet a, ovms_timesheet_details b " +
                                            " where a.timesheet_id = b.timesheet_id " +
                                            " and a.employee_id =  " + EmployeeID + " " +
                                            " and a.active = 1 " +
                                            " and b.active = 1 " +
                                            " and b.timesheet_status_id = 3  and a.hours > 0 ";
                for_Rfer_EMP_id = EmployeeID;
                SqlCommand cmdTBARevenue = new SqlCommand(strTABRevenue, conn);
                SqlDataReader readerTBARevenue = cmdTBARevenue.ExecuteReader();
                //string _svendorList = "";
                int DaysLeft = 0;

                if (readerTBARevenue.HasRows == false)
                {

                    lblPendingRevenue.Text = "$0";
                    //lblPossibleRevenue.Text = "$0";

                }

                double iRevenue = 0;
                while (readerTBARevenue.Read())
                {


                    //calculate
                    iRevenue = (Convert.ToDouble(readerTBARevenue["Ahours"].ToString()) * Convert.ToDouble(PayRate));

                    //if (TimeSheetStatus == "3") //possible revenue
                    //{
                    // lblPossibleRevenue.Text = "$0";
                    lblPendingRevenue.Text = string.Format("{0:c0}", iRevenue).ToString();
                    // }

                }
                lblPossibleRevenue.Text = string.Format("{0:c0}", (8 * Convert.ToDouble(PayRate) * Convert.ToDouble(ContractLength)));


                readerTBARevenue.Close();
                cmdTBARevenue.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }


    public void GetRevenueforEmployee(string EmployeeID, string PayRate, string ContractLength, string TimeSheetStatus)
    {
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                //getJobs
                string strGetPossibleRevenue = @" select a.employee_id, a.hours, a.overtime, b.timesheet_status_id " +
                                            " from ovms_timesheet a, ovms_timesheet_details b " +
                                            " where a.timesheet_id = b.timesheet_id " +
                                            " and a.employee_id =  " + EmployeeID + " " +
                                            " and a.active = 1 " +
                                            " and b.active = 1 " +
                                            " and b.timesheet_status_id = " + TimeSheetStatus;


                SqlCommand cmdGetPossibleRevenue = new SqlCommand(strGetPossibleRevenue.Replace("'", " "), conn);
                SqlDataReader readerGetPossibleRevenue = cmdGetPossibleRevenue.ExecuteReader();
                //string _svendorList = "";
                int DaysLeft = 0;

                if (readerGetPossibleRevenue.HasRows == false)
                {
                    if (TimeSheetStatus == "1")
                    {
                        lblRevenueThisFar.Text = "$0";
                    }
                    if (TimeSheetStatus == "3")
                    {
                        lblPendingRevenue.Text = "$0";
                    }
                }

                double iRevenue = 0;
                while (readerGetPossibleRevenue.Read())
                {

                    if (TimeSheetStatus == "1") //approved
                    {

                        //calculate
                        iRevenue = iRevenue + (Convert.ToDouble(readerGetPossibleRevenue["hours"].ToString()) * Convert.ToDouble(PayRate));
                    }
                    //if (TimeSheetStatus == "3") //possible revenue
                    //{
                    lblPossibleRevenue.Text = string.Format("{0:c0}", (8 * Convert.ToDouble(PayRate) * Convert.ToDouble(ContractLength)));
                    // }

                }
                if (TimeSheetStatus == "1")
                {

                    lblRevenueThisFar.Text = string.Format("{0:c0}", iRevenue);
                }
                Session["EmployeeID"] = EmployeeID;
                readerGetPossibleRevenue.Close();
                cmdGetPossibleRevenue.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }

    //

    protected void btnSendRequest_Click(object sender, EventArgs e)
    {
        //connect to database insert the request and send back to employee side and then notify request has been send
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                string sqlInsertRequest = " insert into ovms_requests (employee_id, vendor_id, client_id, requested_date, requested_Reason, requested_Comments, user_id) " +
                                           " values((select employee_id from ovms_employees where user_id = " + Session["UserID"].ToString() + " and active = 1), " + Session["VendorID"].ToString() + ", " + Session["ClientID"].ToString() + ", '" + datepicker.Value + "', '" + textreason.InnerText + "', '" + textcomment.InnerText + "', " + Session["UserID"].ToString() + ")";
                SqlCommand cmdInsertReq = new SqlCommand(sqlInsertRequest, conn);
                int ReqInsert = cmdInsertReq.ExecuteNonQuery();


                //close connection
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();

                Response.Redirect("E_Dashboard.aspx?action=RI");
                Response.End();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
    }


    //old code for refer friend
    //protected void btnreferAfriend_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("E_Dashboard.aspx?referAfriend=1");
    //}



    protected void btnrefer_Click(object sender, EventArgs e)
    {

        string jobId = lblJobId.Text;
        string name = TxtName.Text;
        string job = Txtjob.Text;
        string phone = Txtphone.Text;
        string email = Txtemail.Text;
        // string resume = FileUpload1.Load;

        string resumepath = Path.GetFileName(FileUpload1.FileName);
        string resume = Server.MapPath("~/") + resumepath;//FileUpload1;

        string comment = TextArea1.Value;
        //Response.Redirect("refer_frnd_page2.aspx?wopen=Y&jobid=" + Request.QueryString["jobID"] + "&p=AW&Name=" + name + "&Job=" + job + "&Phone=" + phone + "&Email=" + email + "&comment=" + comment);
        // Txtemail.Text = "";

        string empID = Session["EmployeeID"].ToString();
        //string cand_name = Request.QueryString["name"];
        //string jobname = Request.QueryString["job"];
        //string phone = Request.QueryString["phone"];
        string job_id = (Request.QueryString["jobID"].Substring(Request.QueryString["jobID"].Length - 7));
        //string email = Request.QueryString["Email"];
        //string resume = Request.QueryString["fileresume"];
        //string comments = Request.QueryString["comment"];
        API.Service refer = new API.Service();
        XmlDocument _xmlDoc1 = new XmlDocument();
        _xmlDoc1.LoadXml("<XML>" + refer.refer_a_frnd(Session["Email"].ToString(), Session["P@ss"].ToString(), empID, job, name, resume, comment, phone, email) + "</XML>");

        // _xmlDoc1.LoadXml("<XML>" + refer.refer_a_frnd(Session["Email"].ToString(), Session["P@ss"].ToString(), emp_id, "", job_id, resume, comment, phone, email).InnerXml + "</XML>");
        XmlNodeList ea = _xmlDoc1.SelectNodes("XML/RESPONSE");

        Response.Redirect("E_JobDetails.aspx?wopen=Y&p=VW&jobid=" + Request.QueryString["jobID"]);
        Response.End();

    }
}