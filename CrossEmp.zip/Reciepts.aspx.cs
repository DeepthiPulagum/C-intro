﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Reciepts : System.Web.UI.Page
{
    SqlConnection conn;
    string errString = "";
    StringFunctions func = new StringFunctions();
    string NumberOfWeeks = "";
    string FirstMonday = "";
    string FirstSunday = "";
    string LastContractDate = "";
    string ContractWeeks = "";
    string sTimeValues;
    string sMilesValues;
    string sReciepts;
    string _sBackground = "";
    string getlink = "";
    protected string viewdate = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        this.viewdate = Request.Form["viewdate"];
        string _sTimeSheetLines = "";
        string _carMilage = "";
        string _receipts = "";
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=Your+session+has+timed+out");
            Response.End();
        }
        if (Session["VendorID"].ToString() == "1012" && Session["ClientID"].ToString() == "12")
        {
            NumberOfWeeks = GetNumberOfWeeks();
            if (NumberOfWeeks != "")
            {
                FirstMonday = GetMonday(NumberOfWeeks.Split(',')[0].ToString());
                FirstSunday = GetSunday(NumberOfWeeks.Split(',')[0].ToString());
                ContractWeeks = NumberOfWeeks.Split(',')[2].ToString(); //week num
                LastContractDate = NumberOfWeeks.Split(',')[1].ToString(); //last contract date
                GetEmployeeID();
                Receipts_Table();
                //draw table but first read from file
                int counter = 0;
                string line;
                string TimeSheet_Line = "";
                string TimeSheetFileRead = "";
                int iloop = 0;
                DateTime MonDate;
                DateTime SunDate;
                string _sMonday;
                string _sMondayDay = "";
                string _sMondayMonth = "";
                string _sMondayYear = "";
                string _sTuesday;
                string _sWednesday;
                string _sThursday;
                string _sFriday;
                string _sSaturday;
                string _sSunday;
                string enableordisable = "";

                double _dTot;
                double _cTot;

                //get all time values for this timesheet
                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();

                        // Session["JobID"] = jobID.ToString();

                        //start, end and weeks
                        //string sqlGetTime = "select concat(month,-day, -year) as tDate, hours " +
                        //            " from ovms_timesheet where employee_id = " + Session["EmployeeIDForJob"].ToString();
                        string sqlGetTime = "select concat(a.month,-a.day, -a.year) as tDate, a.hours, b.timesheet_status_id,  " +
                                                " (select timesheet_status from ovms_timesheet_status where timesheet_status_id = b.timesheet_status_id and active = 1) as TimeSheet_Status_Name " +
                                                " from ovms_timesheet a, ovms_timesheet_details b " +
                                                " where a.employee_id =  " + Session["EmployeeIDForJob"].ToString() + " " +
                                                " and a.timesheet_id = b.timesheet_id " +
                                                " and a.active = 1 " +
                                                " and b.active = 1 ";
                        SqlCommand cmdGetTime = new SqlCommand(sqlGetTime, conn);
                        SqlDataReader rsGetTime = cmdGetTime.ExecuteReader();
                        //string _svendorList = "";
                        while (rsGetTime.Read())
                        {
                            sTimeValues = sTimeValues + rsGetTime["tDate"].ToString() + "," + rsGetTime["hours"].ToString() + "," + rsGetTime["TimeSheet_Status_Name"].ToString() + "@";

                        }
                        sqlGetTime = "select concat(a.month,-a.day, -a.year) as tDate, a.miles, b.car_milesstatus,  " +
                                                " (select status from ovms_car_milage_status where car_milesstatus = b.car_milesstatus and active = 1) as car_miles_Status  " +
                                                " from ovms_cars a, ovms_car_milage_details b " +
                                                " where a.employee_id = " + Session["EmployeeIDForJob"].ToString() + " " +
                                                " and a.car_id = b.car_id " +
                                                " and a.active = 1 " +
                                                " and b.active = 1 ";
                        cmdGetTime = new SqlCommand(sqlGetTime, conn);
                        rsGetTime = cmdGetTime.ExecuteReader();
                        while (rsGetTime.Read())
                        {
                            sMilesValues = sMilesValues + rsGetTime["tDate"].ToString() + "," + rsGetTime["miles"].ToString() + "," + rsGetTime["car_miles_Status"].ToString() + "@";

                        }
                        rsGetTime.Close();
                        cmdGetTime.Dispose();

                    }
                }
                catch (Exception ex)
                {
                    //
                }
                finally
                {
                    if (conn.State == System.Data.ConnectionState.Open)
                        conn.Close();
                }
                for (iloop = 0; iloop <= Convert.ToInt32(ContractWeeks); iloop++)
                {
                    if (iloop == 0)
                    {
                        MonDate = Convert.ToDateTime(FirstMonday);
                        SunDate = Convert.ToDateTime(FirstSunday);
                    }
                    else
                    {
                        MonDate = AddWorkingDays(Convert.ToDateTime(FirstMonday), iloop * 5);
                        SunDate = AddWorkingDays(Convert.ToDateTime(FirstSunday), iloop * 5);
                        //MonDate = Convert.ToDateTime(FirstMonday),AddDays(iloop * 7 + 1);
                    }

                    //Monday
                    if (Convert.ToDateTime(MonDate).Day.ToString().Length == 1)
                    {
                        _sMonday = "0" + Convert.ToDateTime(MonDate).Day.ToString();
                        _sMondayDay = Convert.ToDateTime(MonDate).Day.ToString();
                        _sMondayMonth = Convert.ToDateTime(MonDate).Month.ToString();
                        _sMondayYear = Convert.ToDateTime(MonDate).Year.ToString();
                    }
                    else
                    {
                        _sMonday = Convert.ToDateTime(MonDate).Day.ToString();
                    }
                    //Tuesday
                    if (Convert.ToDateTime(MonDate).AddDays(1).Day.ToString().Length == 1)
                    {
                        _sTuesday = "0" + Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                    }
                    else
                    {
                        _sTuesday = Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                    }
                    //Wednesday
                    if (Convert.ToDateTime(MonDate).AddDays(2).Day.ToString().Length == 1)
                    {
                        _sWednesday = "0" + Convert.ToDateTime(MonDate).AddDays(1).Day.ToString();
                    }
                    else
                    {
                        _sWednesday = Convert.ToDateTime(MonDate).AddDays(2).Day.ToString();
                    }
                    //Thursday
                    if (Convert.ToDateTime(MonDate).AddDays(3).Day.ToString().Length == 1)
                    {
                        _sThursday = "0" + Convert.ToDateTime(MonDate).AddDays(3).Day.ToString();
                    }
                    else
                    {
                        _sThursday = Convert.ToDateTime(MonDate).AddDays(3).Day.ToString();
                    }
                    //Friday
                    if (Convert.ToDateTime(MonDate).AddDays(4).Day.ToString().Length == 1)
                    {
                        _sFriday = "0" + Convert.ToDateTime(MonDate).AddDays(4).Day.ToString();
                    }
                    else
                    {
                        _sFriday = Convert.ToDateTime(MonDate).AddDays(4).Day.ToString();
                    }
                    //Saturday
                    if (Convert.ToDateTime(MonDate).AddDays(5).Day.ToString().Length == 1)
                    {
                        _sSaturday = "0" + Convert.ToDateTime(MonDate).AddDays(5).Day.ToString();
                    }
                    else
                    {
                        _sSaturday = Convert.ToDateTime(MonDate).AddDays(5).Day.ToString();
                    }
                    //Sunday
                    if (Convert.ToDateTime(MonDate).AddDays(6).Day.ToString().Length == 1)
                    {
                        _sSunday = "0" + Convert.ToDateTime(MonDate).AddDays(6).Day.ToString();
                    }
                    else
                    {
                        _sSunday = Convert.ToDateTime(MonDate).AddDays(6).Day.ToString();
                    }

                    if (Between(DateTime.Today.Date, MonDate, SunDate) == true)
                    {
                        enableordisable = "";
                        _sBackground = "style='background:#FFF;'";
                        if (InBetween(DateTime.Today.Date, MonDate, SunDate) == true)
                        { _sBackground = "style='background:#FAFFBD;'"; }
                    }
                    else
                    {
                        enableordisable = "disabled";
                        //enableordisable = "";
                        _sBackground = "";
                        //_sBackground = "bgcolor='#FAFFBD'";
                    }
                    //load all values from database for this employeeID

                    if ((isLessThanToday(DateTime.Today.Date, MonDate)) && (_sBackground == ""))
                    {
                        //     _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }
                    if (_sBackground != "")
                    {
                        /* Timesheets Begin */
                        _sTimeSheetLines = _sTimeSheetLines + "<tr " + _sBackground + ">" +
                                    "    <td>" + iloop + "</td>" +
                                    "    <td>" + DateTime.Parse(MonDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" + DateTime.Parse(SunDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sMonday + " onkeypress='return isNumberKey(event)'  value='" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtMon_" + iloop + "' id='txtMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn'>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sMonday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px'  data-toggle='tooltip' data-placement='top' name='abc' title=" + _sTuesday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtTue_" + iloop + "' id='txtTue_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sTuesday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sWednesday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtWed_" + iloop + "' id='txtWed_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn text-body-2'>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sWednesday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sThursday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtThu_" + iloop + "' id='txtThu_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sThursday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "           <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sFriday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtFri_" + iloop + "' id='txtFri_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sFriday + " </small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sSaturday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtSat_" + iloop + "' id='txtSat_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sSaturday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sSunday + " onkeypress='return isNumberKey(event)' value='" + CheckValTime(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='txtSun_" + iloop + "' id='txtSun_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sSunday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>";
                        _dTot = Convert.ToDouble(CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValTime(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString());

                        _sTimeSheetLines = _sTimeSheetLines + "   <td><input type='text' style='height: 15px;' class='txt form-control' id='txtTot_" + iloop + "' name='txtTot_" + iloop + "'  disabled value=" + _dTot.ToString() + "></td>";

                        _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' class='btn btn-primary' id='btnSubmit_" + iloop + "' onClick='doSubmit(" + iloop + "," + _sMonday + ", " + Convert.ToDateTime(MonDate).Month.ToString() + ", " + Convert.ToDateTime(MonDate).Year.ToString() + ");'>Submit</button></td>";

                        /* end of timesheets */

                        /* Car Milage */
                        _carMilage = _carMilage + "<tr " + _sBackground + ">" +
                                    "    <td>" + iloop + "</td>" +
                                    "    <td>" + DateTime.Parse(MonDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" + DateTime.Parse(SunDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px;' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sMonday + " onkeypress='return isNumberKey(event)'  value='" + CheckValCar(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carMon_" + iloop + "' id='carMon_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn'>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sMonday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px'  data-toggle='tooltip' data-placement='top' name='abc' title=" + _sTuesday + " onkeypress='return isNumberKey(event)' value='" + CheckValCar(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carTue_" + iloop + "' id='carTue_" + iloop + "'  onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sTuesday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sWednesday + " onkeypress='return isNumberKey(event)' value='" + CheckValCar(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carWed_" + iloop + "' id='carWed_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn text-body-2'>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sWednesday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sThursday + " onkeypress='return isNumberKey(event)' value='" + CheckValCar(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carThu_" + iloop + "' id='carThu_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sThursday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "           <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sFriday + " onkeypress='return isNumberKey(event)' value='" + CheckValCar(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carFri_" + iloop + "' id='carFri_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sFriday + " </small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sSaturday + " onkeypress='return isNumberKey(event)' value='" + CheckValCar(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carSat_" + iloop + "' id='carSat_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sSaturday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <input type='text' style='height: 15px; width:25px' data-toggle='tooltip' data-placement='top' name='abc' title=" + _sSunday + " onkeypress='return isNumberKey(event)' value='" + CheckValCar(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString() + "' class='form-control' " + enableordisable + " name='carSun_" + iloop + "' id='carSun_" + iloop + "' onchange='doSum(" + iloop + ");'>" +
                                    //"            <span class='input-group-btn '>" +
                                    //"                <button disabled class='btn btn-default'><small>" + _sSunday + "</small></button>" +
                                    //"            </span>" +
                                    "        </div>" +
                                    "    </td>";
                        _cTot = Convert.ToDouble(CheckValCar(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString());

                        _carMilage = _carMilage + "   <td><input type='text' style='height: 15px;' class='txt form-control' id='carTot_" + iloop + "' name='carTot_" + iloop + "'  disabled value=" + _cTot.ToString() + "></td>";

                        _carMilage = _carMilage + " <td><button style='height: 15px;' class='btn btn-primary' id='btnSubmitCar_" + iloop + "' onClick='doCarSubmit(" + iloop + "," + _sMonday + ", " + Convert.ToDateTime(MonDate).Month.ToString() + ", " + Convert.ToDateTime(MonDate).Year.ToString() + ");'>Submit</button></td>";


                        /* End of Car Milage */

                        /* Reciepts start */

                        /* Car Milage */
                        _receipts = _receipts + "<tr " + _sBackground + ">" +
                                    "    <td>" + iloop + "</td>" +
                                    "    <td>" + DateTime.Parse(MonDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" + DateTime.Parse(SunDate.ToString()).ToString("dd MMM, yyyy") + "</td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <label class='plusmark' href='Monday_" + MonDate.AddDays(0).Day.ToString() + "-" + MonDate.AddDays(0).Month.ToString() + "-" + MonDate.AddDays(0).Year.ToString() + "'><i title=" + _sMonday + enableordisable + " name='recMon_" + iloop + "' id='recMon_" + iloop + "' class='mdi mdi-library-plus'></i></a>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <label class='plusmark' href='Tuesday_" + MonDate.AddDays(1).Day.ToString() + "-" + MonDate.AddDays(1).Month.ToString() + "-" + MonDate.AddDays(1).Year.ToString() + "'><i title=" + _sTuesday + enableordisable + " name='recTue_" + iloop + "' id='recTue_" + iloop + "' class='mdi mdi-library-plus'></i></label>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <label class='plusmark' href='Wensday_" + MonDate.AddDays(2).Day.ToString() + "-" + MonDate.AddDays(2).Month.ToString() + "-" + MonDate.AddDays(2).Year.ToString() + "'><i title=" + _sWednesday + enableordisable + " name='recWed_" + iloop + "' id='recWed_" + iloop + "' class='mdi mdi-library-plus'></i></label>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <label class='plusmark' href='Thrusday_" + MonDate.AddDays(3).Day.ToString() + "-" + MonDate.AddDays(3).Month.ToString() + "-" + MonDate.AddDays(3).Year.ToString() + "'><i title=" + _sThursday + enableordisable + " name='recThr_" + iloop + "' id='recThr_" + iloop + "' class='mdi mdi-library-plus'></i></label>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "           <label class='plusmark' href='Friday_" + MonDate.AddDays(4).Day.ToString() + "-" + MonDate.AddDays(4).Month.ToString() + "-" + MonDate.AddDays(4).Year.ToString() + "'><i title=" + _sFriday + enableordisable + " name='recFri_" + iloop + "' id='recFri_" + iloop + "' class='mdi mdi-library-plus'></i></label>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <label class='plusmark' href='Saturday_" + MonDate.AddDays(5).Day.ToString() + "-" + MonDate.AddDays(5).Month.ToString() + "-" + MonDate.AddDays(5).Year.ToString() + "'><i title=" + _sSaturday + enableordisable + " name='recSat_" + iloop + "' id='recSat_" + iloop + "' class='mdi mdi-library-plus'></i></label>" +
                                    "        </div>" +
                                    "    </td>" +
                                    "    <td>" +
                                    "        <div>" +
                                    "            <label class='plusmark' href='Sunday_" + MonDate.AddDays(6).Day.ToString() + "-" + MonDate.AddDays(6).Month.ToString() + "-" + MonDate.AddDays(6).Year.ToString() + "'><i title=" + _sSunday + enableordisable + " name='recSun_" + iloop + "' id='recSun_" + iloop + "' class='mdi mdi-library-plus'></i></label>" +
                                    "        </div>" +
                                    "    </td>";

                        //_cTot = Convert.ToDouble(CheckValCar(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(1).Day.ToString(), MonDate.AddDays(1).Month.ToString(), MonDate.AddDays(1).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(2).Day.ToString(), MonDate.AddDays(2).Month.ToString(), MonDate.AddDays(2).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(3).Day.ToString(), MonDate.AddDays(3).Month.ToString(), MonDate.AddDays(3).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(4).Day.ToString(), MonDate.AddDays(4).Month.ToString(), MonDate.AddDays(4).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(5).Day.ToString(), MonDate.AddDays(5).Month.ToString(), MonDate.AddDays(5).Year.ToString()).Split(',')[0].ToString()) + Convert.ToDouble(CheckValCar(MonDate.AddDays(6).Day.ToString(), MonDate.AddDays(6).Month.ToString(), MonDate.AddDays(6).Year.ToString()).Split(',')[0].ToString());

                        //_receipts = _receipts + "   <td><input type='text' style='height: 15px;' class='txt form-control' id='carTot_" + iloop + "' name='carTot_" + iloop + "'  disabled value=" + _cTot.ToString() + "></td>";

                        //_receipts = _receipts + " <td><button style='height: 15px;' class='btn btn-primary' id='btnSubmit_" + iloop + "' onClick='doCarSubmit(" + iloop + "," + _sMonday + ", " + Convert.ToDateTime(MonDate).Month.ToString() + ", " + Convert.ToDateTime(MonDate).Year.ToString() + ");'>Submit</button></td>";


                        /* End of Reciepts */
                    }
                    if (isMoreThanToday(DateTime.Today.Date, MonDate))
                    {
                        //   _sTimeSheetLines = _sTimeSheetLines + " <td><button style='height: 15px;' disabled class='btn btn-default' onClick='do_NotSent();'>" + CheckValTime(MonDate.AddDays(0).Day.ToString(), MonDate.AddDays(0).Month.ToString(), MonDate.AddDays(0).Year.ToString()).Split(',')[1].ToString() + "</button></td>";
                    }

                    _sTimeSheetLines = _sTimeSheetLines + "</tr>";

                    _carMilage = _carMilage + "</tr>";

                    _receipts = _receipts + "</tr>";
                    //increment loop
                    //iloop = iloop + 1;
                }
            }
            else
            {
                /* Timesheet Begin */
                _sTimeSheetLines = "<tr><td>" +
                                                                                           " <a class='btn btn-default' href='#'><i class='icon-user-1'></i> You are not assigned to a job yet, please contact your agency.</a>" +
                                                                                           " </td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           //" <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " </tr>";
                divTable.Visible = false;
                lblNotAssigned.Text = _sTimeSheetLines;
                /* End of Timesheet */

                /* Car Milage */
                _carMilage = "<tr><td>" +
                                                                                           " <a class='btn btn-default' href='#'><i class='icon-user-1'></i> You are not assigned to a job yet, please contact your agency.</a>" +
                                                                                           " </td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " <td></td>" +
                                                                                           //" <td></td>" +
                                                                                           " <td></td>" +
                                                                                           " </tr>";
                divcar.Visible = false;
                lblNotAssignedcarmilage.Text = _carMilage;

                /* End of car milage */

                /* Receipts */
                _receipts = "<tr><td>" +
                                                                                               " <a class='btn btn-default' href='#'><i class='icon-user-1'></i> You are not assigned to a job yet, please contact your agency.</a>" +
                                                                                               " </td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " <td></td>" +
                                                                                               //" <td></td>" +
                                                                                               " <td></td>" +
                                                                                               " </tr>";
                div_reciepts.Visible = false;
                lblNotAssignedreceipts.Text = _receipts;

                /* End of car reciepts*/
            }
            lblTimeSheet.Text = _sTimeSheetLines;
            lblcarmilage.Text = _carMilage;
            lblreceipts.Text = _receipts;
        }
    }

    public string CheckValTime(string sDay, string sMonth, string sYear)
    {
        string aHours = "";
        string aDatePassed = sMonth + "-" + sDay + "-" + sYear;
        if (sTimeValues != "")
        {
            string[] stringArray;
            try
            {
                stringArray = sTimeValues.Split('@');

                for (int ix = 0; ix < stringArray.Length; ix++)
                {
                    if (stringArray[ix].Split(',')[0].ToString().Trim() == aDatePassed.ToString().Trim())
                    {
                        //aHours = stringArray[ix].Split(',')[1].ToString();
                        aHours = stringArray[ix].Split(',')[1].ToString() + "," + stringArray[ix].Split(',')[2].ToString();

                        break;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        if (aHours == "")
        {
            aHours = "0,Not Sent";
        }
        //return
        return aHours;
    }

    public string CheckValCar(string sDay, string sMonth, string sYear)
    {
        string aMiles = "";
        string aDatePassed = sMonth + "-" + sDay + "-" + sYear;
        if (sMilesValues != "")
        {
            string[] stringArray;
            try
            {
                stringArray = sMilesValues.Split('@');

                for (int ix = 0; ix < stringArray.Length; ix++)
                {
                    if (stringArray[ix].Split(',')[0].ToString().Trim() == aDatePassed.ToString().Trim())
                    {
                        //aHours = stringArray[ix].Split(',')[1].ToString();
                        aMiles = stringArray[ix].Split(',')[1].ToString() + "," + stringArray[ix].Split(',')[2].ToString();

                        break;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        if (aMiles == "")
        {
            aMiles = "0,Not Sent";
        }
        //return
        return aMiles;
    }

    public string receiptsvalue(string sDay, string sMonth, string sYear)
    {
        string amountrec = "";
        string aDatePassed = sMonth + "-" + sDay + "-" + sYear;
        if (sMilesValues != "")
        {
            string[] stringArray;
            try
            {

            }
            catch (Exception ex)
            { }
            finally
            { }
        }
        return amountrec;
    }
    public static bool Between(DateTime input, DateTime date1, DateTime date2)
    {
        getMonday values = new getMonday();
        DateTime convert_prev_monday1 = Convert.ToDateTime(values.getMondays(DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd h:mm tt")));
        DateTime convert_prev_monday2 = Convert.ToDateTime(values.getMondays(DateTime.Now.AddDays(-14).ToString("yyyy-MM-dd h:mm tt")));
        if (convert_prev_monday1.Date == date1.Date || convert_prev_monday2.Date == date1.Date)
        {
            string dateofprev = values.getMondays(date1.ToString("yyyy-MM-dd h:mm tt"));
            if (convert_prev_monday2.Date == date1.Date)
                return ((DateTime.Now.AddDays(-14) >= Convert.ToDateTime(dateofprev)) && (DateTime.Now.AddDays(-14) <= date2));
            else
                return ((DateTime.Now.AddDays(-7) >= Convert.ToDateTime(dateofprev)) && (DateTime.Now.AddDays(-14) <= date2));
        }
        else
        {
            return (input >= date1 && input <= date2);
        }

        //return (input >= date1 && input <= date2);
    }

    public static bool InBetween(DateTime input, DateTime date1, DateTime date2)
    {
        return (input >= date1 && input <= date2);
    }

    public static bool isLessThanToday(DateTime input, DateTime date1)
    {
        return (input >= date1);
    }
    public static bool isMoreThanToday(DateTime input, DateTime date1)
    {
        return (input < date1);
    }

    public DateTime AddWorkingDays(DateTime dtFrom, int nDays)
    {
        // determine if we are increasing or decreasing the days
        int nDirection = 1;
        if (nDays < 0)
        {
            nDirection = -1;
        }

        // move ahead the day of week
        int nWeekday = nDays % 5;
        while (nWeekday != 0)
        {
            dtFrom = dtFrom.AddDays(nDirection);

            if (dtFrom.DayOfWeek != DayOfWeek.Saturday
                && dtFrom.DayOfWeek != DayOfWeek.Sunday)
            {
                nWeekday -= nDirection;
            }
        }

        // move ahead the number of weeks
        int nDayweek = (nDays / 5) * 7;
        dtFrom = dtFrom.AddDays(nDayweek);

        return dtFrom;
    }

    public void GetEmployeeID()
    {

        //select employee_ID from ovms_employees where job_id = 5 and user_id = 20
        string _sArrayString = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                // Session["JobID"] = jobID.ToString();

                //start, end and weeks
                string sqlGetEmployeeIDForJob = " select employee_ID " +
                                             " from ovms_employees " +
                                             " where job_id =  " + Session["JobID"].ToString().Trim() + "  " +
                                             " and user_id = " + Session["UserID"].ToString();
                SqlCommand cmdEmployeeID = new SqlCommand(sqlGetEmployeeIDForJob, conn);
                SqlDataReader rsGetEmployeeID = cmdEmployeeID.ExecuteReader();
                //string _svendorList = "";
                while (rsGetEmployeeID.Read())
                {
                    Session["EmployeeIDForJob"] = rsGetEmployeeID["employee_ID"].ToString();
                    //_sArrayString = rsStartEndWeeks["contract_Start_date"].ToString() + "," + rsStartEndWeeks["contract_end_date"].ToString() + "," + rsStartEndWeeks["Num_weeks"].ToString();

                }
                rsGetEmployeeID.Close();
                cmdEmployeeID.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        //return _sArrayString;
    }
    public string GetNumberOfWeeks()
    {
        string _sArrayString = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                //open connection
                conn.Open();

                API.Service timesheet = new API.Service();
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.LoadXml("<XML>" + timesheet.Add_TimeSheet(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
                string FileName = Server.MapPath("temp") + "\\response_get_timesheet_" + DateTime.Now.Millisecond.ToString() + ".xml";
                XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/TIMESHEET");
                // string weeks;
                // string timesheetVariable = "";
                string jobID = "";
                jobID = Response[0].SelectSingleNode("JOB_ID").InnerText;
                Session["JobID"] = jobID.ToString();

                //start, end and weeks
                string sqlGetStartEndWeeks = " select contract_Start_date, contract_end_date, " +
                                        " DATEDIFF(wk, contract_Start_date, contract_end_date + 7) as Num_weeks " +
                                        " from ovms_jobs where job_id =  " + Session["JobID"].ToString().Trim();
                SqlCommand cmdStartEndWeeks = new SqlCommand(sqlGetStartEndWeeks, conn);
                SqlDataReader rsStartEndWeeks = cmdStartEndWeeks.ExecuteReader();
                //string _svendorList = "";
                while (rsStartEndWeeks.Read())
                {
                    _sArrayString = rsStartEndWeeks["contract_Start_date"].ToString() + "," + rsStartEndWeeks["contract_end_date"].ToString() + "," + rsStartEndWeeks["Num_weeks"].ToString();
                }
                rsStartEndWeeks.Close();
                cmdStartEndWeeks.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sArrayString;
    }
    public string GetMonday(string StartDate)
    {
        string _sStartDate = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                //getJobs
                string sqlGetStartDate = " select DATEADD(DD, 1 - DATEPART(DW, '" + StartDate + "'), '" + StartDate + "') + 1 as startd ";
                SqlCommand cmdGetStartDate = new SqlCommand(sqlGetStartDate, conn);
                SqlDataReader rsGetStartDate = cmdGetStartDate.ExecuteReader();
                //string _svendorList = "";
                while (rsGetStartDate.Read())
                {
                    _sStartDate = rsGetStartDate["startd"].ToString();
                }
                rsGetStartDate.Close();
                cmdGetStartDate.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sStartDate;
    }

    public string GetSunday(string StartDate)
    {
        string _sEndDate = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                //getJobs
                string sqlGetEndDate = " select DATEADD(DAY , 7-DATEPART(WEEKDAY,'" + StartDate + "'),'" + StartDate + "') + 1  as endd ";
                SqlCommand cmdGetEndDate = new SqlCommand(sqlGetEndDate, conn);
                SqlDataReader rsGetEndDate = cmdGetEndDate.ExecuteReader();
                //string _svendorList = "";
                while (rsGetEndDate.Read())
                {
                    _sEndDate = rsGetEndDate["endd"].ToString();
                }
                rsGetEndDate.Close();
                cmdGetEndDate.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sEndDate;
    }


    protected void details_submit_Click(object sender, EventArgs e)
    {
        //string []datestore = todaysdate.Text.Split('_');
        //datestore = viewdate.Split('_');
        //HtmlControl ctrl = (HtmlControl)this.FindControl("todaysdate");
        //getlink = HttpContext.Current.Request.Url.AbsoluteUri;
        //getlink = HttpContext.Current.Request.Url.PathAndQuery;
        this.viewdate = Request.Form["viewdate"];
        string[] datestore = viewdate.ToString().Split('_');
        string fulldate = datestore[1].ToString();
        datestore = datestore[1].Split('-');
        string txtdate = datestore[0].ToString();
        string txtmonth = datestore[1].ToString();
        string txtyear = datestore[2].ToString();
        string fileExtension = "", recieptname = "";
        string receipt_store = "";

        try
        {
            rec_upload.PostedFile.ContentType.ToLower();
            if (rec_upload.HasFile && rec_upload.PostedFiles.All(x => x.ContentLength < 52428800))
            {
                foreach (var file in rec_upload.PostedFiles)
                {
                    if (file.ContentType == "application/pdf" || file.ContentType == "image/jpeg" || file.ContentType == "image/png" || file.ContentType == "image/gif")
                    {
                        if (Directory.Exists(Server.MapPath("~/Reciepts/" + Session["JobID"].ToString().Trim() + "/" + Session["EmployeeID"].ToString().Trim() + "/" + fulldate + "/")) == false)
                        {
                            DirectoryInfo di = Directory.CreateDirectory(Server.MapPath("~/Reciepts/" + Session["JobID"].ToString().Trim() + "/" + Session["EmployeeID"].ToString().Trim() + "/" + fulldate.Trim() + "/"));
                        }
                        file.SaveAs(Server.MapPath("~/Reciepts/" + Session["JobID"].ToString().Trim() + "/" + Session["EmployeeID"].ToString().Trim() + "/" + fulldate.Trim() + "/") + (file.FileName).Trim());
                        receipt_store += HttpContext.Current.Request.Url.Host + "/Reciepts/" + Session["JobID"].ToString().Trim() + "/" + Session["EmployeeID"].ToString().Trim() + "/" + fulldate.Trim() + "/" + (file.FileName).Trim() + ',';
                    }
                    else
                    {

                        throw new Exception();
                    }
                }
            }
            else
            {
                RegularExpressionValidator1.ForeColor = System.Drawing.Color.Red;
                RegularExpressionValidator1.ErrorMessage = "Maximum file size(50 MB) exceeded";
            }
            SqlConnection conn;
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                string deleteoldrec = " Delete from ovms_reciepts where date = '" + txtdate + "' and month = '" + txtmonth + "' and year = '" + txtyear + "' and employee_id='" + Session["EmployeeID"].ToString().Trim() + "' and job_id='" + Session["JobID"].ToString().Trim() + "'";
                SqlCommand cmdDeleteOldrec = new SqlCommand(deleteoldrec, conn);
                SqlDataReader delreader = cmdDeleteOldrec.ExecuteReader();
                cmdDeleteOldrec.Dispose();
                delreader.Close();

                string insertrec = "insert into ovms_reciepts(employee_id, job_id, user_id, amount, date, month, year, Description, links, createdate) " +
                                  " values(" + Session["EmployeeID"].ToString() + ", " + Session["JobID"].ToString() + ", " + Session["UserID"].ToString() + ", " +
                                   amt_rec.Value + ", " + txtdate + ", " + txtmonth + ", " + txtyear + ", '" + rec_text.Value + "', '" + receipt_store + "', CURRENT_TIMESTAMP) ";

                SqlCommand cmdinsert = new SqlCommand(insertrec, conn);
                SqlDataReader insertread = cmdinsert.ExecuteReader();
                cmdinsert.Dispose();
                insertread.Close();

            }
        }
        catch (Exception ex)
        {
            RegularExpressionValidator1.ForeColor = System.Drawing.Color.Red;
            RegularExpressionValidator1.ErrorMessage = "Your details are not submited as your upload files are not of type pdf/jpeg/gif/png or file size exceeded 50MB";
            // EventHandler slit_string_Click = null;
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "slit_string",  "ClickLink();",  true);
            // slit_string.ServerClick += (slit_string_Click); ;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + " Your details are not submited as your upload files are not of type pdf/jpeg/gif/png or file size exceeded 50MB. " + "')", true);
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
            Receipts_Table();
        }

    }

    protected void Receipts_Table()
    {
        SqlConnection connect;
        connect = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        DateTime MonDate;
        DateTime SunDate;
        string sqlGetTime = "";
        sReciepts = "<tbody>";
        try
        {
            if (connect.State == System.Data.ConnectionState.Closed)
            {
                connect.Open();
                for (int getdatesloop = 0; getdatesloop <= Convert.ToInt32(ContractWeeks); getdatesloop++)
                {
                    if (getdatesloop == 0)
                    {
                        MonDate = Convert.ToDateTime(FirstMonday);
                        SunDate = Convert.ToDateTime(FirstSunday);

                        if (Between(DateTime.Today.Date, MonDate, SunDate) == true)
                        {
                            string[] datesarray = MonDate.ToString().Split(' ');
                            datesarray = datesarray[0].Split('/');
                            string months = datesarray[0];
                            int dates = Int32.Parse(datesarray[1].ToString());
                            int fridaysup = dates + 6;
                            string years = datesarray[2];
                            sqlGetTime = "select * from ovms_reciepts where employee_id ='" + Session["EmployeeID"].ToString() + "' and job_id ='" + Session["JobID"].ToString() + "' and (date>='" + dates + "' and date<='" + fridaysup + "') and month = '" + months + "' and year ='" + years + "'";
                            SqlCommand cmdGetTime = new SqlCommand(sqlGetTime, connect);
                            SqlDataReader rsGetTime = cmdGetTime.ExecuteReader();
                            while (rsGetTime.Read())
                            {
                                sReciepts = sReciepts + "<tr>";
                                sReciepts += "<td>" + rsGetTime["Description"].ToString() + "</td>" + "<td>" + rsGetTime["amount"].ToString() + "</td>";
                                sReciepts += "<td>" + rsGetTime["date"].ToString() + "-" + rsGetTime["month"].ToString() + "-" + rsGetTime["year"].ToString() + "</td>";
                                if (rsGetTime["links"].ToString() != "")
                                {
                                    string[] list = rsGetTime["links"].ToString().Split(',');
                                    sReciepts += "<td> ";
                                    for (int i = 0; i <= list.Count() - 1; i++)
                                    {
                                        sReciepts += " <a href = 'http://" + list[i] + "' >< img src = 'http://" + list[i] + "' width = '42' height = '42' ></ a > ";
                                    }
                                    sReciepts += " </ td ></ tr > ";

                                }
                                else
                                    sReciepts += "<td> </ td ></ tr >";
                            }
                            cmdGetTime.Dispose();
                            rsGetTime.Close();
                        }
                    }
                    else
                    {
                        MonDate = AddWorkingDays(Convert.ToDateTime(FirstMonday), getdatesloop * 5);
                        SunDate = AddWorkingDays(Convert.ToDateTime(FirstSunday), getdatesloop * 5);
                        if (Between(DateTime.Today.Date, MonDate, SunDate) == true)
                        {
                            string[] datesarray = MonDate.ToString().Split(' ');
                            datesarray = datesarray[0].Split('/');
                            string months = datesarray[0];
                            int dates = Int32.Parse(datesarray[1].ToString());
                            int fridaysup = dates + 6;
                            string years = datesarray[2];
                            sqlGetTime = "select * from ovms_reciepts where employee_id ='" + Session["EmployeeID"].ToString() + "' and job_id ='" + Session["JobID"].ToString() + "' and (date>='" + dates + "' and date<='" + fridaysup + "') and month = '" + months + "' and year ='" + years + "'";
                            SqlCommand cmdGetTime = new SqlCommand(sqlGetTime, connect);
                            SqlDataReader rsGetTime = cmdGetTime.ExecuteReader();
                            while (rsGetTime.Read())
                            {
                                sReciepts = sReciepts + "<tr>";
                                sReciepts += "<td>" + rsGetTime["Description"].ToString() + "</td>" + "<td>" + rsGetTime["amount"].ToString() + "</td>";
                                sReciepts += "<td>" + rsGetTime["date"].ToString() + "-" + rsGetTime["month"].ToString() + "-" + rsGetTime["year"].ToString() + "</td>";
                                if (rsGetTime["links"].ToString() != "")
                                {
                                    string[] list = rsGetTime["links"].ToString().Split(',');
                                    sReciepts += "<td> ";
                                    for (int i = 0; i < list.Count() - 1; i++)
                                    {
                                        sReciepts += " <a href = 'http://" + list[i] + "' ><img src = 'http://" + list[i] + "' width = '42' height = '42' ></ a > ";
                                    }
                                    sReciepts += " </ td ></ tr > ";

                                }
                                else
                                    sReciepts += "<td> </ td ></ tr >";
                            }
                            cmdGetTime.Dispose();
                            rsGetTime.Close();
                        }
                    }
                }
            }
            sReciepts += "</tbody>";
            show_receipts.Text = sReciepts;
        }

        catch (Exception ex)
        {
        }
        finally
        {
            if (connect.State == System.Data.ConnectionState.Open)
                connect.Close();
        }
    }
}
public class getMonday
{
    SqlConnection conn;
    public string getMondays(string StartDate)
    {
        string _sStartDate = "";
        //select first_name, last_name, email_id from ovms_users where user_id = 9
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                //getJobs
                string sqlGetStartDate = " select DATEADD(DD, 1 - DATEPART(DW, '" + StartDate + "'), '" + StartDate + "') + 1 as startd ";
                SqlCommand cmdGetStartDate = new SqlCommand(sqlGetStartDate, conn);
                SqlDataReader rsGetStartDate = cmdGetStartDate.ExecuteReader();
                //string _svendorList = "";
                while (rsGetStartDate.Read())
                {
                    _sStartDate = rsGetStartDate["startd"].ToString();
                }
                rsGetStartDate.Close();
                cmdGetStartDate.Dispose();
            }
        }
        catch (Exception ex)
        {
            //
        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        return _sStartDate;
    }
}