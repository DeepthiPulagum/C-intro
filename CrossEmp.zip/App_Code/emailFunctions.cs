﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Mail;

/// <summary>
/// Summary description for emailFunctions
/// </summary>
public class emailFunctions
{
    public emailFunctions()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void sendEmail(string sTo, string sSubject, string sBody, string scc, string sbcc)
    {
        MailMessage mail = new MailMessage();
        //set the addresses
        mail.From = new MailAddress("notifications@flentispro.com"); //IMPORTANT: This must be same as your smtp authentication address.
        mail.To.Add(sTo);

        //set the content
        mail.Subject = sSubject;
        mail.Body = sBody;
        mail.IsBodyHtml = true;

        //send the message
        SmtpClient smtp = new SmtpClient("mail.flentispro.com");

        //IMPORANT: Your smtp login email MUST be same as your FROM address. 
        NetworkCredential Credentials = new NetworkCredential("notifications@flentispro.com", "Opusing@1234");
        smtp.Credentials = Credentials;
        smtp.Send(mail);
    }
    //// new function-email attachment
    public void sendEmailAttachment(string sTo, string sSubject, string sBody, string scc, string sbcc, string path)
    {
        MailMessage mail = new MailMessage();
        ////set the addresses
        mail.From = new MailAddress("notifications@opusingats.com"); //IMPORTANT: This must be same as your smtp authentication address.
        mail.To.Add(sTo);
        //string resumepath = Server.MapPath(path);
        //set the content
        mail.Subject = sSubject;
        mail.Body = sBody;
        // mail.Attachments.Add;
        mail.IsBodyHtml = true;

        if (path != null)
        {
            Attachment attachment = new Attachment(path);
            mail.Attachments.Add(attachment);
        }

        //send the message
        SmtpClient smtp = new SmtpClient("mail.opusingats.com");

        //IMPORANT: Your smtp login email MUST be same as your FROM address. 
        NetworkCredential Credentials = new NetworkCredential("notifications@opusingats.com", "Maracaibo15@.");
        smtp.Credentials = Credentials;
        smtp.Send(mail);

        //        try
        //        {

        //        MailMessage mail = new MailMessage();
        //        ////set the addresses
        //        mail.From = new MailAddress("Nirmal@flentispro.com"); //IMPORTANT: This must be same as your smtp authentication address.
        //        mail.To.Add(sTo);
        //        //string resumepath = Server.MapPath(path);
        //        //set the content
        //        mail.Subject = sSubject;
        //        mail.Body = sBody;
        //        // mail.Attachments.Add;
        //        mail.IsBodyHtml = true;

        //        if (path != null)
        //        {
        //            Attachment attachment = new Attachment(path);
        //            mail.Attachments.Add(attachment);
        //        }

        //        //send the message
        //        SmtpClient smtp = new SmtpClient("smtp.flentispro.com");

        //        //IMPORANT: Your smtp login email MUST be same as your FROM address. 
        //        NetworkCredential Credentials = new NetworkCredential("Nirmal@flentispro.com", "");
        //        smtp.UseDefaultCredentials = true;
        //        smtp.Credentials = Credentials;
        //        smtp.Send(mail);
        //        }
        //catch(Exception e)
        //        {
        //            e.ToString();
        //        }
    }
}