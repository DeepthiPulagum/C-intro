﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StringFunctions
/// </summary>
public class StringFunctions
{
    public StringFunctions()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string FixString(string s)
    {

        return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(s.ToLower());
    }
}