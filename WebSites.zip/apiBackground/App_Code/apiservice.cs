﻿using SelectPdf;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Services;
using System.Xml;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://localhost:65324/apiservice.asmx")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class apiservice : System.Web.Services.WebService
{
    SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

    public apiservice()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public XmlDocument bg_check_candidates(string userEmailId, string userPassword, string vendor_id)
    {
        string xml_string = "";
        // logAPI.Service logService = new logAPI.Service();
        string errString = "";
        //errString = VerifyUser(userEmailId, userPassword);

        xml_string = "<XML>" +
                    "<REQUEST>" +


                         "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +




                    "</REQUEST>";
        xml_string += "<RESPONSE>";
        string strSql = "";
        if (errString != "")
        {
            xml_string += "<ERROR>" + errString + "</ERROR>";
        }
        else
        {

            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();

                    strSql = "select distinct ed.employee_id, dbo.CamelCase(ed.first_name + ' ' + ed.last_name) full_name, " +
                             "ed.email, concat('W', clt.client_alias, '00', right('0000' + convert(varchar(4), ed.employee_id), 4)) as employee_id, " +
                             " (ed.employee_id) as em_id " +
                             "from ovms_employee_details as ed " +
                             "join ovms_employee_actions as ea on ea.employee_id = ed.employee_id " +
                             "join ovms_clients as clt on clt.client_id = ea.client_id " +
                             "left join ovms_background_verify_details as bvd on bvd.employee_id = ed.employee_id " +
                             "where ea.candidate_approve = 1 and ed.active = 1 and bg_check_done = 0 and ea.vendor_id = " + vendor_id + " and (bvd.emp_submitted_details = 0 or bvd.emp_submitted_details IS NULL)";

                    // " select ed.employee_id, dbo.CamelCase(ed.first_name + ' ' + ed.last_name) full_name, ed.email " +
                    //                " from ovms_employee_details as ed " +
                    //                " join ovms_employee_actions as ea on ea.employee_id = ed.employee_id " +
                    //                " where ea.candidate_approve = 1 and bg_check_done=0 and ea.vendor_id = " + vendor_id;

                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    int RowID = 1;
                    while (reader.Read())
                    {
                        xml_string = xml_string + "<EMPLOYEE_NAME_ID ID='" + RowID + "'>" +
                        "<EMPLOYEE_ID>" + reader["employee_id"] + "</EMPLOYEE_ID>" +
                        "<EMPLOYEE_BID>" + reader["em_id"] + "</EMPLOYEE_BID>" +
                        "<EMPLOYEE_NAME>" + reader["full_name"] + "</EMPLOYEE_NAME>" +
                        "<EMPLOYEE_EMAIL>" + reader["email"] + "</EMPLOYEE_EMAIL>" +
                             "</EMPLOYEE_NAME_ID>";
                        RowID = RowID + 1;
                    }
                    reader.Close();
                    cmd.Dispose();
                }
            }

            catch (Exception ex)
            {
                xml_string = xml_string + "<STATUS>error:xxx.systemerror</STATUS>";
                //logService.set_log(100, HttpContext.Current.Request.Url.AbsoluteUri, "System failed: login error");

            }

            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
        xml_string = xml_string + "</RESPONSE>" +
                          "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }

    [WebMethod]
    public XmlDocument insert_bg_empDetails(string userEmailId, string userPassword, string client_id, string vendor_id, string empID, string empName, string empEmail)
    {
        string xml_string = "<XML>" +
                            "<REQUEST>" +
                            "<CLIENT_ID>" + client_id + "</CLIENT_ID>" +
                            "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +
                            "<EMPLOYEE_ID>" + empID + "</EMPLOYEE_ID>" +
                            "<EMPLOYEE_NAME>" + empName + "</EMPLOYEE_NAME>" +
                            "<EMPLOYEE_EMAIL>" + empEmail + "</EMPLOYEE_EMAIL>" +
                            "</REQUEST>";
        xml_string += "<RESPONSE>";

        string sqlstr = "";
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                bool foundemp;
                sqlstr = "select * from ovms_background_verify_details where employee_id = '" + empID + "'";
                SqlCommand cmd = new SqlCommand(sqlstr, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    foundemp = true;
                }
                else
                    foundemp = false;

                reader.Close();
                cmd.Dispose();

                if (foundemp == false)
                {
                    sqlstr = "insert into ovms_background_verify_details (client_id,vendor_id, employee_id, emp_name, emp_email, mail_send,mail_send_date) " +
                              "  values(" + client_id + ", " + vendor_id + ", " + empID + ", '" + empName + "', '" + empEmail + "', 1, '" + DateTime.Now + "')";
                    cmd = new SqlCommand(sqlstr, conn);
                    reader = cmd.ExecuteReader();
                    reader.Close();
                    cmd.Dispose();
                }
                else
                {
                    sqlstr = "update ovms_background_verify_details set mail_send= 1 where employee_id = '" + empID + "'";
                    cmd = new SqlCommand(sqlstr, conn);
                    reader = cmd.ExecuteReader();
                    reader.Close();
                    cmd.Dispose();
                }

                xml_string += "<RESPONSE_STATUS>1</RESPONSE_STATUS>";
                xml_string += "<INSERT_STRING>Details inserted successfully</INSERT_STRING>";
                    
            }
        }
        catch (Exception ex)
        {
            xml_string += "<RESPONSE_STATUS>0</RESPONSE_STATUS>";
            xml_string += "<INSERT_STRING>Details not inserted</INSERT_STRING>";

        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        xml_string = xml_string + "</RESPONSE>" +
                          "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }

    [WebMethod]
    public XmlDocument pending_Bg_service(string userEmailId, string userPassword, string client_id, string vendor_id)
    {
        string xml_string = "<XML>" +
                            "<REQUEST>" +
                            "<CLIENT_ID>" + client_id + "</CLIENT_ID>" +
                            "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +
                            
                            "</REQUEST>";
        xml_string += "<RESPONSE>";

        string sqlstr = "";
        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                sqlstr = "select  distinct ed.employee_id, dbo.CamelCase(ed.first_name + ' ' + ed.last_name) full_name, " +
                         "ed.email, concat('W', clt.client_alias, '00', right('0000' + convert(varchar(4), ed.employee_id), 4)) as employees_id, " +
                         " bvd.verification_started, bvd.mail_send, bvd.emp_submitted_details " +
                         "from ovms_employee_details as ed " +
                         "join ovms_employee_actions as ea on ea.employee_id = ed.employee_id " +
                         "join ovms_clients as clt on clt.client_id = ea.client_id " +
                         "left join ovms_background_verify_details as bvd on bvd.employee_id = ed.employee_id  " +
                         "where ea.candidate_approve = 1 and ea.vendor_id = " + vendor_id + " and ea.client_id = '"+ client_id + "'";

                SqlCommand cmd = new SqlCommand(sqlstr, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                int RowID = 1;
                while (reader.Read())
                {
                    xml_string = xml_string + "<EMPLOYEE_NAME_ID ID='" + RowID + "'>" +
                    "<EMPLOYEE_ID>" + reader["employees_id"] + "</EMPLOYEE_ID>" +
                    "<EMPLOYEE_NAME>" + reader["full_name"] + "</EMPLOYEE_NAME>" +
                    "<EMPLOYEE_EMAIL>" + reader["email"] + "</EMPLOYEE_EMAIL>" +
                    "<VERIFICATION_STARTED>" + reader["verification_started"] +" </VERIFICATION_STARTED>" +
                    "<MAIL_SEND>" + reader["mail_send"] +" </MAIL_SEND>" +
                    "<EMP_DETAILS_SUB>"+ reader["emp_submitted_details"] + " </EMP_DETAILS_SUB>" +
                    "</EMPLOYEE_NAME_ID>";
                    RowID = RowID + 1;
                }
                reader.Close();
                cmd.Dispose();
            }
        }
        catch (Exception ex)
        {
            xml_string = xml_string + "<STATUS>error:xxx.systemerror</STATUS>";

        }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
                conn.Close();
        }
        xml_string = xml_string + "</RESPONSE>" +
                          "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }

    [WebMethod]
    public XmlDocument send_bgINFO_from_candidate(string userEmailId, string userPassword, string field_name, string field_value, string employee_id, string client_id, string vendor_id, string form_id, string doc_title, string job_id)
    {
        SqlConnection conn;
        string xml_string = "";
        // logAPI.Service logService = new logAPI.Service();
        string errString = "";
        //errString = VerifyUser(userEmailId, userPassword);

        xml_string = "<XML>" +
                    "<REQUEST>" +


                         "<FIELD_NAME>" + field_name + "</FIELD_NAME>" +
                         "<FIELD_VALUE>" + field_value + "</FIELD_VALUE>" +
                        "<EMPLOYEE_ID>" + employee_id + "</EMPLOYEE_ID>" +
                        "<CLIENT_ID>" + client_id + "</CLIENT_ID>" +
                        "<VENDOR_ID>" + vendor_id + "</VENDOR_ID>" +
                         "<FORM_ID>" + form_id + "</FORM_ID>" +
                         "<DOC_TITLE>" + doc_title + "</DOC_TITLE>" +



                    "</REQUEST>";
        xml_string += "<RESPONSE>";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        if (errString != "")
        {
            xml_string += "<ERROR>" + errString + "</ERROR>";
        }
        else
        {
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string strSql = " insert into ovms_background_check ( client_id, document_title, field_name,field_value,vendor_id, employee_id, form_id, job_id) " +
                                   "  values('" + client_id + "', '" + doc_title + "', '" + field_name + "', '" + field_value + "', '" + vendor_id + "', '" + employee_id + "','" + form_id + "','" + job_id + "')";

                    SqlCommand cmd = new SqlCommand(strSql, conn);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        xml_string += "<INSERT_STRING>Info inserted</INSERT_STRING>";
                    }
                    else
                    {
                        xml_string += "<INSERT_STRING><ERROR>Info not inserted</ERROR> </INSERT_STRING>";

                    }
                    cmd.Dispose();
                    conn.Close();

                }
            }

            catch (Exception ex)
            {
                xml_string += "<XML>" + "<STATUS>error:100.systemerror</STATUS>";


            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
        }
        xml_string += "</RESPONSE>" +
                             "</XML>";
        XmlDocument xmldoc;
        xmldoc = new XmlDocument();
        xmldoc.LoadXml(xml_string);

        return xmldoc;
    }

    [WebMethod]

    public void pdf_convertor(string filetext, string path)
    {
        int webPageWidth = 1024;
        int webPageHeight = 0;
        
        // instantiate a html to pdf converter object
        HtmlToPdf converter = new HtmlToPdf();

        // set converter options
        
        converter.Options.WebPageWidth = webPageWidth;
        converter.Options.WebPageHeight = webPageHeight;

        // create a new pdf document converting an url
        PdfDocument doc = converter.ConvertHtmlString(filetext);

        // save pdf document
        doc.Save(path);

        // close pdf document
        doc.Close();
    }
}
