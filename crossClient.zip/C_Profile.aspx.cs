﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
public partial class C_Profile : System.Web.UI.Page
{
    SqlConnection conn;
    StringFunctions func;
    protected void Page_Load(object sender, EventArgs e)
    {
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        //if (!Page.IsPostBack)
        //{

        jobrev.Text = Session["Total_Spent"].ToString();
        tApprove.Text = Session["TimeSheet_Approved"].ToString();
        tpending.Text = Session["TimeSheet_Rejected"].ToString();
        tRejected.Text = Session["TimeSheet_Pending"].ToString();

        XmlDocument xmldoc = new XmlDocument();
        API.Service prof = new API.Service();
        // API.Service prof = new API.Service();
        xmldoc.LoadXml("<XML>" + prof.get_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
        // xmldoc.LoadXml("<XML>" + prof.get_Profile("greg@opusing.com ", "1234", "9").InnerXml + "</XML>");
        XmlNodeList xResponse = xmldoc.SelectNodes("XML/RESPONSE/USER_NO");

        txtfirst.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/FIRST_NAME").InnerText;
        txtsecond.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/LAST_NAME").InnerText;
        txtemail.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/EMAIL").InnerText;

        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();

            // Session["JobID"] = jobID.ToString();

            //start, end and weeks
            string sqlgetclientdetails = "select * from ovms_client_details as cd join ovms_clients as c on c.client_id=cd.client_id where c.client_id='" + Session["ClientID"].ToString() + "'";

            SqlCommand c_details = new SqlCommand(sqlgetclientdetails, conn);
            SqlDataReader reader = c_details.ExecuteReader();
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    string address1 = "";
                    txtPhone.Text = reader["client_PhoneNumber"].ToString();
                    Txtcompemail.Text = reader["primary_email"].ToString();
                    address1 = "Suite: " + reader["client_address1"].ToString();
                    address1 = Server.HtmlDecode(address1 + " Postal Code: " + reader["client_postal_code"].ToString());
                    address1 = address1 + "  Country:" + reader["client_country"].ToString();
                    txtComp_name.Text = reader["client_name"].ToString();
                    txtsecEmail.Text = reader["secondary_email"].ToString();
                    txtSuite.Text = reader["client_address1"].ToString();
                    txtPostal.Text = reader["client_postal_code"].ToString();
                    txtcity.Text = reader["client_city"].ToString();
                    txtcountry.Text = reader["client_country"].ToString();
                    txtfax.Text = reader["client_FaxNumber"].ToString();
                    txtadrres2.Text = reader["client_address2"].ToString();
                    // Txtaddres.Text = address1;
                }

            }
            reader.Close();
            c_details.Dispose();
            conn.Close();
        }
        pfname.Text = Session["FirstName"].ToString() + " " + Session["LastName"].ToString() + "@" + txtComp_name.Text.ToLower();

        locate.Text = txtcity.Text;
        //}
    }
    protected void updateChanges_Click(object j, EventArgs e)
    {
        string compname = txtComp_name.Text;
        string phone = txtPhone.Text;
        string fax = txtfax.Text;
        string address1 = txtSuite.Text;
        string address2 = txtadrres2.Text;
        string country = txtcountry.Text;
        string email = Txtcompemail.Text;
        string secndemail = txtsecEmail.Text;
        string city = txtcity.Text;
        string postal = txtPostal.Text;

        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);


        if (conn.State == System.Data.ConnectionState.Closed)
        {
            conn.Open();


            string sqlgetclientdetails2 = "update ovms_client set client_name='" + compname + "' where client_id='" + Session["ClientID"].ToString() + "'";
            string sqlgetclientdetails = sqlgetclientdetails2 + "update ovms_client_details set client_address1='" + address1 + "',client_address2='" + address2 + "'," +
             " client_postal_code='" + postal + "',client_city='" + city + "',client_faxNumber='" + fax + "',client_phoneNumber='" + phone + "',client_country='" + country + "',Primary_email='" + email + "',secondary_email='" + secndemail + "'" +
             " where client_id='" + Session["ClientID"].ToString() + "'";
            SqlCommand c_details = new SqlCommand(sqlgetclientdetails, conn);
            SqlDataReader reader = c_details.ExecuteReader();

            c_details.Dispose();
            conn.Close();
            reader.Close();
        }

    }

    protected void btnupdatepassword_Click(object sender, EventArgs e)
    {
        XmlDocument xmldoc = new XmlDocument();
        API.Service updateP = new API.Service();
        xmldoc.LoadXml("<XML>" + updateP.update_Personal_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString(), txtnewpassword.Text).InnerXml + "</XML>");
        XmlNodeList xResponse = xmldoc.SelectNodes("XML/RESPONSE");
        if(xmldoc.SelectSingleNode("XML/RESPONSE/INSERT_STRING").InnerText!="" || xmldoc.SelectSingleNode("XML/RESPONSE/INSERT_STRING").InnerText!=null)
        {
            lblpwdchanged.Text = xmldoc.SelectSingleNode("XML/RESPONSE/INSERT_STRING").InnerText;
            Session["P@ss"] = txtnewpassword.Text;

        }
        else
        {
            lblpwdchanged.Text = xmldoc.SelectSingleNode("XML/RESPONSE/ERROR").InnerText;

        }

    }
}