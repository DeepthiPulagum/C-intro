﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class C_TimesheetApproval : System.Web.UI.Page
{
    SqlConnection conn;
    string errString = "";
    int CountRows = 1;
    StringFunctions func = new StringFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {
        string sTable = "";
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);


        //show timesheets needed to be approved
        try
        {
            API.Service getWorkers = new API.Service();
            XmlDocument dom1 = new XmlDocument();
            dom1.LoadXml("<XML>" + getWorkers.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), "", "", Session["ClientID"].ToString(), "", "", "1", "").InnerXml + "</XML>");
            XmlNodeList Response = dom1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
            sTable = "";
            string _sBackground = "";
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
                for (int iResponse = 0; iResponse < Response.Count; iResponse++)
            {
                string worker_status = Response[iResponse].SelectSingleNode("CANDIDATE_APPROVE").InnerText;
                DateTime candidate_start_date = DateTime.Parse(Response[iResponse].SelectSingleNode("STARTDATE").InnerText);
                DateTime job_start_date = DateTime.Parse(Response[iResponse].SelectSingleNode("CONTRACT_START_DATE").InnerText);
                DateTime thisday = DateTime.Today;
                string employees_det = Response[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText.Substring(4, Response[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText.Length-4);
                string backgroundverify = "";
                if (Response[iResponse].SelectSingleNode("BACKGROUND_CHECK").InnerText != "")
                {
                    backgroundverify = Response[iResponse].SelectSingleNode("BACKGROUND_CHECK").InnerText;
                }
                if (worker_status == "1" && backgroundverify == "1" && (candidate_start_date <= thisday))
                {

                   
                        string strGetHours = "select sum(a.hours) as hours_total from ovms_timesheet a,  " +
                                                     " ovms_timesheet_details b where a.employee_id = employee_id  " +
                                                     " and a.timesheet_id = b.timesheet_id and a.active = 1 and b.active = 1  " +
                                                     " and b.timesheet_status_id = 3  " +
                                                     " and a.employee_id = " + employees_det + " ";
                        //" and DatePart(week, dateadd(d, -1, CONCAT(a.month, '-', a.day, '-', a.year))) = " + readerGetTimeSheets["weeknum"].ToString() + " ";
                        SqlCommand cmdGetHours = new SqlCommand(strGetHours, conn);
                        SqlDataReader rsGetHours = cmdGetHours.ExecuteReader();
                        while (rsGetHours.Read())
                        {
                            if (rsGetHours["hours_total"].ToString() != null && rsGetHours["hours_total"].ToString() != "")
                            {
                                string hours = rsGetHours["hours_total"].ToString();
                                string chk = "1";
                                string chk2 = "1";

                                //DateTime.Parse(readerGetTimeSheets["DATE+_FROM"].ToString()).ToString("dd MMM, yyyy") +
                                // sAction = rsGetHours["timesheet_status"].ToString();
                                sTable = sTable + "<tr style='height:10px;'>";
                                //sTable = sTable + "<td>" + CountRows + "</td>";
                                sTable = sTable + "<td style='white-space:nowrap;'>" + func.FixString(Response[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response[iResponse].SelectSingleNode("LASTNAME").InnerText) + /*"<p>(" + DateTime.Parse(readerGetTimeSheets["DATE_FROM"].ToString()).ToString("dd MMM, yyyy") + " - " + DateTime.Parse(readerGetTimeSheets["DATE_TO"].ToString()).ToString("dd MMM, yyyy") + ")</p>*/ "</td> ";
                                //sTable = sTable + "<td>" + string.Format("{0:c0}", Convert.ToDouble(readerGetTimeSheets["PAY_RATE"].ToString()) * Convert.ToDouble(readerGetTimeSheets["HOURS_REPORTED"].ToString())) + " </td> ";
                                sTable = sTable + "<td>" + rsGetHours["hours_total"].ToString() + " </td> ";                        //sTable = sTable + "<td class='text-right width-100'><a href='C_TimeSheet_View.aspx?topen=Y&p=VT&TID=123&action=Approve&fromD=1&FromM=1&FromY=1' class='btn btn-success btn-xs'  data-toggle='tooltip' data-placement='top' name='abc' title='Approve TimeSheet'><i class='fa fa-check'></i></a>&nbsp;<a href='C_TimeSheet_View.aspx?topen=Y&p=VT&TID=1&action=Reject&fromD=1&FromM=1&FromY=1' class='btn btn-danger btn-xs' data-toggle='tooltip' data-placement='top' name='abc' title='Reject TimeSheet'><i class='fa fa-times'></i></a></td>";
                                sTable = sTable + "<td><a  target='_blank' href='C_TimeSheet_View.aspx?TID=" + employees_det.TrimStart('0') + "'>Go to Timesheets</a>";
                                //sTable = sTable + "<td class='text-right width-100'><a href='C_TimeSheet_View.aspx?topen=Y&p=VT&TID=" + readerGetTimeSheets["employee_id"].ToString() + "' class='btn btn-warning btn-xs'  data-toggle='tooltip' data-placement='top' name='abc' title='View Details'><i class='fa fa-table'></i></a>&nbsp;<a href='Client.aspx?TID=" + readerGetTimeSheets["employee_id"].ToString() + "&action=Approve&fromD=" + Convert.ToDateTime(readerGetTimeSheets["date_from"].ToString()).Day.ToString() + "&FromM=" + Convert.ToDateTime(readerGetTimeSheets["date_from"].ToString()).Month.ToString() + "&FromY=" + Convert.ToDateTime(readerGetTimeSheets["date_from"].ToString()).Year.ToString() + "&Mess=" + Server.UrlEncode(func.FixString(readerGetTimeSheets["FIRST_NAME"].ToString()) + " " + func.FixString(readerGetTimeSheets["LAST_NAME"].ToString())) + "(" + DateTime.Parse(readerGetTimeSheets["DATE_FROM"].ToString()).ToString("dd MMM, yyyy") + " - " + DateTime.Parse(readerGetTimeSheets["DATE_TO"].ToString()).ToString("dd MMM, yyyy") + ") for " + string.Format("{0:c0}", Convert.ToDouble(readerGetTimeSheets["PAY_RATE"].ToString()) * Convert.ToDouble(readerGetTimeSheets["HOURS_REPORTED"].ToString())) + "' class='btn btn-success btn-xs'  data-toggle='tooltip' data-placement='top' name='abc' title='Approve Timesheet'><i class='fa fa-check'></i></a>&nbsp;<a href='Client.aspx?TID=" + readerGetTimeSheets["employee_id"].ToString() + "&action=Approve&fromD=" + Convert.ToDateTime(readerGetTimeSheets["date_from"].ToString()).Day.ToString() + "&FromM=" + Convert.ToDateTime(readerGetTimeSheets["date_from"].ToString()).Month.ToString() + "&FromY=" + Convert.ToDateTime(readerGetTimeSheets["date_from"].ToString()).Year.ToString() + "' class='btn btn-danger btn-xs' data-toggle='tooltip' data-placement='top' name='abc' title='Reject TimeSheet'><i class='fa fa-times'></i></a></td>";
                                //sTable = sTable = "<td>12</td>";
                                //C_TimeSheet_View.aspx?topen=Y&p=VT&TID=1

                                sTable = sTable + "</tr>";
                            }
                            else {
                                sTable = sTable + "<tr style='height:10px;'><td colspan='3'>No timesheet available at this time</td></tr>";
                            }
                        }
                        //close
                        rsGetHours.Close();
                        cmdGetHours.Dispose();
                        CountRows++;

                    }

                    //string a = "";
                    //}
                }

                // lblJobs.Text = reader["num_of_jobs"].ToString();
                //lblVendors.Text  = reader["num_of_jobs"].ToString();
            }

            sTable = sTable + "</tbody>";
           
            lblTableData.Text = sTable;
        }
        
        catch (Exception ex)
        {
           
            }
        finally
        {
            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }


        }
}