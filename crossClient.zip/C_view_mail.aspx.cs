﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class C_view_mail : System.Web.UI.Page
{
    SqlConnection conn;
    string email_time;
    protected void Page_Load(object sender, EventArgs e)
    {
        string vendor_id = "";
        string client_name = "";
        string main_msg = "";
            
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

        string strSqln = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        SqlDataReader readern = cmdn.ExecuteReader();
        if (readern.HasRows == true)
        {

            while (readern.Read())
            {



                lblinboxnumber.Text = readern["number"].ToString();


            }


        }
        readern.Close();
        cmdn.Dispose();
        conn.Close();



        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        //lblsub.Text = Request.QueryString["Subject"].ToString();
        string msg_id = Request.QueryString["_id"].ToString();
        string strSql = "select * from ovms_messages where (message_id = " + msg_id + " or sourceid = " + msg_id + ") order by message_id desc ";


        conn.Open();

        SqlCommand cmd = new SqlCommand(strSql, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows == true)
        {

            while (reader.Read())

            {

                string today = (DateTime.Now).ToString("yyyyMMdd");
                string time1 = "";


                string date;
                if (reader["sending_time"].ToString() != null)
                {
                    date = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyyMMdd");


                    if (today == date)
                    {

                        email_time = DateTime.Parse(reader["sending_time"].ToString()).ToString("hh.mm tt");



                    }
                    else
                    {

                        email_time = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyy/MM/dd");
                    }
                    lblsub.Text = reader["Msg_Subject"].ToString();
                    if (reader["Actions"].ToString() == "SEND_C_V")
                    {
                        main_msg = main_msg + reader["message"].ToString();
                    }
                    else
                    {
                        main_msg = main_msg  +  "</b><br>" + reader["message"].ToString();

                    }
                    vendor_id = reader["vendor_id"].ToString();
                }
            }

            lblmsgbody.Text =Server.HtmlDecode( main_msg);
        }
        string strSqlT = "select * from ovms_messages where  sourceID=" + msg_id;




        SqlCommand cmdT = new SqlCommand(strSqlT, conn);
        SqlDataReader readerT = cmdT.ExecuteReader();
        if (reader.HasRows == true)
        {

            while (readerT.Read())
            {


                vendor_id = readerT["client_id"].ToString();
            }


        }
        // txtemail.Text = Server.HtmlDecode(main_msg);
        reader.Close();
        cmd.Dispose();
        string strSql1 = "select vendor_name from ovms_vendors  where vendor_id= " + vendor_id;




        SqlCommand cmd1 = new SqlCommand(strSql1, conn);
        SqlDataReader reader1 = cmd1.ExecuteReader();
        if (reader1.HasRows == true)
        {

            while (reader1.Read())
            {


                client_name = reader1["vendor_name"].ToString();
            }
            lblsender.Text = client_name;

        }



        reader1.Close();


        cmd1.Dispose();
        //string strSql2 = "update ovms_messages set IsRead=1 where message_id=" + msg_id;
        //SqlCommand cmd2 = new SqlCommand(strSql2, conn);
        //SqlDataReader reader2 = cmd2.ExecuteReader();
        //if (reader2.HasRows == true)
        //{

        //    while (reader2.Read())
        //    {


        //        client_name = reader2["client_name"].ToString();
        //    }
        //    //  lblSender.Text = client_name;

        //}
        //reader2.Close();
        //cmd2.Dispose();

        //conn.Close();
    }

    //protected void btnSend_Click(object sender, EventArgs e)
    //{

    //    string reply =Server.HtmlEncode( txtReply.InnerText);

    //    conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
    //    conn.Open();

    //    string strSqln = "insert into ovms_messages(pmo_id, message, vendor_id, Msg_Subject, SourceID, User_id, client_id,IsSend,IsRead, Actions,sending_time)" +
    //                        " values(1,'" + reply + "','" +Session["VendorID"].ToString() + "', (select Msg_Subject from ovms_messages where message_id = '" + Request.QueryString["_id"].ToString() + "'), '" + Request.QueryString["_id"].ToString() + "', '" +Session["VendorID"].ToString() + "','" + Session["ClientID"] + "', 0,0, 'SEND_C_V','"+DateTime.Now+"')";


    //    //" and candidate_reject_time >= '" + thisDay + "'";


    //    SqlCommand cmdn = new SqlCommand(strSqln, conn);
    //    if (cmdn.ExecuteNonQuery() != 0)
    //    {
    //        string test = "";
    //    }

    //    cmdn.Dispose();
    //    conn.Close();
    //    //  xDoc.LoadXml("<XML>" + web.Reply_from_Vendor(Session["Email"].ToString(), Session["P@ss"].ToString(), "1", Request.QueryString["_id"].ToString(), txtReply.Value, Session["VendorID"].ToString(), "", Session["ClientID"].ToString(), "", "Send_V_C", "").InnerXml + "</XML>");
    //    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(),
    //    "",
    //    "alert('Email Sent');",
    //    true);
    //    //XmlDocument xDoc = new XmlDocument();
    //    //API.Service web = new API.Service();
    //    //// LocalAPI.Service web = new LocalAPI.Service();
    //    //xDoc.LoadXml("<XML>" + web.Reply_from_Vendor(Session["Email"].ToString(), Session["P@ss"].ToString(), "1", Request.QueryString["_id"].ToString(), txtReply.Value, Session["VendorID"].ToString(), "", Session["ClientID"].ToString(), "", "Send_C_V", "").InnerXml + "</XML>");
    //    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(),
    //    "",
    //    "alert('Email Sent');",
    //    true);
    //    Response.Redirect("C_Sent_message.aspx");
    //}
}