﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.Text;
using System.IO;

public partial class CSV_Reports : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=Your+session+has+timed+out");
            Response.End();
        }
        storeprocedureexec();
    }
    private void storeprocedureexec()
    {
        SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        DataTable Dstoreprocedure = new DataTable();
        try
        {
            if(conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand("dummy_store", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@client_id", SqlDbType.Int).Value = Session["ClientID"].ToString();

                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        adp.Fill(Dstoreprocedure);
                        adp.Dispose();
                    }
                    cmd.Dispose();


                    //using (SqlCommand cmd = new SqlCommand("candidate_submitted_against_jobs", conn))
                    //{
                    //    cmd.CommandType = CommandType.StoredProcedure;
                    //    cmd.Parameters.Add("@client_id", SqlDbType.Int).Value = Session["ClientID"].ToString();
                    //    cmd.Parameters.Add("@vendor_id", SqlDbType.Int).Value = Session["VendorID"].ToString();
                    //    cmd.Parameters.Add("@job_id", SqlDbType.Int).Value = null;

                    //using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    //{
                    //        cmd.CommandType = CommandType.StoredProcedure;
                    //        adp.Fill(Dstoreprocedure);
                    //        adp.Dispose();
                    //}
                    //    cmd.Dispose();


                    string path = Server.MapPath("~/storeprocedures.csv");
                    if (File.Exists(Server.MapPath("~/storeprocedures.csv")) )
                    {
                        File.Delete(Server.MapPath("~/storeprocedures.csv"));
                    }
                    var storeFile = File.Create(path);
                    storeFile.Close();
                    using (FileStream file = storeFile)
                    { 

                        StringBuilder sb = new StringBuilder();

                    IEnumerable<string> columnNames = Dstoreprocedure.Columns.Cast<DataColumn>().
                                                      Select(column => column.ColumnName);
                    sb.AppendLine(string.Join(",", columnNames));

                    foreach (DataRow row in Dstoreprocedure.Rows)
                    {
                        IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                        sb.AppendLine(string.Join(",", fields));
                    }
                        ////Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "myfunction(" + Server.MapPath("~/File/storeprocedures.csv") + ")", true);
                        

                        string script = "myfunction('" + Server.MapPath("~/storeprocedures.csv") + "');";
                        //csv.Value = Server.MapPath("~/File/storeprocedures.csv");
                        ClientScript.RegisterStartupScript(this.GetType(), "myfunction", script, true);

                        File.WriteAllText(path, sb.ToString());
                    }

                }
            }
        }
        catch(Exception ex)
        {
            // ex.Message;
        }
        finally
        {
            if(conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }
    }
}