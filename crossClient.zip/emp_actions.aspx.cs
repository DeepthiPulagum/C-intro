﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class emp_actions : System.Web.UI.Page
{
    emailFunctions semail = new emailFunctions();
    StringFunctions func = new StringFunctions();

    private int iResponse;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["approve"] != null)
        {

            string employee_id = (Request.QueryString["approve"].Substring(Request.QueryString["approve"].Length - 6));
            if (Request.QueryString["chkapprove"] == "yes")
            {

                string job_end_date = Request.QueryString["job_end"].ToString();
                string emp_end_date = Request.QueryString["emp_end"].ToString();
                string job_id = Request.QueryString["job_id"].ToString();
                DateTime thisDay = DateTime.Now.AddHours(1);
                //API.Service approve = new API.Service();
                API.Service approve = new API.Service();
                XmlDocument _xmlDoc1 = new XmlDocument();
                _xmlDoc1.LoadXml("<XML>" + approve.candidate_approve(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), employee_id.ToString(), Session["VendorID"].ToString(), "1", job_id, emp_end_date, job_end_date, thisDay.ToString()).InnerXml + "</XML>");
                XmlNodeList ea = _xmlDoc1.SelectNodes("XML/RESPONSE");


                API.Service name = new API.Service();
                XmlDocument _xmlDoc = new XmlDocument();
                _xmlDoc.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id, "", "", "", "", "1", "").InnerXml + "</XML>");
                XmlNodeList ea1 = _xmlDoc.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
                string name2 = "";
                name2 = ea1[iResponse].SelectSingleNode("FIRSTNAME").InnerText;
                string job_name = ea1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
                string vendor_email = Session["Vendor_Email"].ToString();
                //semail.sendEmail("", "Candidate Approved ", "<br>Worker Name :" + name2 +
                //    "<br>Position applied for :" + job_name +
                //                 "<br>******" +
                //                "<br>This notification was sent by oveems.If you have any questions regarding this notice," +
                //                "<br>please contact the SAP Fieldglass Helpdesk at:" +
                //                "<br>mailto:helpdesk@oveems.com" +
                //                "<br>By Phone:" +
                //                "<br>US(toll free) 1 800 123 1234" +
                //                "<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");


                //********* Sms Notify********** ///////
                SqlConnection conn;
                string readsms;
                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                        string smsquery = "select vendor_id from ovms_employee_actions where job_id = " + job_id;
                        SqlCommand smscmd = new SqlCommand(smsquery, conn);
                        SqlDataReader datareders = smscmd.ExecuteReader();
                        if (datareders.HasRows == true)
                        {
                            while (datareders.Read())
                            {
                                readsms = datareders["vendor_id"].ToString();
                                string message = "Candidate Approved \n" + name2 + "\n " + job_name;
                                // localhost.Service files = new localhost.Service();
                                API.Service files = new API.Service();
                               // files.client_smsNotification(readsms, message, Session["ClientID"].ToString(), "candid_approve_notify");
                            }
                        }
                        datareders.Close();
                        smscmd.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                ///////// ***** end of sms notify******* /////////////

                /* background verification */
                try
                {
                    string empsID = Request["approve"].Substring(5, Request["approve"].Length - 5);
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                        //employee_id
                        string client_id = "", vendor_id = "", empName = "", empEmail = "";

                        string strSql = "select ed.*, emp.vendor_id, emp.client_id  from ovms_employee_details as ed " +
                            " join ovms_employees as emp on emp.employee_id= ed.employee_id where ed.employee_id ='" + employee_id + "'";

                        SqlCommand cmd = new SqlCommand(strSql, conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                empName = reader["first_name"].ToString() + " " + reader["last_name"].ToString();
                                empEmail = reader["email"].ToString();
                                vendor_id = reader["vendor_id"].ToString();
                                client_id = reader["client_id"].ToString();
                            }
                        }
                        reader.Close();
                        cmd.Dispose();

                        if(Request.QueryString["bgvcheck"].ToString() == "")
                        {
                            strSql = "insert into ovms_background_verify_details (client_id,vendor_id, employee_id, emp_name, emp_email,  verification_started, verifcation_start_date) " +
                              "  values(" + client_id + ", " + vendor_id + ", " + employee_id + ", '" + empName + "', '" + empEmail + "', 1, '" + DateTime.Now + "')";

                            cmd = new SqlCommand(strSql, conn);
                            reader = cmd.ExecuteReader();
                            reader.Close();
                            cmd.Dispose();
                        }
                        else
                        {
                            strSql = "update ovms_employee_actions set bg_check_done = '1', bg_check_time = '" + DateTime.Now + "' where employee_id ='" + employee_id + "'";

                            cmd = new SqlCommand(strSql, conn);
                            reader = cmd.ExecuteReader();
                            reader.Close();
                            cmd.Dispose();
                        }
                    }

                }
                catch (Exception ex)
                {

                }
                finally
                {
                    conn.Close();
                }
                /* end of background verification */

                HttpContext.Current.Response.Redirect("C_ViewCandidates.aspx?copen=Y&p=VC");
            }
            else
            {
                string comment = Request.QueryString["intComment"].ToString();
                string job_end_date = Request.QueryString["job_end"].ToString();
                string emp_end_date = Request.QueryString["emp_end"].ToString();
                string job_id = Request.QueryString["job_id"].ToString();
                string intw_time = Request.QueryString["time"].ToString();
                string intw_date = Request.QueryString["date"].ToString();
                 DateTime int_date = Convert.ToDateTime(intw_date);
               
                DateTime thisDay = DateTime.Now.AddHours(1);
                API.Service int_req = new API.Service();
                // API.Service int_req = new API.Service();
                XmlDocument _xmlDoc = new XmlDocument();
                // _xmlDoc.LoadXml("<XML>" + int_req.interview_request(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString(), employee_id.ToString(), int_date, intw_time).InnerXml + "</XML>");
                _xmlDoc.LoadXml("<XML>" + int_req.interview_request(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), Session["VendorID"].ToString(), employee_id.ToString(), "1", int_date, intw_time, job_id.ToString(), emp_end_date.ToString(), job_end_date.ToString(), comment, "", "", thisDay.ToString()).InnerXml + "</XML>");
                XmlNodeList ea = _xmlDoc.SelectNodes("XML/RESPONSE");
                API.Service name = new API.Service();
                XmlDocument _xmlDoc1 = new XmlDocument();
                _xmlDoc1.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id, "", "", "", "", "1", "").InnerXml + "</XML>");
                XmlNodeList Response1 = _xmlDoc1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
                string name2 = "";
                name2 = Response1[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response1[iResponse].SelectSingleNode("LASTNAME").InnerText;
                string job_name = Response1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
                string vendor_email = Session["Vendor_Email"].ToString();
                //semail.sendEmail("", "Candidate Interview schedule ", "<br>Worker Name :" + name2 +
                //                 "<br>Interview Date :" + intw_date +
                //                "<br>Interview Date :" + intw_time +
                //                "<br>Position applied for :" + job_name +
                //                "<br>******" +
                //               "<br>This notification was sent by oveems.If you have any questions regarding this notice," +
                //               "<br>please contact the SAP Fieldglass Helpdesk at:" +
                //               "<br>mailto:helpdesk@oveems.com" +
                //               "<br>By Phone:" +
                //               "<br>US(toll free) 1 800 123 1234" +
                //               "<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");
                ////********* Sms Notify********** ///////
                SqlConnection conn;
                string readsms;
                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                        string smsquery = "select vendor_id from ovms_employee_actions where job_id =  " + job_id;
                        SqlCommand smscmd = new SqlCommand(smsquery, conn);
                        SqlDataReader datareders = smscmd.ExecuteReader();
                        if (datareders.HasRows == true)
                        {
                            while (datareders.Read())
                            {
                                readsms = datareders["vendor_id"].ToString();
                                string message = "Candidate Interview schedule \n" + name2 + "\n " + job_name;
                                // localhost.Service files = new localhost.Service();
                                API.Service files = new API.Service();
                              //  files.client_smsNotification(readsms, message, Session["ClientID"].ToString(), "interview_schedule_notify");
                            }
                        }
                        datareders.Close();
                        smscmd.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }


                ///////// ***** end of sms notify******* /////////////

                HttpContext.Current.Response.Redirect("C_ViewCandidates.aspx?copen=Y&p=VC");
            }
        }
        if (Request.QueryString["Reject"] != null)
        {
            string job_end_date = Request.QueryString["job_end"];
            string emp_end_date = Request.QueryString["emp_end"];
            string job_id = Request.QueryString["job_id"];
            string employee_id = (Request.QueryString["Reject"].Substring(Request.QueryString["Reject"].Length - 6));
            string reason = Request.QueryString["txtComments"];
            DateTime thisDay = DateTime.Now.AddHours(1);

            API.Service int_req = new API.Service();
            XmlDocument _xmlDoc = new XmlDocument();
            _xmlDoc.LoadXml("<XML>" + int_req.reject_candidate(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), employee_id.ToString(), Session["VendorID"].ToString(), "1", reason, job_id.ToString(), emp_end_date.ToString(), job_end_date.ToString(), thisDay.ToString()).InnerXml + "</XML>");
            XmlNodeList ea = _xmlDoc.SelectNodes("XML/RESPONSE");
            API.Service name = new API.Service();
            XmlDocument _xmlDoc1 = new XmlDocument();
            _xmlDoc1.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id, "", "", "", "", "1", "").InnerXml + "</XML>");
            XmlNodeList Response1 = _xmlDoc1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
            string name2 = "";
            name2 = Response1[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response1[iResponse].SelectSingleNode("LASTNAME").InnerText;
            string job_name = Response1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
            string vendor_email = Session["Vendor_Email"].ToString();
            //semail.sendEmail("", "Candidate rejected ", "<br>Candidate Name :" + name2 +
            //                    "<br>Reason of rejection :" + reason +
            //                   "<br>Position applied for :" + job_name +
            //                   "<br>******" +
            //                  "<br>This notification was sent by oveems.If you have any questions regarding this notice," +
            //                  "<br>please contact the SAP Fieldglass Helpdesk at:" +
            //                  "<br>mailto:helpdesk@oveems.com" +
            //                  "<br>By Phone:" +
            //                  "<br>US(toll free) 1 800 123 1234" +
            //                  "<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");

            //********* Sms Notify********** ///////
            SqlConnection conn;
            string readsms;
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string smsquery = "select vendor_id from ovms_employee_actions where job_id = " + job_id;
                    SqlCommand smscmd = new SqlCommand(smsquery, conn);
                    SqlDataReader datareders = smscmd.ExecuteReader();
                    if (datareders.HasRows == true)
                    {
                        while (datareders.Read())
                        {
                            readsms = datareders["vendor_id"].ToString();
                            string message = "Candidate rejected \n" + name2 + "\n " + job_name;
                            //localhost.Service files = new localhost.Service();
                            API.Service files = new API.Service();
                            //files.client_smsNotification(readsms, message, Session["ClientID"].ToString(), "candid_reject_notify");
                        }
                    }
                    datareders.Close();
                    smscmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }



            ///////// ***** end of sms notify******* /////////////

            Response.Redirect("C_ViewCandidates.aspx?copen=Y&p=VC");

        }
        if (Request.QueryString["More"] != null)
        {
            string employee_id = (Request.QueryString["More"].Substring(Request.QueryString["More"].Length - 6));
            string moreinf = Request.QueryString["txtComments"].ToString();
            string job_end_date = Request.QueryString["job_end"];
            string emp_end_date = Request.QueryString["emp_end"];
            string job_id = Request.QueryString["job_id"];

            API.Service more_info = new API.Service();
            XmlDocument _xmlDoc = new XmlDocument();
            _xmlDoc.LoadXml("<XML>" + more_info.more_info_candidate(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), employee_id.ToString(), moreinf, job_id.ToString(), emp_end_date.ToString(), job_end_date.ToString()).InnerXml + "</XML>");
            XmlNodeList ea = _xmlDoc.SelectNodes("XML/RESPONSE");
            API.Service name = new API.Service();
            XmlDocument _xmlDoc1 = new XmlDocument();
            _xmlDoc1.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id, "", "", "", "", "1", "").InnerXml + "</XML>");
            XmlNodeList Response1 = _xmlDoc1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
            string name2 = "";
            name2 = Response1[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response1[iResponse].SelectSingleNode("LASTNAME").InnerText;
            string job_name = Response1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
            string vendor_email = Session["Vendor_Email"].ToString();
            //semail.sendEmail("", "Client needs more information ", "<br>Worker NAme :" + name2 +
            //                      "<br> We want to know about :" + moreinf +
            //                      "<br>Position applied for :" + job_name +
            //                     "<br>******" +
            //                    "<br>This notification was sent by oveems.If you have any questions regarding this notice," +
            //                    "<br>please contact the SAP Fieldglass Helpdesk at:" +
            //                    "<br>mailto:helpdesk@oveems.com" +
            //                    "<br>By Phone:" +
            //                    "<br>US(toll free) 1 800 123 1234" +
            //                    "<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");





            Response.Redirect("C_View_Candidate.aspx?copen=Y&p=VC");

        }
        if (Request.QueryString["reshedule"] != null)
        {

            // following code is to get inderview comments for rescheduling the interview comments
            API.Service getWorkers = new API.Service();
            XmlDocument dom1 = new XmlDocument();
            dom1.LoadXml("<XML>" + getWorkers.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), "", "", Session["ClientID"].ToString(), "", "", "1", "").InnerXml + "</XML>");
            XmlNodeList Response = dom1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");

            string comment2 = "";
            string comment3 = "";
            string comment4 = "";
            string comment5 = "";

            for (int iResponse = 0; iResponse < Response.Count; iResponse++)
            {
                comment2 = Response[iResponse].SelectSingleNode("INTERVIEW_REQUEST_COMMENT2").InnerText;
                comment3 = Response[iResponse].SelectSingleNode("INTERVIEW_REQUEST_COMMENT3").InnerText;
                comment4 = Response[iResponse].SelectSingleNode("INTERVIEW_REQUEST_COMMENT4").InnerText;
                comment5 = Response[iResponse].SelectSingleNode("INTERVIEW_REQUEST_COMMENT5").InnerText;


            }

            string comment = Request.QueryString["newcomments"].ToString();
            {
                string action_id1 = Request.QueryString["action_id"];
                string newdate1 = Request.QueryString["newdate"];
                DateTime newdate2 = DateTime.Parse(newdate1);
                string newtime1 = Request.QueryString["newtime"].ToString();
                DateTime thisDay = DateTime.Now.AddHours(1);
                API.Service reshedule = new API.Service();
                XmlDocument _xmlDoc1 = new XmlDocument();

                if (comment2 == "")
                {
                    _xmlDoc1.LoadXml("<XML>" + reshedule.interview_Reschedule(Session["Email"].ToString(), Session["P@ss"].ToString(), action_id1, newdate2, newtime1, "1", "null", "1", comment, "", "", "", "", "", thisDay.ToString()).InnerXml + "</XML>");

                }
                else
                    if (comment3 == "")
                {


                    _xmlDoc1.LoadXml("<XML>" + reshedule.interview_Reschedule(Session["Email"].ToString(), Session["P@ss"].ToString(), action_id1, newdate2, newtime1, "1", "null", "1", comment2, comment, "", "", "", "", thisDay.ToString()).InnerXml + "</XML>");

                }
                else
                    if (comment4 == "")
                {


                    _xmlDoc1.LoadXml("<XML>" + reshedule.interview_Reschedule(Session["Email"].ToString(), Session["P@ss"].ToString(), action_id1, newdate2, newtime1, "1", "null", "1", comment2, comment3, comment, "", "", "", thisDay.ToString()).InnerXml + " </XML>");

                }
                else
                    if (comment5 == "")
                {


                    _xmlDoc1.LoadXml("<XML>" + reshedule.interview_Reschedule(Session["Email"].ToString(), Session["P@ss"].ToString(), action_id1, newdate2, newtime1, "1", "null", "1", comment2, comment3, comment4, comment, "", "", thisDay.ToString()).InnerXml + " </XML>");

                }








                HttpContext.Current.Response.Redirect("C_View_Candidate.aspx?copen=Y&p=VC");
            }

        }
    }
}