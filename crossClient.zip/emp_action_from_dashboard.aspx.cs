﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class emp_action_from_dashboard : System.Web.UI.Page
{
    private int iResponse;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["approve"] != null)
        {
            string employee_id = (Request.QueryString["approve"].Substring(Request.QueryString["approve"].Length - 6));
            if (Request.QueryString["chkapprove"] == "yes")
            {

                string job_end_date = Request.QueryString["job_end"].ToString();
                string emp_end_date = Request.QueryString["emp_end"].ToString();
                string job_id = Request.QueryString["job_id"].ToString();
                DateTime thisDay = DateTime.Now.AddHours(1);
                //API.Service approve = new API.Service();
                API.Service approve = new API.Service();
                XmlDocument _xmlDoc1 = new XmlDocument();
                _xmlDoc1.LoadXml("<XML>" + approve.candidate_approve(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), employee_id.ToString(), Session["VendorID"].ToString(), "1", job_id, emp_end_date, job_end_date, thisDay.ToString()).InnerXml + "</XML>");
                XmlNodeList ea = _xmlDoc1.SelectNodes("XML/RESPONSE");
                API.Service name = new API.Service();
                XmlDocument _xmlDoc = new XmlDocument();
                _xmlDoc.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id, "", "", "", "", "1", "").InnerXml + "</XML>");
                XmlNodeList ea1 = _xmlDoc.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
                string name2 = "";
                name2 = ea1[iResponse].SelectSingleNode("FIRSTNAME").InnerText;
                string job_name = ea1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
                //*** Sms Notify**** ///////
                SqlConnection conn;
                string readsms;
                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                        string smsquery = "select vendor_id from ovms_employee_actions where job_id = " + job_id;
                        SqlCommand smscmd = new SqlCommand(smsquery, conn);
                        SqlDataReader datareders = smscmd.ExecuteReader();
                        if (datareders.HasRows == true)
                        {
                            while (datareders.Read())
                            {
                                readsms = datareders["vendor_id"].ToString();
                                string message = "Candidate Approved \n" + name2 + "\n " + job_name;
                                //localhost.Service files = new localhost.Service();
                                API.Service files = new API.Service();
                                // files.client_smsNotification(readsms, message, Session["ClientID"].ToString(), "candid_approve_notify");
                            }
                        }
                        datareders.Close();
                        smscmd.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                ///////// ** end of sms notify** /////////////

                HttpContext.Current.Response.Redirect("C_Dashboard.aspx");
            }
            else
            {
                string comment = Request.QueryString["intComment"].ToString();
                string job_end_date = Request.QueryString["job_end"].ToString();
                string emp_end_date = Request.QueryString["emp_end"].ToString();
                string job_id = Request.QueryString["job_id"].ToString();
                string intw_time = Request.QueryString["time"].ToString();
                string intw_date = Request.QueryString["date"].ToString();
                DateTime int_date = Convert.ToDateTime(intw_date);
                DateTime thisDay = DateTime.Now.AddHours(1);
                API.Service int_req = new API.Service();
                // API.Service int_req = new API.Service();
                XmlDocument _xmlDoc = new XmlDocument();
                // _xmlDoc.LoadXml("<XML>" + int_req.interview_request(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString(), employee_id.ToString(), int_date, intw_time).InnerXml + "</XML>");
                _xmlDoc.LoadXml("<XML>" + int_req.interview_request(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), Session["VendorID"].ToString(), employee_id.ToString(), "1", int_date, intw_time, job_id.ToString(), emp_end_date.ToString(), job_end_date.ToString(), comment, "", "", thisDay.ToString()).InnerXml + "</XML>");
                XmlNodeList ea = _xmlDoc.SelectNodes("XML/RESPONSE");
                API.Service name = new API.Service();
                XmlDocument _xmlDoc1 = new XmlDocument();
                _xmlDoc1.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id, "", "", "", "", "1", "").InnerXml + "</XML>");
                XmlNodeList Response1 = _xmlDoc1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
                string name2 = "";
                name2 = Response1[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response1[iResponse].SelectSingleNode("LASTNAME").InnerText;
                string job_name = Response1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
                //*** Sms Notify**** ///////
                SqlConnection conn;
                string readsms;
                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                        string smsquery = "select vendor_id from ovms_employee_actions where job_id =  " + job_id;
                        SqlCommand smscmd = new SqlCommand(smsquery, conn);
                        SqlDataReader datareders = smscmd.ExecuteReader();
                        if (datareders.HasRows == true)
                        {
                            while (datareders.Read())
                            {
                                readsms = datareders["vendor_id"].ToString();
                                string message = "Candidate Interview schedule \n" + name2 + "\n " + job_name;
                                //localhost.Service files = new localhost.Service();
                                API.Service files = new API.Service();
                               // files.client_smsNotification(readsms, message, Session["ClientID"].ToString(), "interview_schedule_notify");
                            }
                        }
                        datareders.Close();
                        smscmd.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }


                ///////// ** end of sms notify** /////////////
                HttpContext.Current.Response.Redirect("C_Dashboard.aspx");
            }
        }
        if (Request.QueryString["Reject_dash1"] != null)
        {
            string employee_id1 = (Request.QueryString["Reject_dash1"].Substring(Request.QueryString["Reject_dash1"].Length - 6));
            string job_end_date = Request.QueryString["job_end"];
            string emp_end_date = Request.QueryString["emp_end"];
            string job_id = Request.QueryString["job_id"];

            string reason = Request.QueryString["txtComments"];
            DateTime thisDay = DateTime.Now.AddHours(1);

            API.Service int_req = new API.Service();
            XmlDocument _xmlDoc = new XmlDocument();
            _xmlDoc.LoadXml("<XML>" + int_req.reject_candidate(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString(), employee_id1.ToString(), Session["VendorID"].ToString(), "1", reason, job_id.ToString(), emp_end_date.ToString(), job_end_date.ToString(), thisDay.ToString()).InnerXml + "</XML>");
            XmlNodeList ea = _xmlDoc.SelectNodes("XML/RESPONSE");
            API.Service name = new API.Service();
            XmlDocument _xmlDoc1 = new XmlDocument();
            _xmlDoc1.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), employee_id1, "", "", "", "", "1", "").InnerXml + "</XML>");
            XmlNodeList Response1 = _xmlDoc1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
            string name2 = "";
            name2 = Response1[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response1[iResponse].SelectSingleNode("LASTNAME").InnerText;
            string job_name = Response1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
            //*** Sms Notify**** ///////
            SqlConnection conn;
            string readsms;
            conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
            try
            {
                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();
                    string smsquery = "select vendor_id from ovms_employee_actions where job_id = " + job_id;
                    SqlCommand smscmd = new SqlCommand(smsquery, conn);
                    SqlDataReader datareders = smscmd.ExecuteReader();
                    if (datareders.HasRows == true)
                    {
                        while (datareders.Read())
                        {
                            readsms = datareders["vendor_id"].ToString();
                            string message = "Candidate rejected \n" + name2 + "\n " + job_name;
                            //localhost.Service files = new localhost.Service();
                            API.Service files = new API.Service();
                           // files.client_smsNotification(readsms, message, Session["ClientID"].ToString(), "candid_reject_notify");
                        }
                    }
                    datareders.Close();
                    smscmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }



            ///////// ** end of sms notify** /////////////
            Response.Redirect("C_Dashboard.aspx");
        }
    }
}