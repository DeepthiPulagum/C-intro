﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class C_Compose_email : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            BtnCancel.CausesValidation = false;
            // BtnReshedule.CausesValidation = false;

        }
        DataTable dt = new DataTable();
        XmlDocument xDoc = new XmlDocument();
        API.Service web = new API.Service();
        xDoc.LoadXml("<XML>" + web.get_vendor(Session["ClientID"].ToString(), Session["Email"].ToString(), Session["P@ss"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response = xDoc.SelectNodes("XML/RESPONSE/VENDOR_ID");
        dt.Columns.Add("VENDOR_NAME", typeof(string));
        dt.Columns.Add("VENDOR_ID", typeof(string));
        foreach (XmlNode node in Response)
        {
            DataRow dr = dt.NewRow();
            dr["VENDOR_NAME"] = node["VENDOR_NAME"].InnerText;
            dr["VENDOR_ID"] = node["VENDOR_ID"].InnerText;
            dt.Rows.Add(dr);
        }
        ddlvendor.DataSource = dt;
        ddlvendor.DataTextField = "VENDOR_NAME";
        ddlvendor.DataValueField = "VENDOR_ID";
        ddlvendor.DataBind();



    }
 protected void sendemail_Click(object sender, EventArgs e)
    {
        string subject = txtsubject.Text;
        string email_content = Request.Form["ctl00$ContentPlaceHolder1$txtemail"]; 

        string vendor_id = Request.Form["ctl00$ContentPlaceHolder1$ddlvendor"];




        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

        string strSqln = "insert into ovms_messages(pmo_id,message,vendor_id,Msg_Subject, User_id, client_id,Actions,IsRead,IsSend,sending_time)" +
                                   "values(1, '" + email_content + "','" + vendor_id + "', '" + subject + "',1, '" + Session["ClientID"].ToString() + "','SEND_C_V',0, 0,'"+DateTime.Now+"')";

        //" and candidate_reject_time >= '" + thisDay + "'";

        
        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        if (cmdn.ExecuteNonQuery() != 0)
        {
            string test = "";
        }

        // readern.Close();
        cmdn.Dispose();
        conn.Close();



        //XmlDocument xDoc = new XmlDocument();
        //API.Service web = new API.Service();
        // LocalAPI.Service web = new LocalAPI.Service();
        //  xDoc.LoadXml("<XML>" + web.Send_Message_client(Session["Email"].ToString(), Session["P@ss"].ToString(), subject, email_content, vendor_id, "1", Session["ClientID"].ToString(), "Send_C_V").InnerXml + "</XML>");
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "",
        "alert('Email Sent');",
        true);
        
        Response.Redirect("C_Sent_message.aspx");
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        BtnCancel.CausesValidation = false;
        Response.Redirect("C_email_inbox.aspx");
    }

    protected void sendemail_Click1(object sender, EventArgs e)
    {
        string subject =Server.HtmlEncode( txtsubject.Text);
        string email_content =Server.HtmlEncode( txtemail.Text); //Request.Form["ctl00$ContentPlaceHolder1$txtemail"])

        string vendor_id = Request.Form["ctl00$ContentPlaceHolder1$ddlvendor"];




        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

        string strSqln = "insert into ovms_messages(pmo_id,message,vendor_id,Msg_Subject, User_id, client_id,Actions,IsRead,IsSend,sending_time,msg_type)" +
                                   "values(1, '" + email_content + "','" + vendor_id + "', '" + subject + "',1, '" + Session["ClientID"].ToString() + "','SEND_C_V',0, 0,'" + DateTime.Now + "','M')";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        if (cmdn.ExecuteNonQuery() != 0)
        {
            string test = "";
        }

        // readern.Close();
        cmdn.Dispose();
        conn.Close();



        //XmlDocument xDoc = new XmlDocument();
        //API.Service web = new API.Service();
        // LocalAPI.Service web = new LocalAPI.Service();
        //  xDoc.LoadXml("<XML>" + web.Send_Message_client(Session["Email"].ToString(), Session["P@ss"].ToString(), subject, email_content, vendor_id, "1", Session["ClientID"].ToString(), "Send_C_V").InnerXml + "</XML>");
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "",
        "alert('Email Sent');",
        true);

        Response.Redirect("C_Sent_message.aspx");
    }

    
}