﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class C_inbox_email_view : System.Web.UI.Page
{
    SqlConnection conn;
    string email_time;
    string Sourceid_reply = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string vendor_id = "";
        string client_name = "";
        string main_msg = "";

        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();


        string strSqln = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        SqlDataReader readern = cmdn.ExecuteReader();
        if (readern.HasRows == true)
        {

            while (readern.Read())
            {



                lblinboxnumber.Text = readern["number"].ToString();


            }


        }
        readern.Close();
        cmdn.Dispose();
        conn.Close();



        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        //lblsub.Text = Request.QueryString["Subject"].ToString();
        string msg_id = Request.QueryString["_id"].ToString();
        string strSql = "select * from ovms_messages where (message_id = " + msg_id +  ") order by message_id desc ";


        conn.Open();

        SqlCommand cmd = new SqlCommand(strSql, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows == true)
        {

            while (reader.Read())

            {

                string today = (DateTime.Now).ToString("yyyyMMdd");
                string time1 = "";


                string date;
                if (reader["sending_time"].ToString() != null)
                {
                    date = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyyMMdd");


                    if (today == date)
                    {

                        email_time = DateTime.Parse(reader["sending_time"].ToString()).ToString("hh.mm tt");



                    }
                    else
                    {

                        email_time = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyy/MM/dd");
                    }
                    lbltime.Text = email_time;
                    lblsub.Text =Server.HtmlDecode( reader["Msg_Subject"].ToString());
                    if (reader["sourceID"].ToString() != "0")
                    {
                       
                        string sql = "select * from ovms_messages where (message_id = " + reader["sourceID"].ToString() + ")  ";




                        SqlCommand command = new SqlCommand(sql, conn);
                        SqlDataReader readert = command.ExecuteReader();
                        if (readert.HasRows == true)
                        {

                            while (readert.Read())

                            {
                                main_msg = main_msg + readert["message"].ToString();
                                string resetISREAD = "update ovms_messages set Isread=1 where message_id= "+ reader["sourceID"].ToString()+ " or SourceID=" + reader["sourceID"].ToString();


                                

                                SqlCommand Command = new SqlCommand(resetISREAD, conn);

                                if (Command.ExecuteNonQuery() != 0)
                                {
                                    string test = "";
                                }
                                string resetISREAD2 = "update ovms_messages set Isread=1 where message_id= " + Request.QueryString["_id"] +" or SourceID=" + reader["sourceID"].ToString();




                                SqlCommand Command2 = new SqlCommand(resetISREAD2, conn);

                                if (Command2.ExecuteNonQuery() != 0)
                                {
                                    string test = "";
                                }
                            }
                        }
                    }
                    else
                    {
                        main_msg = main_msg + reader["message"].ToString();

                    }
                    //if (reader["Actions"].ToString() == "SEND_C_V")
                    //{
                    //    main_msg = main_msg + "<br><br><b>" + "Sent on: " + email_time + "</b><br>" + reader["message"].ToString();
                    //}
                    //else
                    //{
                    //    main_msg = main_msg + "<br><br><b>" + "Received on: " + email_time + "</b><br>" + reader["message"].ToString();

                    //}
                    string strSqlQ = "select * from ovms_messages where (SourceID = " + reader["SourceID"].ToString() + ") order by message_id asc ";
                    Sourceid_reply = reader["SourceID"].ToString();



                    string messageT = "";
                    SqlCommand cmdQ = new SqlCommand(strSqlQ, conn);
                    SqlDataReader readerQ = cmdQ.ExecuteReader();
                    if (readerQ.HasRows == true)
                    {

                        while (readerQ.Read())
                            
                        {
                            string temp = readerQ["Sending_time"].ToString();
                            if (readerQ["actions"].ToString() == "SEND_V_C")
                            {

                                messageT = messageT + @" <div class=""media mb-0""> " +
                                @" <img class=""d-flex mr-3 rounded-circle thumb-sm"" src=""assets/images/users/avatar-2.jpg"">
                                        " +


                                                  @"  <div class=""media-body"">" +
                                                    @"    <div class=""card-box"">" +
                                                      @"      <div class=""summernote"">" +

                                                  @"   " + readerQ["message"].ToString() + " " +
                                                    @"   " + temp + " " +
                                                         @"   </div> " +
                                                      @" </div > " +
                                                        @" </div > " +
                                                @"    </div> ";
                            }
                            else if (readerQ["actions"].ToString() == "SEND_C_V")
                            {
                               
                                messageT = messageT + @" <div class=""media mb-0""> " +
                                                //@" <img class=""d-flex mr-3 rounded-circle thumb-sm"" src=""assets/images/users/175168_203560056325105_4427692_o.jpg"">" +



                                                @"  <div class=""media-body"">" +
                                                  @"    <div class=""card-box"">" +
                                                    @"      <div class=""summernote"">" +

                                                @"   " + readerQ["message"].ToString() + " " +
                                                 @"   " + temp + " " +
                                                       @"   </div> " +
                                                    @" </div > " +
                                                      @" </div > " +
                                              @"    </div> ";

                            }

                            lblmsgThread.Text =Server.HtmlDecode( messageT);
                        
                    }
                    }



                            vendor_id = reader["vendor_id"].ToString();
                }
            }

            lblmsgbody.Text =Server.HtmlDecode( main_msg);
        }
        string strSqlT = "select * from ovms_messages where  sourceID=" + msg_id;




        SqlCommand cmdT = new SqlCommand(strSqlT, conn);
        SqlDataReader readerT = cmdT.ExecuteReader();
        if (reader.HasRows == true)
        {

            while (readerT.Read())
            {


                vendor_id = readerT["client_id"].ToString();
            }


        }
        // txtemail.Text = Server.HtmlDecode(main_msg);
        reader.Close();
        cmd.Dispose();
        string strSql1 = "select vendor_name from ovms_vendors  where vendor_id= " + vendor_id;




        SqlCommand cmd1 = new SqlCommand(strSql1, conn);
        SqlDataReader reader1 = cmd1.ExecuteReader();
        if (reader1.HasRows == true)
        {

            while (reader1.Read())
            {


                client_name = reader1["vendor_name"].ToString();
            }
            lblsender.Text = client_name;

        }



        reader1.Close();


        cmd1.Dispose();
        string strSql2 = "update ovms_messages set IsRead=1 where message_id=" + msg_id;
        SqlCommand cmd2 = new SqlCommand(strSql2, conn);
        SqlDataReader reader2 = cmd2.ExecuteReader();
        if (reader2.HasRows == true)
        {

            while (reader2.Read())
            {


                client_name = reader2["client_name"].ToString();
            }
            //  lblSender.Text = client_name;

        }
        reader2.Close();
        cmd2.Dispose();

        conn.Close();
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {

      
    }

    protected void btnsend_Click(object sender, EventArgs e)
    {
        string reply = Server.HtmlEncode(txtReply.Value);

        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

        string strSqln = "insert into ovms_messages(pmo_id, message, vendor_id, Msg_Subject, SourceID, User_id, client_id,IsSend,IsRead, Actions,sending_time,msg_type)" +
                            " values(1,'" + reply + "','" + Session["VendorID"].ToString() + "', (select Msg_Subject from ovms_messages where message_id = '" + Request.QueryString["_id"].ToString() + "'), '" + Sourceid_reply + "', '" + Session["VendorID"].ToString() + "','" + Session["ClientID"] + "', 0,0, 'SEND_C_V','" + DateTime.Now + "','R')";


        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        if (cmdn.ExecuteNonQuery() != 0)
        {
            string test = "";
        }

        cmdn.Dispose();
        conn.Close();
        //  xDoc.LoadXml("<XML>" + web.Reply_from_Vendor(Session["Email"].ToString(), Session["P@ss"].ToString(), "1", Request.QueryString["_id"].ToString(), txtReply.Value, Session["VendorID"].ToString(), "", Session["ClientID"].ToString(), "", "Send_V_C", "").InnerXml + "</XML>");
        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(),
        "",
        "alert('Email Sent');",
        true);
        //XmlDocument xDoc = new XmlDocument();
        //API.Service web = new API.Service();
        //// LocalAPI.Service web = new LocalAPI.Service();
        //xDoc.LoadXml("<XML>" + web.Reply_from_Vendor(Session["Email"].ToString(), Session["P@ss"].ToString(), "1", Request.QueryString["_id"].ToString(), txtReply.Value, Session["VendorID"].ToString(), "", Session["ClientID"].ToString(), "", "Send_C_V", "").InnerXml + "</XML>");
        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(),
        "",
        "alert('Email Sent');",
        true);
        Response.Redirect("C_Sent_message.aspx");
    }
}