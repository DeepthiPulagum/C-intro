﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Client_T : System.Web.UI.MasterPage
{
    public string UserName { get { return (Session["FirstName"].ToString() + ' ' + Session["LastName"].ToString()); } }
    public string jobDetails { get { return (jbView.Value); } }
    public string empid { get { return empView.Value; } }
    public string tsid { get { return tsview.Value; } }

    StringFunctions func = new StringFunctions();
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["jobID"] != null)
        {
            jbView.Value = Request["jobID"].ToString();
        }

        if (Request["empID"] != null)
        {
            empView.Value = Request["empID"].ToString();
        }

        if (Request["TID"] != null)
        {
            tsview.Value = Request["TID"].ToString();
        }

        if (Request["recieversNo"] != null)
        {
            jbView.Value = Request["recieversNo"].ToString();
        }

        //Breadcrumb
        //subpage.Visible = false;
        //mainpage.Visible=false;

        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

       string strSqln = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        SqlDataReader readern = cmdn.ExecuteReader();
        if (readern.HasRows == true)
        {

            while (readern.Read())
            {
                lblnotification.Text = readern["number"].ToString();

                lblnot2.Visible = true;
                lblnot2.Text = "(" + readern["number"].ToString() + ")";
                if (Convert.ToInt32(readern["number"].ToString()) < 1)

                {

                    lblnot2.Visible = false;

                }

            }


        }
        readern.Close();
        cmdn.Dispose();
        conn.Close();

        //lblname.Text = Session["FirstName"] + " " + Session["LastName"] + " (" + (Session["Email"])+")";


        XmlDocument xmldoc = new XmlDocument();
        API.Service prof = new API.Service();
        // API.Service prof = new API.Service();
        xmldoc.LoadXml("<XML>" + prof.get_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
        // xmldoc.LoadXml("<XML>" + prof.get_Profile("greg@opusing.com ", "1234", "9").InnerXml + "</XML>");
        XmlNodeList Response1 = xmldoc.SelectNodes("XML/RESPONSE/USER_NO");
    }

   
}
