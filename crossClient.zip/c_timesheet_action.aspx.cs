﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class c_timesheet_action : System.Web.UI.Page
{

    string sSQLUpdate = "";
    string _TimeSheetID = "0";
    string sqlGetTimeSheetID = "";
    string sAction = "";
    SqlConnection conn;
    string errString = "";
    StringFunctions func = new StringFunctions();
    emailFunctions semail = new emailFunctions();
    private int iResponse;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["action"] != null)
        {
            //timesheet popup modal action text
            //lblAction.Text = "Timesheet Action";
            // lblActionTimeSheet.Text = "Are you sure you want to " + Request.QueryString["action"] + " this timesheet?";
            if (Request.QueryString["ModalAction"] != null)
            {
                //update status
                conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                        string _TimeSheetID = "0";
                        string sqlGetTimeSheetID = "";

                        //start, end and weeks
                        //get timesheetID + 7

                        sqlGetTimeSheetID = " select timesheet_id " +
                                                " from ovms_timesheet " +
                                                " where day =  " + Request.QueryString["fromD"].ToString() + " " +
                                                " and month =  " + Request.QueryString["FromM"].ToString() + " " +
                                                " and year = " + Request.QueryString["FromY"].ToString() + " " +
                                                " and employee_id = " + Request.QueryString["TID"].ToString() + " " +
                                                " and active =  1";

                        SqlCommand cmdGetTimeSheetID = new SqlCommand(sqlGetTimeSheetID, conn);
                        SqlDataReader rsGetTimeSheetID = cmdGetTimeSheetID.ExecuteReader();
                        if (rsGetTimeSheetID.HasRows == true)
                        {
                            while (rsGetTimeSheetID.Read())
                            {
                                _TimeSheetID = rsGetTimeSheetID["timesheet_id"].ToString();
                            }
                        }
                        //close
                        rsGetTimeSheetID.Close();
                        cmdGetTimeSheetID.Dispose();

                        string sSQLUpdate = "";
                        string sAction = "";
                        if (Request.QueryString["action"] == "Approve")
                        {
                            //update
                            sAction = "Approve";
                            sSQLUpdate = " update ovms_timesheet_details " +
                                                        " set timesheet_status_id = 1 " +
                                                        " where timesheet_id between " + _TimeSheetID + " and " + (Convert.ToInt32(_TimeSheetID.ToString()) + +Convert.ToInt32("6")) + " " +
                                                        " and active = 1";


                            //string emp_id = Request.QueryString["TID"].ToString();
                            //string totalhours = Request.QueryString["hours"].ToString();
                            //string name = Request.QueryString["Mess"].ToString();
                            //string vendor_email = Session["Vendor_Email"].ToString();


                            //    semail.sendEmail(vendor_email, "TIMESHEET is approved - (" + name + ")", "<br>Worker ID :" + emp_id +

                            //        "<br>Time Sheet Billable Days : 7 days" +
                            //        "<br>Time Sheet Billable Hours :" + totalhours +
                            //        "<br>******" +
                            //        "<br>This notification was sent by FlentisPRO.If you have any questions regarding this notice," +
                            //        "<br>please contact the SAP Fieldglass Helpdesk at:" +
                            //        "<br>mailto:helpdesk@oveems.com" +
                            //        "<br>By Phone:" +
                            //        "<br>US(toll free) 1 800 123 1234" +
                            //        "<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");
                        }

                        if (Request.QueryString["action"] == "Reject")
                            {
                                //update
                                string test = _TimeSheetID;
                                sAction = "Reject";
                                sSQLUpdate = " update ovms_timesheet_details " +
                                                            " set timesheet_status_id = 2 " +
                                                            " where timesheet_id between " + _TimeSheetID + " and " + (Convert.ToInt32(_TimeSheetID.ToString()) + +Convert.ToInt32("6")) + " " +
                                                            " and active = 1";
                                string emp_id = Request.QueryString["TID"].ToString();
                                API.Service name = new API.Service();
                                XmlDocument _xmlDoc = new XmlDocument();
                                _xmlDoc.LoadXml("<XML>" + name.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), emp_id, "", "", "", "", "1", "").InnerXml + "</XML>");
                                XmlNodeList ea1 = _xmlDoc.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
                                string name2 = "";
                                name2 = ea1[iResponse].SelectSingleNode("FIRSTNAME").InnerText;
                                string job_name = ea1[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
                                string vendor_email = Session["Vendor_Email"].ToString();
                            //semail.sendEmail(vendor_email, "TIMESHEET is rejected - (" + name + ")", "<br>Worker Name :" + name2 +

                            //"<br>******" +
                            //"<br>This notification was sent by FlentisPRO.If you have any questions regarding this notice," +
                            //"<br>please contact the SAP Fieldglass Helpdesk at:" +
                            //"<br>mailto:helpdesk@oveems.com" +
                            //"<br>By Phone:" +
                            //"<br>US(toll free) 1 800 123 1234" +
                            //"<br>Please do not respond to this email, this is an automatic email message and this mailbox is not being monitored.", "", "");

                        }
                        //    Uri uri = new Uri("http://www.opusingats.com/e_Timesheet_Email.aspx?timesheet_id=1");

                        //    string data = "field-keywords=ASP.NET 2.0";

                        //    HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
                        //    request.Method = WebRequestMethods.Http.Post;
                        //    request.ContentLength = data.Length;
                        //    request.ContentType = "application/x-www-form-urlencoded";
                        //    StreamWriter writer = new StreamWriter(request.GetRequestStream());
                        //    writer.Write(data);
                        //    writer.Close();
                        //    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                        //    StreamReader reader = new StreamReader(response.GetResponseStream());

                        //    string tmp = reader.ReadToEnd();
                        //    response.Close();
                        //    Response.Write(tmp);
                        //    Response.Write(tmp);

                        //    MailMessage mail = new MailMessage();
                        //    set the addresses
                        //    mail.From = new MailAddress("notifications@opusingats.com"); //IMPORTANT: This must be same as your smtp authentication address.
                        //    mail.To.Add("greg@opusing.com");

                        //    set the content
                        //    mail.Subject = "This is an email";
                        //    mail.Body = tmp;
                        //    mail.IsBodyHtml = true;

                        //    send the message
                        //    SmtpClient smtp = new SmtpClient("mail.opusingats.com");

                        //IMPORANT: Your smtp login email MUST be same as your FROM address. 
                        //    NetworkCredential Credentials = new NetworkCredential("notifications@opusingats.com", "Maracaibo15@.");
                        //    smtp.Credentials = Credentials;
                        //    smtp.Send(mail);
                        // blMessage.Text = "Mail Sent";
                        SqlCommand cmdUpdateTimeSheet1 = new SqlCommand(sSQLUpdate, conn);
                            int iUpdate = cmdUpdateTimeSheet1.ExecuteNonQuery();
                            cmdUpdateTimeSheet1.Dispose();


                        }
                    
                }
                catch (Exception ex)
                {
                    string abc = "";
                }
                finally
                {
                    if (conn.State == System.Data.ConnectionState.Open)
                        conn.Close();
                }
            } //end of ModalAction
        }

        Response.Redirect("C_Timesheet_View.aspx?topen=Y&p=VT&TU=True&TID=" + Request.QueryString["TID"].ToString());
        Response.End();

        //Response.Redirect("Client.aspx?TU=True");
        //Response.End();
        //end of update timesheet status
    }
}