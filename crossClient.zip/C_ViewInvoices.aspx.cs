﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class C_ViewInvoices : System.Web.UI.Page
{
    int iResponse;
    int iResponse2;
    string vendorDetails;
    int tax;
    double subTotal;
    int sr_number;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        lblToday.Text = DateTime.Now.ToString("dd MMM, yyyy");
        string CurrentMonth = ((String.Format("{0:MMMM}", DateTime.Now)).Substring(0, 3)).ToUpper();
        string CurrentDay = DateTime.Now.ToString("dd");
        string Currentyear = (DateTime.Now.Year.ToString()).Substring(2, 2);
        lblInvoiceN.Text = CurrentMonth + CurrentDay + "00" + Currentyear;
        API.Service invoiceV = new API.Service();
        XmlDocument ClientD = new XmlDocument();
        ClientD.LoadXml("<XML>" + invoiceV.get_CLient(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response1 = ClientD.SelectNodes("XML/RESPONSE/CLIENTS/CLIENT");
        try
        {

            //lblClientName.Text = "Hello " + Response1[iResponse].SelectSingleNode("CLIENT_NAME").InnerText + ",";
            string client_address = Response1[iResponse].SelectSingleNode("CLIENT_CITY").InnerText + "<br>";
            client_address += Response1[iResponse].SelectSingleNode("CLIENT_COUNTRY").InnerText + "<br>";
            client_address += Response1[iResponse].SelectSingleNode("CLIENT_FAXNUMBER").InnerText + "<br>";
            client_address += Response1[iResponse].SelectSingleNode("CLIENT_PHONENUMBER").InnerText + "<br>";
            lblClientAddress.Text = client_address;



        }

        catch (Exception ex)
        {


        }
        SqlConnection conn;
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

        // conn.Open();
        string vendorID = Session["VendorID"].ToString();
        // string strSqln = "select * from ovms_jobs where job_id="+ jobid2;
        try
        {

            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();


                string strSql = "select * from ovms_vendor_details where vendor_id=" + Session["VendorID"].ToString();







                SqlCommand cmd = new SqlCommand(strSql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                //xml_string += "<RESPONSE>";
                if (reader.HasRows)
                    while (reader.Read())
                    {
                        vendorDetails += reader["vendor_address1"].ToString() + "<br>";
                        vendorDetails += reader["vendor_city"].ToString() + "<br>";
                        vendorDetails += reader["vendor_country"].ToString() + "<br>";
                        vendorDetails += reader["vendor_postal_code"].ToString() + "<br>";





                    }
                lblvendoraddress.Text = vendorDetails;
                reader.Close();
                cmd.Dispose();
                conn.Close();


            }
        }
        catch (Exception ex)
        {
            //logService.set_log(124, HttpContext.Current.Request.Url.AbsoluteUri, ex.Message);
        }


        try
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();

                string mondayOfLastWeek = (DateTime.Now.AddDays(-(int)DateTime.Now.DayOfWeek - 6)).ToString("dd");
                string month = (DateTime.Now.AddDays(-(int)DateTime.Now.DayOfWeek - 6)).ToString("MM");
                string month1 = ((DateTime.Now.AddDays(-(int)DateTime.Now.DayOfWeek - 6)).AddDays(7)).ToString("MM");

                int sundayoFLastWeek = Convert.ToInt32(mondayOfLastWeek) + 7;

                string strSql = "select  concat (ed.first_name,' ',ed.last_name) as Employee_name ,sum(ts.hours) as hours,ed.province ,ed.pay_rate, ja.markup " +

                               "     from ovms_timesheet as ts " +

                                "    join ovms_timesheet_details as td on td.timesheet_id = ts.timesheet_id " +
                                 "   join ovms_employee_details as ed on ed.employee_id = ts.employee_id " +
                                        " join ovms_employees as emp on emp.employee_id = ed.employee_id " +
                                           " join ovms_job_accounting as ja on ja.job_id = emp.job_id " +
                                  "  where( ts.day <= '" + sundayoFLastWeek + "' and ts.month = '" + month + "') and( ts.day >= '" + mondayOfLastWeek + "' and ts.month = '" + month1 + "') " +
                                   " and ts.year = '2018'  and td.timesheet_status_id = 1 and emp.client_id=" + Session["ClientID"].ToString() + " and emp.vendor_id = " + Session["VendorID"].ToString() +
                                   " group by ed.first_name,ed.last_name,ed.pay_rate,ed.province,ja.markup ";






                string rowDetails = "";
                SqlCommand cmd = new SqlCommand(strSql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                //xml_string += "<RESPONSE>";
                if (reader.HasRows)
                    while (reader.Read())
                    {
                        string province = (reader["province"].ToString()).Substring(0, 2);
                        string strSqlL = "select sum(cast(province_rate as int)+cast(Canada_Rate as int)) as total from ovms_tax where province='" + province + "'";







                        SqlCommand cmdL = new SqlCommand(strSqlL, conn);
                        SqlDataReader readerL = cmdL.ExecuteReader();
                        //xml_string += "<RESPONSE>";
                        if (readerL.HasRows)
                            while (readerL.Read())
                            {

                                tax = Convert.ToInt32(readerL["total"].ToString());
                                lblTax.Text = tax.ToString() + "%";
                            }
                        sr_number += 1;
                        int amount = Convert.ToInt32(reader["pay_rate"].ToString()) * Convert.ToInt32(reader["hours"].ToString());
                        subTotal = subTotal + amount;
                        rowDetails = rowDetails + @" <tr> " +
                                     @"   <td> " + sr_number + " </td> " +
                                     @"   <td> " +
                                        @"    <b> " + reader["Employee_name"].ToString() + " </b> " +
                                         @"   <br/> " +

                                     @"   </td> " +
                                      @"  <td> " + reader["hours"].ToString() + " </td> " +
                                     @"   <td>" + reader["pay_rate"].ToString() + " </td> " +


                                       @"   <td class=""text-right"">" + amount + "</td> " +
                                 @"   </tr> ";



                    }
                else

                {
                    rowDetails = rowDetails + @" <tr> " +
                                    @"   <td>  </td> " +
                                    @"   <td> " +
                                       @"    <b>  </b> " +
                                        @"   <br/> " +

                                    @"   </td> " +
                                     @"  <td>No record to show </td> " +
                                    @"   <td></td> " +


                                      @"   <td class=""text-right""></td> " +
                                @"   </tr> ";



                }
                lbltable.Text = rowDetails;
                reader.Close();
                cmd.Dispose();
                conn.Close();


            }
        }
        catch (Exception ex)
        {



        }
        lblsubtotal.Text = (subTotal).ToString();
        lbltotaltax.Text = ((subTotal / 100) * tax).ToString();
        lblGrandTotal.Text = (Convert.ToInt32(subTotal) + Convert.ToInt32(subTotal / 100) * tax).ToString();
    }

}

//    public string GetStateProvinceTax(string StateProvince)
//    {
//        string sTax = "0,0,0";
//        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
//        try
//        {
//            if (conn.State == System.Data.ConnectionState.Closed)
//            {
//                conn.Open();


//                //getJobs
//                string strGetTax = "select rate_type, province_rate, canada_rate from ovms_tax where province = '" + StateProvince + "' and country = 'CA'";
//                SqlCommand cmdGetTax = new SqlCommand(strGetTax, conn);
//                SqlDataReader readerGetTax = cmdGetTax.ExecuteReader();
//                //string _svendorList = "";
//                while (readerGetTax.Read())
//                {
//                    sTax = readerGetTax["rate_type"].ToString() + "," + (Convert.ToDouble(readerGetTax["province_rate"].ToString()) + Convert.ToDouble(readerGetTax["canada_rate"].ToString()));
//                }
//                //close
//                readerGetTax.Close();
//                cmdGetTax.Dispose();
//            }
//        }
//        catch (Exception ex)
//        {
//            //
//        }
//        finally
//        {
//            if (conn.State == System.Data.ConnectionState.Open)
//                conn.Close();
//        }
//        return sTax;

//    }
//    public string GetVendorPay(string Job_ID)
//    {
//        string vendorPay = "0,0,0";
//        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
//        try
//        {
//            if (conn.State == System.Data.ConnectionState.Closed)
//            {
//                conn.Open();


//                //getJobs
//                string strGetVendorPay = "select vender_pay_rate, vender_ot_pay_rate, vender_dt_pay_rate from ovms_job_accounting where job_id = " + Job_ID;
//                SqlCommand cmdGetVendorPay = new SqlCommand(strGetVendorPay, conn);
//                SqlDataReader readerVendorPay = cmdGetVendorPay.ExecuteReader();
//                //string _svendorList = "";
//                while (readerVendorPay.Read())
//                {
//                    vendorPay = readerVendorPay["vender_pay_rate"].ToString() + "," + readerVendorPay["vender_ot_pay_rate"].ToString() + "," + readerVendorPay["vender_dt_pay_rate"].ToString();
//                }
//                //close
//                readerVendorPay.Close();
//                cmdGetVendorPay.Dispose();
//            }
//        }
//        catch (Exception ex)
//        {
//            //
//        }
//        finally
//        {
//            if (conn.State == System.Data.ConnectionState.Open)
//                conn.Close();
//        }
//        return vendorPay;

//    }
//    public string GetStateProvinceOverTime(string StateProvince)
//    {
//        string overtime = "0";
//        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
//        try
//        {
//            if (conn.State == System.Data.ConnectionState.Closed)
//            {
//                conn.Open();


//                //getJobs
//                string strGetStateProvince_Overtime = "select state_overtime from ovms_state where state_code ='ON' ";
//                SqlCommand cmdGetStateProvince_Overtime = new SqlCommand(strGetStateProvince_Overtime, conn);
//                SqlDataReader readerStateProvince_Overtime = cmdGetStateProvince_Overtime.ExecuteReader();
//                //string _svendorList = "";
//                while (readerStateProvince_Overtime.Read())
//                {
//                    overtime = readerStateProvince_Overtime["state_overtime"].ToString();
//                }
//                //close
//                readerStateProvince_Overtime.Close();
//                cmdGetStateProvince_Overtime.Dispose();
//            }
//        }
//        catch (Exception ex)
//        {
//            //
//        }
//        finally
//        {
//            if (conn.State == System.Data.ConnectionState.Open)
//                conn.Close();
//        }
//        return overtime;

//    }

//    public string GetProgramFee(string vendorID)
//    {
//        string sVendorFee = "0";
//        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
//        try
//        {
//            if (conn.State == System.Data.ConnectionState.Closed)
//            {
//                conn.Open();


//                //getJobs
//                string strGetProgramFee = "select program_fee from ovms_vendor_details where vendor_id = " + vendorID + "";
//                SqlCommand cmdGetProgramFee = new SqlCommand(strGetProgramFee, conn);
//                SqlDataReader readerGetProgramFee = cmdGetProgramFee.ExecuteReader();
//                //string _svendorList = "";
//                while (readerGetProgramFee.Read())
//                {
//                    sVendorFee = readerGetProgramFee["program_fee"].ToString();
//                }
//                //close
//                readerGetProgramFee.Close();
//                cmdGetProgramFee.Dispose();
//            }
//        }
//        catch (Exception ex)
//        {
//            //
//        }
//        finally
//        {
//            if (conn.State == System.Data.ConnectionState.Open)
//                conn.Close();
//        }
//        return sVendorFee;
//    }
//}