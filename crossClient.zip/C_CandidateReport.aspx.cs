﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class C_CandidateReport : System.Web.UI.Page
{
    public string UserName { get { return (Session["FirstName"].ToString() + ' ' + Session["LastName"].ToString()); } }
    public string jobDetails { get { return (jbView.Value); } }
    public string empid { get { return empView.Value; } }
    public string tsid { get { return tsview.Value; } }

    StringFunctions func = new StringFunctions();
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["jobID"] != null)
        {
            jbView.Value = Request["jobID"].ToString();
        }

        if (Request["empID"] != null)
        {
            empView.Value = Request["empID"].ToString();
        }

        if (Request["TID"] != null)
        {
            tsview.Value = Request["TID"].ToString();
        }

        if (Request["recieversNo"] != null)
        {
            jbView.Value = Request["recieversNo"].ToString();
        }
        if (!Page.IsPostBack)
        {
            ReportViewer();
        }
        //Breadcrumb
        //subpage.Visible = false;
        //mainpage.Visible=false;

        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

        string strSqln = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        SqlDataReader readern = cmdn.ExecuteReader();
        if (readern.HasRows == true)
        {

            while (readern.Read())
            {
                lblnotification.Text = readern["number"].ToString();

                lblnot2.Visible = true;
                lblnot2.Text = "(" + readern["number"].ToString() + ")";
                if (Convert.ToInt32(readern["number"].ToString()) < 1)

                {

                    lblnot2.Visible = false;

                }

            }


        }
        readern.Close();
        cmdn.Dispose();
        conn.Close();

        //lblname.Text = Session["FirstName"] + " " + Session["LastName"] + " (" + (Session["Email"])+")";


        XmlDocument xmldoc = new XmlDocument();
        API.Service prof = new API.Service();
        // API.Service prof = new API.Service();
        xmldoc.LoadXml("<XML>" + prof.get_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
        // xmldoc.LoadXml("<XML>" + prof.get_Profile("greg@opusing.com ", "1234", "9").InnerXml + "</XML>");
        XmlNodeList Response1 = xmldoc.SelectNodes("XML/RESPONSE/USER_NO");

        //txtfirst.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/FIRST_NAME").InnerText;
        //txtsecond.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/LAST_NAME").InnerText;
        //txtemail.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/EMAIL").InnerText;

        //string interview_alert = "";
        //conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

        //if (conn.State == System.Data.ConnectionState.Closed)
        //{
        //    DateTime thisDay = DateTime.Now;
        //    string vendorID = Session["VendorID"].ToString();
        //    conn.Open();

        //    string strSql = " select cast(interview_date as datetime) + (select cast(interview_time as datetime) ) as interview " +
        //                   "  from ovms_employee_actions where client_id = '" + Session["ClientID"].ToString() + "' and interview_confirm = 1 and(cast(interview_date as datetime) + (select cast(interview_time as datetime))) " +
        //                   "    BETWEEN DATEADD(HOUR, 3, DATEADD(minute, 10, GETDATE())) and DATEADD(minute, +15, DATEADD(HOUR, 3, GETDATE())) ";

        //    SqlCommand cmd = new SqlCommand(strSql, conn);
        //    SqlDataReader reader = cmd.ExecuteReader();
        //    if (reader.HasRows == true)
        //    {
        //        interview_alert = "1";

        //    }
        //    if (interview_alert == "1")
        //    {
        //        System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, typeof(System.Web.UI.Page), "Script", "interviewTIME('','','');", true);
        //        // Response.End();

        //    }
        //}
    }

    //protected void selEmployee_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    string Employee_Name = selEmployee.SelectedItem.Text;
    //    Response.Redirect("Add_Jobs.aspx?jopen=Y&p=JA&type=" + selEmployee.SelectedItem.Value);
    //    Response.End();
    //}



    //protected void seljobtype_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    Response.Redirect("Add_jobs.aspx?type=" + seljobtype.SelectedItem.Value);
    //}

    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    if (txtnewpassword.Text == "" || txtconfirmpassword.Text == "")
    //    {

    //        Label1.Text = "*Fields can not be empty";
    //        Label1.ForeColor = System.Drawing.Color.Red;
    //        Label1.Focus();
    //    }
    //    else
    //    {
    //        if (txtnewpassword.Text != txtconfirmpassword.Text)
    //        {

    //            Label1.Text = "*Passwords do not match";
    //            Label1.ForeColor = System.Drawing.Color.Red;
    //            Label1.Focus();

    //        }
    //        else
    //        {
    //            XmlDocument xmldoc = new XmlDocument();
    //            API.Service updateP = new API.Service();
    //            xmldoc.LoadXml("<XML>" + updateP.update_Personal_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString(), txtnewpassword.Text).InnerXml + "</XML>");
    //            Session["P@ss"] = "";
    //            Session["P@ss"] = txtnewpassword.Text;
    //            Response.Redirect("C_Dashboard.aspx");
    //        }


    //    }
    //}
    protected void btnCandidatereport_Click(object sender, EventArgs e)
    {
        ReportViewer();

    }
    protected void ReportViewer()
    {
        try
        {

            ReportViewer1.ProcessingMode = ProcessingMode.Remote;
            ReportViewer1.ServerReport.ReportServerCredentials = new ReportViewerCredentials("aseemanand-001", "Iw2raran17.", "IFC");
            ReportViewer1.ServerReport.ReportServerUrl = new Uri("http://sql5030.smarterasp.net/ReportServer");
            ReportViewer1.ServerReport.ReportPath = "/aseemanand-001/Submitted_Candidate";
            ReportParameter[] reportParameterCollection = new ReportParameter[3];
            reportParameterCollection[0] = new ReportParameter();
            reportParameterCollection[0].Name = "vendor_id";
            reportParameterCollection[0].Values.Add(Session["VendorID"].ToString());

            reportParameterCollection[1] = new ReportParameter();
            reportParameterCollection[1].Name = "start_date";
            if (fromdate.Value.Equals(""))
                reportParameterCollection[1].Values.Add(null);
            else
                reportParameterCollection[1].Values.Add(fromdate.Value);

            reportParameterCollection[2] = new ReportParameter();
            reportParameterCollection[2].Name = "end_date";
            if (todate.Value.Equals(""))
                reportParameterCollection[2].Values.Add(null);
            else
                reportParameterCollection[2].Values.Add(todate.Value);

            ReportViewer1.ServerReport.SetParameters(reportParameterCollection);
            ReportViewer1.ServerReport.Refresh();
            ReportViewer1.ShowParameterPrompts = false;
            ReportViewer1.ShowPrintButton = true;


        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }
    public partial class ReportViewerCredentials : IReportServerCredentials
    {
        private string _userName;
        private string _password;
        private string _domain;


        public ReportViewerCredentials(string userName, string password, string domain)
        {
            _userName = userName;
            _password = password;
            _domain = domain;


        }

        public WindowsIdentity ImpersonationUser
        {
            get
            {
                return null;
            }
        }


        public ICredentials NetworkCredentials
        {
            get
            {
                return new NetworkCredential(_userName, _password, _domain);
            }
        }

        public bool GetFormsCredentials(out Cookie authCookie,
                out string userName, out string password,
                out string authority)
        {
            authCookie = null;
            userName = _userName;
            password = _password;
            authority = _domain;


            // Not using form credentials
            return false;
        }

    }


    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        ICredentials IReportServerCredentials.NetworkCredentials
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }
}
