﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class Dynamic_Report : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
    StringFunctions func = new StringFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        if(!IsPostBack)
        {
            jobs_data.Style.Add("display", "none");
            vendorperformance_data.Style.Add("display", "none");
            Employee_Status.Style.Add("display", "none");
        }
        
        ClientJobs();
        vendor();
        worker();
    }
    private void ClientJobs()
    {
        try
        {
            DataTable jobstab = new DataTable();
            jobstab.Columns.Add("Job_Title", typeof(string));
            jobstab.Columns.Add("Job_ID", typeof(int));
            if (Conn.State == System.Data.ConnectionState.Closed)
            {
                Conn.Open();
                string sqlstr = "select * from ovms_jobs where client_id = '" + Session["ClientID"].ToString() + "'";
                SqlCommand scmd = new SqlCommand(sqlstr, Conn);
                SqlDataReader sread = scmd.ExecuteReader();
                if (sread.HasRows)
                {
                    while (sread.Read())
                    {
                        DataRow drow = jobstab.NewRow();
                        drow["Job_Title"] = sread["job_title"].ToString();
                        drow["Job_ID"] = sread["job_id"].ToString();
                        jobstab.Rows.Add(drow);
                    }
                }
                scmd.Dispose();
                sread.Close();
                job_id.DataSource = jobstab;
                job_id.DataTextField = "Job_Title";
                job_id.DataValueField = "Job_ID";
                job_id.DataBind();

                vjob_id.DataSource = jobstab;
                vjob_id.DataTextField = "Job_Title";
                vjob_id.DataValueField = "Job_ID";
                vjob_id.DataBind();
            }
        }
        catch(Exception ex)
        {

        }
        finally
        {
            if(Conn.State==System.Data.ConnectionState.Open)
            {
                Conn.Close();
            }
        }
    }
    private void vendor()
    {
        try
        {
            DataTable vendortab = new DataTable();
            vendortab.Columns.Add("Vendor_Name", typeof(string));
            vendortab.Columns.Add("Vendor_ID", typeof(string));
            if (Conn.State == System.Data.ConnectionState.Closed)
            {
                Conn.Open();
                string sqlstr = "select * from ovms_vendors";
                SqlCommand scmd = new SqlCommand(sqlstr, Conn);
                SqlDataReader sread = scmd.ExecuteReader();
                if(sread.HasRows)
                {
                    while(sread.Read())
                    {
                        DataRow drow = vendortab.NewRow();
                        drow["Vendor_Name"] = sread["vendor_name"].ToString();
                        drow["Vendor_ID"] = sread["vendor_id"].ToString();
                        vendortab.Rows.Add(drow);
                    }
                }
                scmd.Dispose();
                sread.Close();
                vendor_id.DataSource = vendortab;
                vendor_id.DataTextField = "Vendor_Name";
                vendor_id.DataValueField = "Vendor_ID";
                vendor_id.DataBind();

                vvendor_id.DataSource = vendortab;
                vvendor_id.DataTextField = "Vendor_Name";
                vvendor_id.DataValueField = "Vendor_ID";
                vvendor_id.DataBind();

                empvendorid.DataSource = vendortab;
                empvendorid.DataTextField = "Vendor_Name";
                empvendorid.DataValueField = "Vendor_ID";
                empvendorid.DataBind();
            }
        }
        catch(Exception ex)
        {

        }
        finally
        {
            if(Conn.State == System.Data.ConnectionState.Open)
            {
                Conn.Close();
            }
        }
        
    }
    private void worker()
    {
        DataTable tab = new DataTable();
        API.Service worker = new API.Service();
        XmlDocument xdoc = new XmlDocument();
        xdoc.LoadXml("<XML>" + worker.get_employees("", "", "", "", Session["ClientID"].ToString(), "", "", "1", "").InnerXml + "</XML>");
        XmlNodeList Response = xdoc.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
        tab.Columns.Add("Worker_Name", typeof(string));
        tab.Columns.Add("Worker_ID", typeof(string));
        string datatable = "";
        foreach (XmlNode node in Response)
        {
            DataRow row = tab.NewRow();
            row["Worker_Name"] = "" + func.FixString(node["FIRSTNAME"].InnerText) + " " + func.FixString(node["LASTNAME"].InnerText) ; //Convert.ToDateTime(node["CONTRACT_START_DATE"].InnerText).DayOfWeek + " " + Convert.ToDateTime(node["CONTRACT_START_DATE"].InnerText).ToString("dd/MM/yyyy") + ""  //DateTime.TryParseExact(node["CONTRACT_START_DATE"].InnerText, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt); 
            row["Worker_ID"] = node["EMPLOYEE_ID"].InnerText.Substring(4, node["EMPLOYEE_ID"].InnerText.Length-4);
            tab.Rows.Add(row);
        }
        datatable = datatable + "";
        employee_id.DataSource = tab;
        employee_id.DataTextField = "Worker_Name";
        employee_id.DataValueField = "Worker_ID";
        employee_id.DataBind();

        empID.DataSource = tab;
        empID.DataTextField = "Worker_Name";
        empID.DataValueField = "Worker_ID";
        empID.DataBind();

    }
    protected void ReportViewer(ReportParameter[] reportParameterCollection)
    {
        try
        {
            ReportViewer2.ServerReport.SetParameters(reportParameterCollection);
            ReportViewer2.ServerReport.Refresh();
            ReportViewer2.ShowParameterPrompts = false;
            ReportViewer2.ShowPrintButton = true;

        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }


    public partial class ReportViewerCredentials : IReportServerCredentials
    {
        private string _userName;
        private string _password;
        private string _domain;


        public ReportViewerCredentials(string userName, string password, string domain)
        {
            _userName = userName;
            _password = password;
            _domain = domain;


        }

        public WindowsIdentity ImpersonationUser
        {
            get
            {
                return null;
            }
        }


        public ICredentials NetworkCredentials
        {
            get
            {
                return new NetworkCredential(_userName, _password, _domain);
            }
        }

        public bool GetFormsCredentials(out Cookie authCookie,
                out string userName, out string password,
                out string authority)
        {
            authCookie = null;
            userName = _userName;
            password = _password;
            authority = _domain;


            // Not using form credentials
            return false;
        }

    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        ICredentials IReportServerCredentials.NetworkCredentials
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }



    protected void Jobs_Click(object sender, EventArgs e)
    {
        jobs_data.Style.Add("display", "flex");
        vendorperformance_data.Style.Add("display", "none");
        Employee_Status.Style.Add("display", "none");
    }

    protected void VendorPerformance_Click(object sender, EventArgs e)
    {
        vendorperformance_data.Style.Add("display", "flex");
        jobs_data.Style.Add("display", "none");
        Employee_Status.Style.Add("display", "none");
    }

    protected void jobs_report_Click(object sender, EventArgs e)
    {
        jobs_data.Style.Add("display", "flex");

        ReportViewer2.ProcessingMode = ProcessingMode.Remote;
        ReportViewer2.ServerReport.ReportServerCredentials = new ReportViewerCredentials("aseemanand-001", "Iw2raran17.", "IFC");
        ReportViewer2.ServerReport.ReportServerUrl = new Uri("http://sql5030.smarterasp.net/ReportServer");
        ReportViewer2.ServerReport.ReportPath = "/aseemanand-001/Client_Posted_Jobs";

        ReportParameter[] reportParameterCollection = new ReportParameter[4];
        reportParameterCollection[0] = new ReportParameter();
        reportParameterCollection[0].Name = "client_id";
        reportParameterCollection[0].Values.Add(Session["ClientID"].ToString());
        reportParameterCollection[1] = new ReportParameter();
        reportParameterCollection[1].Name = "vendor_id";
        if (vendor_id.SelectedValue.ToString().Equals(""))
            reportParameterCollection[1].Values.Add(null);
        else
            reportParameterCollection[1].Values.Add(vendor_id.SelectedValue.ToString());
        reportParameterCollection[2] = new ReportParameter();
        reportParameterCollection[2].Name = "job_id";
        if (job_id.SelectedValue.ToString().Equals(""))
            reportParameterCollection[2].Values.Add(null);
        else
            reportParameterCollection[2].Values.Add(job_id.SelectedValue.ToString());
        reportParameterCollection[3] = new ReportParameter();
        reportParameterCollection[3].Name = "active";
        if (jobactive.SelectedValue.ToString().Equals(""))
            reportParameterCollection[3].Values.Add(null);
        else
            reportParameterCollection[3].Values.Add(jobactive.SelectedValue.ToString());
        ReportViewer(reportParameterCollection);
    }

    protected void vendor_performance_report_Click(object sender, EventArgs e)
    {
        vendorperformance_data.Style.Add("display", "flex");

        ReportViewer2.ProcessingMode = ProcessingMode.Remote;
        ReportViewer2.ServerReport.ReportServerCredentials = new ReportViewerCredentials("aseemanand-001", "Iw2raran17.", "IFC");
        ReportViewer2.ServerReport.ReportServerUrl = new Uri("http://sql5030.smarterasp.net/ReportServer");
        ReportViewer2.ServerReport.ReportPath = "/aseemanand-001/Client_Vendor_Performance_View";

        ReportParameter[] reportParameterCollection = new ReportParameter[5];
        reportParameterCollection[0] = new ReportParameter();
        reportParameterCollection[0].Name = "client_id";
        reportParameterCollection[0].Values.Add(Session["ClientID"].ToString());
        reportParameterCollection[1] = new ReportParameter();
        reportParameterCollection[1].Name = "vendor_id";
        if (vvendor_id.SelectedValue.ToString().Equals(""))
            reportParameterCollection[1].Values.Add(null);
        else
            reportParameterCollection[1].Values.Add(vvendor_id.SelectedValue.ToString());
        reportParameterCollection[2] = new ReportParameter();
        reportParameterCollection[2].Name = "job_id";
        if (vjob_id.SelectedValue.ToString().Equals(""))
            reportParameterCollection[2].Values.Add(null);
        else
            reportParameterCollection[2].Values.Add(vjob_id.SelectedValue.ToString());
        reportParameterCollection[3] = new ReportParameter();
        reportParameterCollection[3].Name = "employee_id";
        if (employee_id.SelectedValue.ToString().Equals(""))
            reportParameterCollection[3].Values.Add(null);
        else
            reportParameterCollection[3].Values.Add(employee_id.SelectedValue.ToString());
        reportParameterCollection[4] = new ReportParameter();
        reportParameterCollection[4].Name = "employee_active";
        if (empactive.SelectedValue.ToString().Equals(""))
            reportParameterCollection[4].Values.Add(null);
        else
            reportParameterCollection[4].Values.Add(empactive.SelectedValue.ToString());
        ReportViewer(reportParameterCollection);
    }

    protected void EmployeesData_Click(object sender, EventArgs e)
    {
        jobs_data.Style.Add("display", "none");
        vendorperformance_data.Style.Add("display", "none");
        Employee_Status.Style.Add("display", "flex");
    }

    protected void clientemp_status_Click(object sender, EventArgs e)
    {
        Employee_Status.Style.Add("display", "flex");

        ReportViewer2.ProcessingMode = ProcessingMode.Remote;
        ReportViewer2.ServerReport.ReportServerCredentials = new ReportViewerCredentials("aseemanand-001", "Iw2raran17.", "IFC");
        ReportViewer2.ServerReport.ReportServerUrl = new Uri("http://sql5030.smarterasp.net/ReportServer");
        ReportViewer2.ServerReport.ReportPath = "/aseemanand-001/ClientEmpStatus";

        ReportParameter[] reportParameterCollection = new ReportParameter[5];
        reportParameterCollection[0] = new ReportParameter();
        reportParameterCollection[0].Name = "clientid";
        reportParameterCollection[0].Values.Add(Session["ClientID"].ToString());
        reportParameterCollection[1] = new ReportParameter();
        reportParameterCollection[1].Name = "vendorid";
        if (empvendorid.SelectedValue.ToString().Equals(""))
            reportParameterCollection[1].Values.Add(null);
        else
            reportParameterCollection[1].Values.Add(empvendorid.SelectedValue.ToString());
        reportParameterCollection[2] = new ReportParameter();
        reportParameterCollection[2].Name = "empid";
        if (empID.SelectedValue.ToString().Equals(""))
            reportParameterCollection[2].Values.Add(null);
        else
            reportParameterCollection[2].Values.Add(empID.SelectedValue.ToString());
        reportParameterCollection[3] = new ReportParameter();
        reportParameterCollection[3].Name = "start_date";
        if (empstartdate.Value.ToString().Equals(""))
            reportParameterCollection[3].Values.Add(null);
        else
            reportParameterCollection[3].Values.Add(empstartdate.Value.ToString());
        reportParameterCollection[4] = new ReportParameter();
        reportParameterCollection[4].Name = "end_date";
        if (empenddate.Value.ToString().Equals(""))
            reportParameterCollection[4].Values.Add(null);
        else
            reportParameterCollection[4].Values.Add(empenddate.Value.ToString());
        ReportViewer(reportParameterCollection);
    }
}