﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class C_ViewJobs : System.Web.UI.Page
{
    StringFunctions func = new StringFunctions();
    SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        if(!IsPostBack)
        {
            ViewJobsInTable();
        }
    }
    private void ViewJobsInTable()
    {
        string sTable = "<tbody>";
        API.Service jobInfo = new API.Service();
        XmlDocument xmldoc = new XmlDocument();

        //xmldoc.LoadXml("<XML>" + jobInfo.get_JobView("srinivas.gadde@pamten.ca", "ferivan", "2", "", "", "", "", "", "", "").InnerXml + "</XML>");
        xmldoc.LoadXml("<XML>" + jobInfo.get_Jobs("", Session["Email"].ToString(), Session["P@ss"].ToString(), "", Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/JOBS ");
        sTable = "";
        int CountRows = 1;

        string _sBackground = "";

//code for if here
        if( Response.Count !=0)
        { 
        for (int intCount = 0; intCount < Response.Count; intCount++)
        {
            //wrap text for title
            string original_jobtitle = Response[intCount].SelectSingleNode("JOB_TITLE").InnerText;

            string job_title = "";
            if (original_jobtitle.Length > 25)
            {
                job_title = original_jobtitle.Substring(0, 25);
            }
            else
            {
                job_title = original_jobtitle;
            }

            string urgent_job = Response[intCount].SelectSingleNode("URGENT").InnerText;

            //sTable = sTable + "<tr " + _sBackground + ">";
            sTable = sTable + "<tr>";
            //sTable = sTable + "<td>" + CountRows + "</td>";

            if (Response[intCount].SelectSingleNode("URGENT").InnerText == "1")
            {
                sTable = sTable + "<td style=color:red><blink>" + "Urgent" + "</blink> </td> ";
                sTable = sTable + "<td style=color:red;white-space:nowrap;><a style=color:red href='C_JobDetails.aspx?jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                sTable = sTable + "<td style=color:red>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + Response[intCount].SelectSingleNode("JOB_LOCATION").InnerText.Replace(",Canada", "") + " </td> ";
                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                // sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                DateTime comp_end_date = DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                DateTime thisday = DateTime.Now;
                if (comp_end_date <= thisday)
                {
                    sTable = sTable + "<td style=color:red>N/A</td> ";
                }
                else
                {
                    sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                }
                //sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("NO_OF_OPENINGS").InnerText + " </td> ";
                //sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("HIRED").InnerText + " </td> ";
                //sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("AVAILABLE_JOBS").InnerText + " </td> ";
                sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("RECENT").InnerText + " day(s)</td> ";
                //sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("USERNAME").InnerText + " </td> ";
                sTable = sTable + "</tr>";
            }
            else
            {
                sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("JOB_STATUS").InnerText + "</td>";
                sTable = sTable + "<td><a href='C_JobDetails.aspx?jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                sTable = sTable + "<td>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("JOB_LOCATION").InnerText.Replace(",Canada", "") + " </td> ";
                sTable = sTable + "<td>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                //sTable = sTable + "<td>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                DateTime comp_end_date = DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                DateTime thisday = DateTime.Now;
                if (comp_end_date <= thisday)
                {
                    sTable = sTable + "<td style=color:red>N/A</td> ";
                }
                else
                {
                    sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                }
                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("NO_OF_OPENINGS").InnerText + " </td> ";
                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("HIRED").InnerText + " </td> ";
                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("AVAILABLE_JOBS").InnerText + " </td> ";
                sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("RECENT").InnerText + " day(s)</td> ";
                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("USERNAME").InnerText + " </td> ";
                sTable = sTable + "</tr>";
            }
            CountRows++;
        }
        }
        else
        {
            try
            {

                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();

                    string strSql = " (select distinct dbo.GetJobNo(oj.job_id) job_alias,oj.job_id,oj.create_date,(select comments from ovms_job_comments where job_id = oj.job_id) " +
                              "as comments,   oj.user_id, (select first_name + ' ' + last_name from ovms_users where user_id = oj.user_id) firstname,  " +
                              " oj.job_title,  job_currency,oj.urgent,oj.job_timezone,oj.vendors ,ojd.Base_salary,ojd.Bonus,oj.contract_start_date,oj.Contract_end_date,     " +
                              " oj.job_status_id,os.job_status,oj.job_title,oj.no_of_openings,oj.hired,oj.hired,  " +
                              "  (oj.no_of_openings - oj.hired)available_jobs,  oj.department_id,  od.department_name,oj.client_id,oc.client_name, " +
                              "  op.job_position_type,op.position_type_id,oj.vendor_id,  " +

                              "  ojd.posting_start_date,ojd.posting_end_date,    datediff(day, oj.create_date, GETDATE()) " +
                              "   recent,jl.address1,jl.job_location_id,  jl.post_code,   concat(jl.city, ', ', jl.province) " +
                              "  job_location,ojd.able_to_move,ojd.travel_time,ojd.hours_per_day,   jp.hiring_manager_name,  jp.coordinator,  " +
                              "   jp.Distributor,jp.creator,jp.create_date,jp.submit_date,   jp.max_submission_per_supplier, jp.auto_invoice_type,jp.purchase_order_number, " +
                              "   jp.reason_for_open,ja.markup,   ja.ot_bill_rate_from,ja.dbl_pay_rate_from, ja.ot_pay_rate_from,ja.st_bill_rate_from,ja.dt_bill_rate_from,  " +
                              "    ja.vender_pay_rate,ja.vender_ot_pay_rate,ja.vender_dt_pay_rate,jp.interview_requirement,  " +
                              "    jp.start_and_end_time,  coalesce(ja.std_pay_rate_from, 0) std_pay_rate_from from ovms_jobs as " +
                              "    oj join ovms_job_status as os on oj.job_status_id = os.job_status_id join ovms_job_details as ojd " +
                              "   on ojd.job_id = oj.job_id    join ovms_departments as od on oj.department_id = od.department_id join ovms_clients as oc " +
                              "   on oj.client_id = oc.client_id  join ovms_users as usr on usr.client_id = oc.client_id " +
                              "   join ovms_job_position_type as op on oj.position_type_id = op.position_type_id " +
                              " join ovms_vendors as ov on ov.client_ID = oj.client_ID " +
                              "  left join ovms_job_posting_info as jp on oj.job_id = jp.job_id " +
                              "   left join ovms_job_accounting as ja on ja.job_id = oj.job_id " +
                              "   join ovms_job_locations as jl on ojd.job_location_id = jl.job_location_id where 1 = 1 and oj.submit='1'" + " and oc.client_id = '" + Session["ClientID"].ToString() +
                              "' and patindex('%" + Session["VendorID"].ToString() + "%', vendors) >0  " +
                              "   and os.active = 1 and od.active = 1  and oc.active = 1 and op.active = 1  and ov.active = 1 and oj.urgent = 1 " +
                              "  UNION select distinct dbo.GetJobNo(oj.job_id) job_alias,oj.job_id,oj.create_date,(select comments from ovms_job_comments where job_id = oj.job_id)  " +
                              "as comments,   oj.user_id, (select first_name + ' ' + last_name from ovms_users where user_id = oj.user_id) firstname,   " +
                              " oj.job_title,  job_currency,'0' as urgent,oj.job_timezone,oj.vendors ,ojd.Base_salary,ojd.Bonus,  oj.contract_start_date,oj.Contract_end_date,   " +
                              " oj.job_status_id,os.job_status,oj.job_title,oj.no_of_openings,oj.hired,oj.hired,  " +
                              "  (oj.no_of_openings - oj.hired)available_jobs,  oj.department_id,  od.department_name,oj.client_id,oc.client_name,  " +
                              "  op.job_position_type,op.position_type_id,oj.vendor_id, " +
                              "  ojd.posting_start_date,ojd.posting_end_date,    datediff(day, oj.create_date, GETDATE()) " +
                              "  recent,jl.address1,jl.job_location_id,  jl.post_code,   concat(jl.city, ', ', jl.province) " +
                              "  job_location,ojd.able_to_move,ojd.travel_time,ojd.hours_per_day,   jp.hiring_manager_name,  jp.coordinator,  " +
                              "  jp.Distributor,jp.creator,jp.create_date,jp.submit_date,   jp.max_submission_per_supplier, jp.auto_invoice_type,jp.purchase_order_number, " +
                              "  jp.reason_for_open,ja.markup,   ja.ot_bill_rate_from,ja.dbl_pay_rate_from, ja.ot_pay_rate_from,ja.st_bill_rate_from,ja.dt_bill_rate_from,  " +
                              "   ja.vender_pay_rate,ja.vender_ot_pay_rate,ja.vender_dt_pay_rate,jp.interview_requirement,  " +
                              "    jp.start_and_end_time,  coalesce(ja.std_pay_rate_from, 0) std_pay_rate_from from ovms_jobs as " +
                              "   oj join ovms_job_status as os on oj.job_status_id = os.job_status_id join ovms_job_details as ojd " +
                              "   on ojd.job_id = oj.job_id    join ovms_departments as od on oj.department_id = od.department_id join ovms_clients as oc " +
                              "   on oj.client_id = oc.client_id  join ovms_users as usr on usr.client_id = oc.client_id " +
                              "   join ovms_job_position_type as op on oj.position_type_id = op.position_type_id " +

                              "   join ovms_vendors as ov on ov.client_ID = oj.client_ID " +
                              "   left join ovms_job_posting_info as jp on oj.job_id = jp.job_id " +
                              "   left join ovms_job_accounting as ja on ja.job_id = oj.job_id " +
                              "  join ovms_job_locations as jl on ojd.job_location_id = jl.job_location_id where 1 = 1 and oj.submit='1'" + " and oc.client_id = '" + Session["ClientID"].ToString() +

                               "' and patindex('%" + Session["VendorID"].ToString() + "%', vendors) >0  " +
                              "  and os.active = 1 and od.active = 1  and oc.active = 1 and op.active = 1 " +
                              "and ov.active = 1 and oj.urgent = 0)   " +
                              " order by urgent desc, oj.create_date desc";





                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    //xml_string += "<RESPONSE>";
                    if (reader.HasRows)
                        while (reader.Read())
                        {
                            string job_title = reader["job_Title"].ToString();
                            if (job_title.Length > 25)
                            {
                                job_title = job_title.Substring(0, 25);
                            }
                            
                            //xml_string += "<RESPONSE_STATUS>1</RESPONSE_STATUS>";
                            if (reader["urgent"].ToString() == "1")
                            {
                                sTable = sTable + "<td style=color:red><blink>" + "Urgent" + "</blink> </td> ";
                                sTable = sTable + "<td style=color:red;white-space:nowrap;><a style=color:red href='C_JobDetails.aspx?jobID=" + reader["job_alias"].ToString() + "'>" + reader["job_alias"].ToString() + "</td>";
                                sTable = sTable + "<td style=color:red>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + reader["job_location"].ToString().Replace(",Canada", "") + " </td> ";
                                sTable = sTable + "<td style=color:red;white-space:nowrap;>" + DateTime.Parse(reader["contract_start_date"].ToString()).ToString("dd MMM, yyyy") + " </td> ";
                                // sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                                DateTime comp_end_date = DateTime.Parse(reader["Contract_end_date"].ToString());
                                DateTime thisday = DateTime.Now;
                                if (comp_end_date <= thisday)
                                {
                                    sTable = sTable + "<td style=color:red>N/A</td> ";
                                }
                                else
                                {
                                    sTable = sTable + "<td style=color:red>" + DateTime.Parse(reader["Contract_end_date"].ToString()).ToString("dd MMM, yyyy") + " </td> ";
                                }
                               sTable = sTable + "<td style=color:red>" + reader["RECENT"].ToString()+ " day(s)</td> ";
                                sTable = sTable + "</tr>";
                            }
                            else
                            {
                                sTable = sTable + "<td>" + reader["JOB_STATUS"].ToString() + "</td>";
                                sTable = sTable + "<td><a href='C_JobDetails.aspx?jobID=" + reader["job_alias"].ToString() + "'>" + reader["job_alias"].ToString() + "</td>";
                                sTable = sTable + "<td>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                                sTable = sTable + "<td>" + reader["job_location"].ToString().Replace(",Canada", "") + " </td> ";
                                sTable = sTable + "<td>" + DateTime.Parse(reader["contract_start_date"].ToString()).ToString("dd MMM, yyyy") + " </td> ";
                                //sTable = sTable + "<td>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                                DateTime comp_end_date = DateTime.Parse(reader["Contract_end_date"].ToString());
                                DateTime thisday = DateTime.Now;
                                if (comp_end_date <= thisday)
                                {
                                    sTable = sTable + "<td style=color:red>N/A</td> ";
                                }
                                else
                                {
                                    sTable = sTable + "<td style=color:red>" + DateTime.Parse(reader["Contract_end_date"].ToString()).ToString("dd MMM, yyyy")  + " </td> ";
                                }
                              sTable = sTable + "<td>" + reader["RECENT"].ToString() + " day(s)</td> ";
                                //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("USERNAME").InnerText + " </td> ";
                                sTable = sTable + "</tr>";
                            }
                        }

                    reader.Close();
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                //logService.set_log(124, HttpContext.Current.Request.Url.AbsoluteUri, ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

        }

        sTable = sTable + "</tbody>";
        jobInfo.Dispose();
        lblTableData.Text = sTable;

    }

    private void ViewJobsonclick(bool inputs)
    {
        string sTable = "<tbody>";
        API.Service jobInfo = new API.Service();
        XmlDocument xmldoc = new XmlDocument();

        //xmldoc.LoadXml("<XML>" + jobInfo.get_JobView("srinivas.gadde@pamten.ca", "ferivan", "2", "", "", "", "", "", "", "").InnerXml + "</XML>");
        xmldoc.LoadXml("<XML>" + jobInfo.get_Jobs("", Session["Email"].ToString(), Session["P@ss"].ToString(), "", Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/JOBS ");
        sTable = "";
        int CountRows = 1;

        string _sBackground = "";

        //code for if here
        if(inputs)
        {
            try
            {

                if (conn.State == System.Data.ConnectionState.Closed)
                {
                    conn.Open();

                    string strSql = " (select distinct dbo.GetJobNo(oj.job_id) job_alias, oj.active,oj.job_id,oj.create_date,(select comments from ovms_job_comments where job_id = oj.job_id) " +
                              "as comments,   oj.user_id, (select first_name + ' ' + last_name from ovms_users where user_id = oj.user_id) firstname,  " +
                              " oj.job_title,  job_currency,oj.urgent,oj.job_timezone,oj.vendors ,ojd.Base_salary,ojd.Bonus,oj.contract_start_date,oj.Contract_end_date,     " +
                              " oj.job_status_id,os.job_status,oj.job_title,oj.no_of_openings,oj.hired,oj.hired,  " +
                              "  (oj.no_of_openings - oj.hired)available_jobs,  oj.department_id,  od.department_name,oj.client_id,oc.client_name, " +
                              "  op.job_position_type,op.position_type_id,oj.vendor_id,  " +

                              "  ojd.active, ojd.posting_start_date,ojd.posting_end_date,    datediff(day, oj.create_date, GETDATE()) " +
                              "   recent,jl.address1,jl.job_location_id,  jl.post_code,   concat(jl.city, ', ', jl.province) " +
                              "  job_location,ojd.able_to_move,ojd.travel_time,ojd.hours_per_day,   jp.hiring_manager_name,  jp.coordinator,  " +
                              "   jp.Distributor,jp.creator,jp.create_date,jp.submit_date,   jp.max_submission_per_supplier, jp.auto_invoice_type,jp.purchase_order_number, " +
                              "   jp.reason_for_open,ja.markup,   ja.ot_bill_rate_from,ja.dbl_pay_rate_from, ja.ot_pay_rate_from,ja.st_bill_rate_from,ja.dt_bill_rate_from,  " +
                              "    ja.vender_pay_rate,ja.vender_ot_pay_rate,ja.vender_dt_pay_rate,jp.interview_requirement,  " +
                              "    jp.start_and_end_time,  coalesce(ja.std_pay_rate_from, 0) std_pay_rate_from from ovms_jobs as " +
                              "    oj join ovms_job_status as os on oj.job_status_id = os.job_status_id join ovms_job_details as ojd " +
                              "   on ojd.job_id = oj.job_id    join ovms_departments as od on oj.department_id = od.department_id join ovms_clients as oc " +
                              "   on oj.client_id = oc.client_id  join ovms_users as usr on usr.client_id = oc.client_id " +
                              "   join ovms_job_position_type as op on oj.position_type_id = op.position_type_id " +
                              " join ovms_vendors as ov on ov.client_ID = oj.client_ID " +
                              "  left join ovms_job_posting_info as jp on oj.job_id = jp.job_id " +
                              "   left join ovms_job_accounting as ja on ja.job_id = oj.job_id " +
                              "   join ovms_job_locations as jl on ojd.job_location_id = jl.job_location_id where 1 = 1 and oj.submit='1'" + " and oc.client_id = '" + Session["ClientID"].ToString() +
                              "' and patindex('%" + Session["VendorID"].ToString() + "%', vendors) >0  " +
                              "  and oj.active = 0 and os.active = 1 and od.active = 1  and oc.active = 1 and op.active = 1  and ov.active = 1 and oj.urgent = 1 " +
                              "  UNION select distinct dbo.GetJobNo(oj.job_id) job_alias, oj.active,oj.job_id,oj.create_date,(select comments from ovms_job_comments where job_id = oj.job_id)  " +
                              "as comments,   oj.user_id, (select first_name + ' ' + last_name from ovms_users where user_id = oj.user_id) firstname,   " +
                              " oj.job_title,  job_currency,'0' as urgent,oj.job_timezone,oj.vendors ,ojd.Base_salary,ojd.Bonus,  oj.contract_start_date,oj.Contract_end_date,   " +
                              " oj.job_status_id,os.job_status,oj.job_title,oj.no_of_openings,oj.hired,oj.hired,  " +
                              "  (oj.no_of_openings - oj.hired)available_jobs,  oj.department_id,  od.department_name,oj.client_id,oc.client_name,  " +
                              "  op.job_position_type,op.position_type_id,oj.vendor_id, " +
                              "  ojd.active, ojd.posting_start_date,ojd.posting_end_date,    datediff(day, oj.create_date, GETDATE()) " +
                              "  recent,jl.address1,jl.job_location_id,  jl.post_code,   concat(jl.city, ', ', jl.province) " +
                              "  job_location,ojd.able_to_move,ojd.travel_time,ojd.hours_per_day,   jp.hiring_manager_name,  jp.coordinator,  " +
                              "  jp.Distributor,jp.creator,jp.create_date,jp.submit_date,   jp.max_submission_per_supplier, jp.auto_invoice_type,jp.purchase_order_number, " +
                              "  jp.reason_for_open,ja.markup,   ja.ot_bill_rate_from,ja.dbl_pay_rate_from, ja.ot_pay_rate_from,ja.st_bill_rate_from,ja.dt_bill_rate_from,  " +
                              "   ja.vender_pay_rate,ja.vender_ot_pay_rate,ja.vender_dt_pay_rate,jp.interview_requirement,  " +
                              "    jp.start_and_end_time,  coalesce(ja.std_pay_rate_from, 0) std_pay_rate_from from ovms_jobs as " +
                              "   oj join ovms_job_status as os on oj.job_status_id = os.job_status_id join ovms_job_details as ojd " +
                              "   on ojd.job_id = oj.job_id    join ovms_departments as od on oj.department_id = od.department_id join ovms_clients as oc " +
                              "   on oj.client_id = oc.client_id  join ovms_users as usr on usr.client_id = oc.client_id " +
                              "   join ovms_job_position_type as op on oj.position_type_id = op.position_type_id " +

                              "   join ovms_vendors as ov on ov.client_ID = oj.client_ID " +
                              "   left join ovms_job_posting_info as jp on oj.job_id = jp.job_id " +
                              "   left join ovms_job_accounting as ja on ja.job_id = oj.job_id " +
                              "  join ovms_job_locations as jl on ojd.job_location_id = jl.job_location_id where 1 = 1 and oj.submit='1'" + " and oc.client_id = '" + Session["ClientID"].ToString() +

                               "' and patindex('%" + Session["VendorID"].ToString() + "%', vendors) >0  " +
                              " and oj.active = 0 and os.active = 1 and od.active = 1  and oc.active = 1 and op.active = 1 " +
                              "and ov.active = 1 and oj.urgent = 0)   " +
                              " order by urgent desc, oj.create_date desc";





                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    //xml_string += "<RESPONSE>";
                    if (reader.HasRows)
                        while (reader.Read())
                        {
                            string job_title = reader["job_Title"].ToString();
                            if (job_title.Length > 25)
                            {
                                job_title = job_title.Substring(0, 25);
                            }

                            //xml_string += "<RESPONSE_STATUS>1</RESPONSE_STATUS>";

                            sTable = sTable + "<td style=color:red>Inactive</td> ";
                            sTable = sTable + "<td style=color:red;white-space:nowrap;><a style=color:red href='C_JobDetails.aspx?jobID=" + reader["job_alias"].ToString() + "'>" + reader["job_alias"].ToString() + "</td>";
                            sTable = sTable + "<td style=color:red>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                            sTable = sTable + "<td style=color:red;white-space:nowrap;>" + reader["job_location"].ToString().Replace(",Canada", "") + " </td> ";
                            sTable = sTable + "<td style=color:red;white-space:nowrap;>" + DateTime.Parse(reader["contract_start_date"].ToString()).ToString("dd MMM, yyyy") + " </td> ";
                            // sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                            DateTime comp_end_date = DateTime.Parse(reader["Contract_end_date"].ToString());
                            DateTime thisday = DateTime.Now;
                            if (comp_end_date <= thisday)
                            {
                                sTable = sTable + "<td style=color:red>N/A</td> ";
                            }
                            else
                            {
                                sTable = sTable + "<td style=color:red>" + DateTime.Parse(reader["Contract_end_date"].ToString()).ToString("dd MMM, yyyy") + " </td> ";
                            }
                            sTable = sTable + "<td style=color:red>" + reader["RECENT"].ToString() + " day(s)</td> ";
                            sTable = sTable + "</tr>";

                        }

                    reader.Close();
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                //logService.set_log(124, HttpContext.Current.Request.Url.AbsoluteUri, ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

        }
        else
        {

            if (Response.Count != 0)
            {
                for (int intCount = 0; intCount < Response.Count; intCount++)
                {
                    //wrap text for title
                    string original_jobtitle = Response[intCount].SelectSingleNode("JOB_TITLE").InnerText;

                    string job_title = "";
                    if (original_jobtitle.Length > 25)
                    {
                        job_title = original_jobtitle.Substring(0, 25);
                    }
                    else
                    {
                        job_title = original_jobtitle;
                    }

                    string urgent_job = Response[intCount].SelectSingleNode("URGENT").InnerText;

                    //sTable = sTable + "<tr " + _sBackground + ">";
                    sTable = sTable + "<tr>";
                    //sTable = sTable + "<td>" + CountRows + "</td>";

                    if (Response[intCount].SelectSingleNode("URGENT").InnerText == "1")
                    {
                        sTable = sTable + "<td style=color:red><blink>" + "Urgent" + "</blink> </td> ";
                        sTable = sTable + "<td style=color:red;white-space:nowrap;><a style=color:red href='C_JobDetails.aspx?jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                        sTable = sTable + "<td style=color:red>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                        sTable = sTable + "<td style=color:red;white-space:nowrap;>" + Response[intCount].SelectSingleNode("JOB_LOCATION").InnerText.Replace(",Canada", "") + " </td> ";
                        sTable = sTable + "<td style=color:red;white-space:nowrap;>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                        // sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                        DateTime comp_end_date = DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                        DateTime thisday = DateTime.Now;
                        if (comp_end_date <= thisday)
                        {
                            sTable = sTable + "<td style=color:red>N/A</td> ";
                        }
                        else
                        {
                            sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                        }
                        sTable = sTable + "<td style=color:red>" + Response[intCount].SelectSingleNode("RECENT").InnerText + " day(s)</td> ";
                        sTable = sTable + "</tr>";
                    }
                    else
                    {
                        sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("JOB_STATUS").InnerText + "</td>";
                        sTable = sTable + "<td><a href='C_JobDetails.aspx?jobID=" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "'>" + Response[intCount].SelectSingleNode("JOB_ALIAS").InnerText + "</td>";
                        sTable = sTable + "<td>" + func.FixString(Server.HtmlDecode(job_title)) + "</td> ";
                        sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("JOB_LOCATION").InnerText.Replace(",Canada", "") + " </td> ";
                        sTable = sTable + "<td>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                        //sTable = sTable + "<td>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                        DateTime comp_end_date = DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                        DateTime thisday = DateTime.Now;
                        if (comp_end_date <= thisday)
                        {
                            sTable = sTable + "<td style=color:red>N/A</td> ";
                        }
                        else
                        {
                            sTable = sTable + "<td style=color:red>" + DateTime.Parse(Response[intCount].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                        }
                       sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("RECENT").InnerText + " day(s)</td> ";
                        //sTable = sTable + "<td>" + Response[intCount].SelectSingleNode("USERNAME").InnerText + " </td> ";
                        sTable = sTable + "</tr>";
                    }
                    CountRows++;
                }
            }

        }

        sTable = sTable + "</tbody>";
        jobInfo.Dispose();
        lblTableData.Text = sTable;

    }

    protected void view_all_jobs_CheckedChanged(object sender, EventArgs e)
    {
        ViewJobsonclick(view_all_jobs.Checked);
    }
}