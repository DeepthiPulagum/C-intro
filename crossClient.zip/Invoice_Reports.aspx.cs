﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Security.Principal;

using System.Data;
using System.Xml;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Invoice_Reports : System.Web.UI.Page
{
    public string UserName { get { return (Session["FirstName"].ToString() + ' ' + Session["LastName"].ToString()); } }
    public string jobDetails { get { return (jbView.Value); } }
    public string empid { get { return empView.Value; } }
    public string tsid { get { return tsview.Value; } }

    StringFunctions func = new StringFunctions();
    SqlConnection conn;

    public partial class ReportViewerCredentials : IReportServerCredentials
    {
        private string _userName;
        private string _password;
        private string _domain;


        public ReportViewerCredentials(string userName, string password, string domain)
        {
            _userName = userName;
            _password = password;
            _domain = domain;


        }




        public WindowsIdentity ImpersonationUser
        {
            get
            {
                return null;
            }
        }


        public ICredentials NetworkCredentials
        {
            get
            {


                return new NetworkCredential(_userName, _password, _domain);


            }
        }


        public bool GetFormsCredentials(out Cookie authCookie,
                out string userName, out string password,
                out string authority)
        {
            authCookie = null;
            userName = _userName;
            password = _password;
            authority = _domain;


            // Not using form credentials
            return false;
        }






    }
    string emp_idG = "";
    string end_dateG = "";
    string start_dateG = "";
    string job_idG = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["jobID"] != null)
        {
            jbView.Value = Request["jobID"].ToString();
        }

        if (Request["empID"] != null)
        {
            empView.Value = Request["empID"].ToString();
        }

        if (Request["TID"] != null)
        {
            tsview.Value = Request["TID"].ToString();
        }

        if (Request["recieversNo"] != null)
        {
            jbView.Value = Request["recieversNo"].ToString();
        }
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }

        if (!Page.IsPostBack)
        {
            job_title();
            emp_detail();
            view_report_Click();

        }

        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();
        string strSqln = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        SqlDataReader readern = cmdn.ExecuteReader();
        if (readern.HasRows == true)
        {

            while (readern.Read())
            {
                lblnotification.Text = readern["number"].ToString();

                lblnot2.Visible = true;
                lblnot2.Text = "(" + readern["number"].ToString() + ")";
                if (Convert.ToInt32(readern["number"].ToString()) < 1)

                {

                    lblnot2.Visible = false;

                }

            }


        }
        readern.Close();
        cmdn.Dispose();
        conn.Close();

        //lblname.Text = Session["FirstName"] + " " + Session["LastName"] + " (" + (Session["Email"])+")";


        XmlDocument xmldoc = new XmlDocument();
        API.Service prof = new API.Service();
        // API.Service prof = new API.Service();
        xmldoc.LoadXml("<XML>" + prof.get_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString()).InnerXml + "</XML>");
        // xmldoc.LoadXml("<XML>" + prof.get_Profile("greg@opusing.com ", "1234", "9").InnerXml + "</XML>");
        XmlNodeList Response1 = xmldoc.SelectNodes("XML/RESPONSE/USER_NO");

        txtfirst.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/FIRST_NAME").InnerText;
        txtsecond.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/LAST_NAME").InnerText;
        txtemail.Text = xmldoc.SelectSingleNode("XML/RESPONSE/USER_NO/EMAIL").InnerText;





        //string interview_alert = "";
        //conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);

        //if (conn.State == System.Data.ConnectionState.Closed)
        //{
        //    DateTime thisDay = DateTime.Now;
        //    string vendorID = Session["VendorID"].ToString();
        //    conn.Open();

        //    string strSql = " select cast(interview_date as datetime) + (select cast(interview_time as datetime) ) as interview " +
        //                   "  from ovms_employee_actions where client_id = '" + Session["ClientID"].ToString() + "' and interview_confirm = 1 and(cast(interview_date as datetime) + (select cast(interview_time as datetime))) " +
        //                   "    BETWEEN DATEADD(HOUR, 3, DATEADD(minute, 10, GETDATE())) and DATEADD(minute, +15, DATEADD(HOUR, 3, GETDATE())) ";

        //    SqlCommand cmd = new SqlCommand(strSql, conn);
        //    SqlDataReader reader = cmd.ExecuteReader();
        //    if (reader.HasRows == true)
        //    {
        //        interview_alert = "1";

        //    }
        //    if (interview_alert == "1")
        //    {
        //        System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, typeof(System.Web.UI.Page), "Script", "interviewTIME('','','');", true);
        //        // Response.End();

        //    }
        //}
    }
    //protected void selEmployee_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    string Employee_Name = selEmployee.SelectedItem.Text;
    //    Response.Redirect("Add_Jobs.aspx?jopen=Y&p=JA&type=" + selEmployee.SelectedItem.Value);
    //    Response.End();
    //}



    //protected void seljobtype_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    Response.Redirect("Add_jobs.aspx?type=" + seljobtype.SelectedItem.Value);
    //}
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txtnewpassword.Text == "" || txtconfirmpassword.Text == "")
        {

            Label1.Text = "*Fields can not be empty";
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Focus();
        }
        else
        {
            if (txtnewpassword.Text != txtconfirmpassword.Text)
            {

                Label1.Text = "*Passwords do not match";
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Focus();

            }
            else
            {
                XmlDocument xmldoc = new XmlDocument();
                API.Service updateP = new API.Service();
                xmldoc.LoadXml("<XML>" + updateP.update_Personal_Profile(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["UserID"].ToString(), txtnewpassword.Text).InnerXml + "</XML>");
                Session["P@ss"] = "";
                Session["P@ss"] = txtnewpassword.Text;
                Response.Redirect("C_Dashboard.aspx");
            }


        }
    }
    protected void emp_detail()
    {
        DataTable dt = new DataTable();
        API.Service iReport = new API.Service();
        XmlDocument xDoc = new XmlDocument();
        xDoc.LoadXml("<XML>" + iReport.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), "", "1", "", "", "", "", "").InnerXml + "</XML>");
        XmlNodeList Response = xDoc.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
        dt.Columns.Add("FIRSTNAME", typeof(string));
        dt.Columns.Add("EMPLOYEE_ID", typeof(string));
        foreach (XmlNode node in Response)
        {
            DataRow dr = dt.NewRow();

            dr["FIRSTNAME"] = func.FixString(node["FIRSTNAME"].InnerText + " " + node["LASTNAME"].InnerText);

            dr["EMPLOYEE_ID"] = (node["EMPLOYEE_ID"].InnerText).Substring((node["EMPLOYEE_ID"].InnerText).Length - 6);
            dt.Rows.Add(dr);
        }

        Dd_emp.DataSource = dt;

        Dd_emp.DataTextField = "FIRSTNAME";
        Dd_emp.DataValueField = "EMPLOYEE_ID";
        Dd_emp.DataBind();

    }
    protected void job_title()
    {
        DataTable dt = new DataTable();
        API.Service jobInfo = new API.Service();
        XmlDocument xmldoc = new XmlDocument();

        //xmldoc.LoadXml("<XML>" + jobInfo.get_JobView("srinivas.gadde@pamten.ca", "ferivan", "2", "", "", "", "", "", "", "").InnerXml + "</XML>");
        xmldoc.LoadXml("<XML>" + jobInfo.get_Jobs("", Session["Email"].ToString(), Session["P@ss"].ToString(), Session["VendorID"].ToString(), Session["UserID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
        XmlNodeList Response = xmldoc.SelectNodes("XML/RESPONSE/JOBS ");
        dt.Columns.Add("JOB_TITLE", typeof(string));
        dt.Columns.Add("JOB_ID", typeof(string));
        foreach (XmlNode node in Response)
        {
            DataRow dr = dt.NewRow();
            dr["JOB_TITLE"] = func.FixString(node["JOB_TITLE"].InnerText);

            dr["JOB_ID"] = node["JOB_ID"].InnerText;
            dt.Rows.Add(dr);
        }
        //Dd_job.Items.Insert(0, new ListItem("Select a Title", ""));
        Dd_job.DataSource = dt;
        Dd_job.DataTextField = "JOB_TITLE";
        Dd_job.DataValueField = "JOB_ID";
        Dd_job.DataBind();
    }
    protected void btn_report_generate_Click(object sender, EventArgs e)
    {
        view_report_Click();
    }

    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        ICredentials IReportServerCredentials.NetworkCredentials
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }

        //public bool GetFormsCredentials(out Cookie authCookie, out string userName, out string password, out string authority)
        //{
        //    throw new NotImplementedException();
        //}
    }
    protected void view_report_Click()
    {
        try
        {

            Rw_invoice.ProcessingMode = ProcessingMode.Remote;
            Rw_invoice.ServerReport.ReportServerCredentials = new ReportViewerCredentials("aseemanand-001", "Opusing@123", "IFC");
            Rw_invoice.ServerReport.ReportServerUrl = new Uri("http://sql5030.smarterasp.net/ReportServer");
            Rw_invoice.ServerReport.ReportPath = "/aseemanand-001/ovms_invoices_status";

            Rw_invoice.ServerReport.Refresh();

            ReportParameter[] reportParameterCollection = new ReportParameter[6];

            reportParameterCollection[0] = new ReportParameter();
            reportParameterCollection[0].Name = "vendor_id";
            reportParameterCollection[0].Values.Add(Session["VendorID"].ToString());
            reportParameterCollection[1] = new ReportParameter();
            reportParameterCollection[1].Name = "client_id";
            reportParameterCollection[1].Values.Add(Session["ClientID"].ToString());

            reportParameterCollection[2] = new ReportParameter();
            reportParameterCollection[2].Name = "start_date";
            if (dp_start_Date.Value.Equals(""))
                reportParameterCollection[2].Values.Add(null);
            else
                reportParameterCollection[2].Values.Add(dp_start_Date.ToString());

            reportParameterCollection[3] = new ReportParameter();
            reportParameterCollection[3].Name = "end_date";
            if (dp_end_date.Value.Equals(""))
                reportParameterCollection[3].Values.Add(null);
            else
                reportParameterCollection[3].Values.Add(dp_end_date.ToString());

            reportParameterCollection[4] = new ReportParameter();
            reportParameterCollection[4].Name = "job_id";
            if (Dd_job.SelectedValue.ToString().Equals(""))
                reportParameterCollection[4].Values.Add(null);
            else
                reportParameterCollection[4].Values.Add(Dd_job.SelectedValue.ToString());

            reportParameterCollection[5] = new ReportParameter();
            reportParameterCollection[5].Name = "employee_id";
            if (Dd_emp.SelectedValue.ToString().Equals(""))
                reportParameterCollection[5].Values.Add(null);
            else
                reportParameterCollection[5].Values.Add(Dd_emp.SelectedValue.ToString());


            Rw_invoice.ServerReport.SetParameters(reportParameterCollection);
            Rw_invoice.ShowParameterPrompts = false;
            Rw_invoice.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            string exc = "";
        }
    }
}