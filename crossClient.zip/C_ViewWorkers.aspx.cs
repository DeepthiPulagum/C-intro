﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class C_ViewWorkers : System.Web.UI.Page
{
    StringFunctions func = new StringFunctions();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] == null)
        {
            //logout
            Session.Abandon();
            Response.Redirect("Login.aspx?m=You+have+logged+out");
            Response.End();
        }
        // pop1.Visible = false;
        //ViewworkerInTable();
        ViewcandidateInTable();

    }
    private void ViewcandidateInTable()
    {
        string sTable = "<tbody>";

        API.Service getWorkers = new API.Service();
        XmlDocument dom1 = new XmlDocument();
        dom1.LoadXml("<XML>" + getWorkers.get_employees(Session["Email"].ToString(), Session["P@ss"].ToString(), "","", Session["ClientID"].ToString(), "", "", "1", "").InnerXml + "</XML>");
        XmlNodeList Response = dom1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");
        sTable = "";
        string _sBackground = "";
        for (int iResponse = 0; iResponse < Response.Count; iResponse++)
        {
            string worker_status = Response[iResponse].SelectSingleNode("CANDIDATE_APPROVE").InnerText;
            DateTime candidate_start_date = DateTime.Parse(Response[iResponse].SelectSingleNode("STARTDATE").InnerText);
            DateTime job_start_date = DateTime.Parse(Response[iResponse].SelectSingleNode("CONTRACT_START_DATE").InnerText);
            DateTime thisday = DateTime.Today;

            string backgroundverify = "";
            if (Response[iResponse].SelectSingleNode("BACKGROUND_CHECK").InnerText != "")
            {
                backgroundverify = Response[iResponse].SelectSingleNode("BACKGROUND_CHECK").InnerText;
            }

            int EXT_REQUESTED1;
            DateTime localdate = DateTime.Now;
            IList<string> Location = func.FixString(Response[iResponse].SelectSingleNode("LOCATION").InnerText).Split(',').ToList<string>();
            string job_title = func.FixString(Response[iResponse].SelectSingleNode("JOB_TITLE").InnerText);
            string candidate_name = func.FixString(Response[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response[iResponse].SelectSingleNode("LASTNAME").InnerText);

            if (job_title.Length > 25)
            {
                job_title = job_title.Substring(0, 25);
            }

            if (candidate_name.Length > 15)
            {
                candidate_name = candidate_name.Substring(0, 15);
            }
            if (worker_status == "1" && backgroundverify == "1" && (candidate_start_date <= thisday))
            {

                sTable = sTable + "<tr " + _sBackground + ">";
                sTable = sTable + "<td><a href='C_WorkerDetail.aspx?wopen=Y&p=VW&empid=" + Response[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText + "'>" + Response[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText + "</a> </td> ";
                sTable = sTable + "<td>" + candidate_name + "</td> ";
                sTable = sTable + "<td>" + job_title + " </td> ";
                sTable = sTable + "<td>" + Location[0] + " </td> ";
                sTable = sTable + "<td>" + DateTime.Parse(Response[iResponse].SelectSingleNode("STARTDATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                //  sTable = sTable + "<td>" + DateTime.Parse(Response[iResponse].SelectSingleNode("ENDDATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                DateTime comp_end_date = DateTime.Parse(Response[iResponse].SelectSingleNode("CONTRACT_END_DATE").InnerText);
                // DateTime thisday = DateTime.Now;
                if (comp_end_date <= thisday)
                {
                    sTable = sTable + "<td>N/A</td> ";
                }
                else
                {
                    sTable = sTable + "<td>" + DateTime.Parse(Response[iResponse].SelectSingleNode("CONTRACT_END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
                }
                EXT_REQUESTED1 = Convert.ToInt32(Response[iResponse].SelectSingleNode("EXT_REQUESTED").InnerText);
                string cand_int_rejectd_by_vendor = Response[iResponse].SelectSingleNode("VENDOR_REJECT_CANDIDATE").InnerText;
                string cont_end_date = Response[iResponse].SelectSingleNode("CONTRACT_END_DATE").InnerText;
                int alertC = (DateTime.Parse(Response[iResponse].SelectSingleNode("CONTRACT_END_DATE").InnerText).Subtract(localdate)).Days;
                if (cand_int_rejectd_by_vendor == "1")

                {
                    sTable = sTable + "<td>Candidate Rejected by Vendor</td>";
                }
                else if (worker_status == "Not Working")
                {
                    sTable = sTable + "<td style=color:red>Contract Ended On:<br>" + cont_end_date + "</td>";
                }

                else
            if (alertC <= 20)

                {
                    if (alertC <= 0 && EXT_REQUESTED1 != 'N' && EXT_REQUESTED1 != 1)
                    {


                        sTable = sTable + "<td>Early Termination</td>";

                    }
                    else
                   if (EXT_REQUESTED1 == 'N')
                    {
                        //< button data-toggle='tk-modal-demo' data-modal-options='slide-down' class="btn btn-primary">Slide down</button>
                        sTable = sTable + "<td><div class='progress margin-none'> " +
                                            "<a href='V_submitted_candidate.aspx?wopen=Y&p=VW&empid=" + Response[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText + "'><div class='progress-bar  progress-bar-danger' role='progressbar' aria-valuenow='80' aria-valuemin='0' aria-valuemax='100' style='width: 80%' value='" + Response[iResponse].SelectSingleNode("EMPLOYEE_ID").InnerText + "&contract=" + 1 + "'> " +
                                            "<span class='sr-only'>80% Complete</span> " +

                                            "</div></a> " +
                                            "</div> ";
                    }
                    else

                     if (EXT_REQUESTED1 == 1)
                    {
                        sTable = sTable + "<td><div> " + "Request Sent" +
                                           //"<div class='progress-bar  progress-bar-inverse' role='progressbar' aria-valuenow='80' aria-valuemin='0' aria-valuemax='100' style='width: 80%'> " +
                                           //"<span class='sr-only'>80% Complete</span> " +
                                           "</div> " +
                                           "</div> ";
                    }
                    else
                    if (alertC >= 0 && alertC <= 20)
                    {
                        sTable = sTable + "<td><div class='progress margin-none'> " +
                                           "<div class='progress-bar  progress-bar-warning' role='progressbar' aria-valuenow='80' aria-valuemin='0' aria-valuemax='100' style='width: 80%'> " +
                                           "<span class='sr-only'>80% Complete</span> " +
                                           "</div> " +
                                           "</div> ";
                    }
                }

                else
                {
                    sTable = sTable + "<td><div class='progress margin-none'> " +
                                       "<div class='progress-bar  progress-bar-success' role='progressbar' aria-valuenow='80' aria-valuemin='0' aria-valuemax='100' style='width: 80%'> " +
                                       "<span class='sr-only'>80% Complete</span> " +
                                       "</div> " +
                                       "</div> ";
                }
                sTable = sTable + "</tr>";
            }
        }
        sTable = sTable + "</tbody>";
        getWorkers.Dispose();
        lblTableData.Text = sTable;
    }
    //private void ViewworkerInTable()
    //{
    //    string sTable = "<tbody>";

    //    API.Service getWorkers = new API.Service();
    //    // API.Service getWorkers = new API.Service();
    //    XmlDocument dom1 = new XmlDocument();
    //    dom1.LoadXml("<XML>" + getWorkers.get_worker(Session["Email"].ToString(), Session["P@ss"].ToString(), Session["VendorID"].ToString(), Session["ClientID"].ToString()).InnerXml + "</XML>");
    //    XmlNodeList Response = dom1.SelectNodes("XML/RESPONSE/EMPLOYEE_NAME_ID");


    //    int CountRows = 1;
    //    sTable = "";
    //    for (int iResponse = 0; iResponse < Response.Count; iResponse++)
    //    {
    //        string original_jobtitle = Response[iResponse].SelectSingleNode("JOB_TITLE").InnerText;
    //        string job_title = "";

    //        if (original_jobtitle.Length > 25)
    //        {
    //            job_title = original_jobtitle.Substring(0, 25);
    //        }
    //        else
    //        {
    //            job_title = original_jobtitle;
    //        }

    //        sTable = sTable + "<tr>";
    //        //sTable = sTable + "<td>" + CountRows + "</td>";
    //        //sTable = sTable + "<td>" + Response[iResponse].SelectSingleNode("ACTIVE").InnerText + " </TD>";
    //        sTable = sTable + "<td><a href='C_WorkerDetail.aspx?empid=" + Response[iResponse].SelectSingleNode("EMPLOYEE_FULL_ID").InnerText + "'>" + Response[iResponse].SelectSingleNode("EMPLOYEE_FULL_ID").InnerText + "</a> </td> ";
    //        sTable = sTable + "<td>" + func.FixString(Response[iResponse].SelectSingleNode("FIRSTNAME").InnerText + " " + Response[iResponse].SelectSingleNode("LASTNAME").InnerText) + "</td> ";
    //        sTable = sTable + "<td>" + func.FixString(job_title) + " </td> ";
    //        sTable = sTable + "<td>" + func.FixString(Response[iResponse].SelectSingleNode("LOCATION").InnerText) + " </td> ";
    //        sTable = sTable + "<td style='white-space:nowrap;'>" + DateTime.Parse(Response[iResponse].SelectSingleNode("START_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";
    //        sTable = sTable + "<td style='white-space:nowrap;'>" + DateTime.Parse(Response[iResponse].SelectSingleNode("END_DATE").InnerText).ToString("dd MMM, yyyy") + " </td> ";

    //        sTable = sTable + "</tr>";
    //        CountRows++;
    //    }
    //    sTable = sTable + "</tbody>";
    //    getWorkers.Dispose();
    //    lblTableData.Text = sTable;
    //}
}