﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class C_Sent_message : System.Web.UI.Page
{
    string email_time;
    SqlConnection conn;
    int? source_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbconn"].ConnectionString);
        conn.Open();

        string strSqln = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";


        SqlCommand cmdn = new SqlCommand(strSqln, conn);
        SqlDataReader readern = cmdn.ExecuteReader();
        if (readern.HasRows == true)
        {

            while (readern.Read())
            {



                lblinboxnumber.Text = readern["number"].ToString();


            }


        }
        readern.Close();
        cmdn.Dispose();
        conn.Close();







        string message = "";


        conn.Open();

        //  string strSql = "SELECT count (message_id) as number from ovms_messages where IsRead=0 and client_id=" + Session["ClientID"].ToString() + " and Actions='Send_V_C'";

        //" and candidate_reject_time >= '" + thisDay + "'";
        string strSQL = " select msg.User_id, msg.vendor_id,msg.sending_time,msg.sourceID, v.vendor_name, msg.IsSend,msg.message, msg.message_id, msg.Msg_Subject, msg.IsRead, msg.Actions, msg.create_date,msg.client_id,c.client_name from ovms_messages as msg  join ovms_vendors as v  on msg.vendor_id = v.vendor_id  join ovms_clients as c on c.client_id = msg.client_id " +
                                    " where msg.client_id = '" + Session["ClientID"].ToString() + "' and (Actions='Send_C_V' )" +
                                    " order by sending_time desc";

        SqlCommand cmd = new SqlCommand(strSQL, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows == true)
        {

            while (reader.Read())
            {

                int id = Convert.ToInt32(reader["message_id"].ToString());
                try
                {
                    source_id = Convert.ToInt32(reader["sourceID"].ToString());
                }
                catch
                {

                    source_id = null;


                }
                string today = (DateTime.Now).ToString("yyyyMMdd");
                string time1 = "";


                string date;

                if (reader["sending_time"].ToString() != null)
                {
                    date = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyyMMdd");




                    if (reader["sending_time"].ToString() != null)
                    {
                        date = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyyMMdd");


                        if (today == date)
                        {

                            email_time = DateTime.Parse(reader["sending_time"].ToString()).ToString("hh.mm tt");



                        }
                        else
                        {

                            email_time = DateTime.Parse(reader["sending_time"].ToString()).ToString("yyyy/MM/dd");
                        }
                    }


                }
               
                    if ( source_id ==0 && (reader["Actions"].ToString() == "SEND_C_V"))
                {


                    message = message +
                                                    @" <li> " +
                                                       @"     <a href = 'C_view_mail.aspx?_id=" + id.ToString().TrimEnd().TrimStart() + "'> " +
                                                         @"      <div class=""col-mail col-mail-1""> " +
                                                           @"         <div class=""checkbox-wrapper-mail""> " +
                                                             @"           <input type = ""checkbox"" id=""chk1""> " +
                                                               @"         <label for=""chk1"" class=""toggle""></label> " +

                                                                 @"   </div> " +

                                                                 @" <p class=""title"">" + reader["vendor_name"].ToString() +
                                                                 @"</p><span class=""star-toggle fa fa-star-o""></span> " +
                                                                       @"</div>" +
                                                               @" <div class=""col-mail col-mail-2""> " +
                                                                @"    <div class=""""> " + reader["Msg_Subject"].ToString() +




                                                                 @"   </div> " +
                                                                        @"<div class=""date"">" + email_time + "</div>" +

                                                             @"   </div> " +
                                                        @"    </a> " +
                                                    @"    </li> ";



                }

            }
                }


            
        else
        {

                message = message +
                                                               @" <li> " +
                                                                  @"     <a > " +
                                                                    @"      <div class=""col-mail col-mail-1""> " +



                                                                            @"</div>" +
                                                                          @" <div class=""col-mail col-mail-2""> " +
                                                                           @"    <div class=""subject"">No message " +




                                                                            @"   </div> " +

                                                                            @"<div class=""date""></div>" +
                                                                        @"   </div> " +

                                                                   @"    </a> " +
                                                               @"    </li> ";



            
        }
        reader.Close();
        cmd.Dispose();
        conn.Close();








        lblmsg.Text = message;
    }
}